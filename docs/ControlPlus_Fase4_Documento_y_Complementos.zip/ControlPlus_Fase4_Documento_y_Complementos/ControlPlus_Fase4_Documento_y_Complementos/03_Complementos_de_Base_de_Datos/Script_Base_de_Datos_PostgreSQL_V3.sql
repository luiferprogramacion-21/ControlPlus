/*
===============================================================================
 CONTROLPLUS - SCRIPT FISICO INTEGRAL DE BASE DE DATOS - VERSION 3
 PostgreSQL
===============================================================================

 Alcance:
   - 7 esquemas funcionales.
   - Modelo ampliado para operacion individual o compartida, pedidos de compra,
     impresion, recuperacion y respaldos verificables.
   - Claves primarias, foraneas, unicas, restricciones CHECK e indices.

 Requisitos de ejecucion:
   1. Crear previamente una base de datos vacia llamada controlplus (UTF8).
   2. Conectarse a esa base en pgAdmin.
   3. Abrir este archivo en Query Tool y ejecutarlo completo con F5.

 Decisiones vigentes incorporadas:
   - Los UUIDv7 se generan en ASP.NET Core mediante Guid.CreateVersion7().
   - Este script no necesita extensiones de PostgreSQL.
   - Los instantes se almacenan como timestamptz y se interpretan en UTC.
   - No se usa eliminacion en cascada para informacion del negocio.
   - Los precios de venta ya incluyen IVA; el IVA conocido se discrimina sin
     sumarlo nuevamente al total.
   - Los importes de venta y caja se registran en pesos colombianos enteros.
   - Todas las cantidades, incluso los metros, se venden en unidades enteras.
   - El modo inicial de turno es INDIVIDUAL; COMPARTIDO habilita sesiones
     rapidas mediante credenciales Code 128 cuyo secreto nunca se almacena.
   - Los tres roles iniciales son plantillas editables de permisos granulares.
   - El RPO configurado inicialmente es 30 minutos y el RTO es 120 minutos.
   - __EFMigrationsHistory no se crea aqui; EF Core la administra al aplicar
     migraciones.

 Este script esta pensado para una base vacia. No contiene DROP ni elimina datos.
===============================================================================
*/

BEGIN;

SET LOCAL TIME ZONE 'UTC';

-- =============================================================================
-- 1. ESQUEMAS
-- =============================================================================

CREATE SCHEMA seguridad;
CREATE SCHEMA configuracion;
CREATE SCHEMA catalogo;
CREATE SCHEMA caja;
CREATE SCHEMA ventas;
CREATE SCHEMA compras;
CREATE SCHEMA auditoria;

COMMENT ON SCHEMA seguridad IS 'Autenticacion, usuarios, roles, permisos y autorizaciones.';
COMMENT ON SCHEMA configuracion IS 'Configuracion del establecimiento, instalaciones y operacion tecnica.';
COMMENT ON SCHEMA catalogo IS 'Catalogos y maestros comerciales.';
COMMENT ON SCHEMA caja IS 'Cajas, turnos y movimientos de efectivo.';
COMMENT ON SCHEMA ventas IS 'Ventas, creditos, apartados, pagos y cambios.';
COMMENT ON SCHEMA compras IS 'Compras y movimientos de inventario.';
COMMENT ON SCHEMA auditoria IS 'Auditoria de negocio e idempotencia de operaciones.';

-- =============================================================================
-- 2. CONFIGURACION BASE
-- =============================================================================

CREATE TABLE configuracion.establecimiento (
    id                       uuid           NOT NULL,
    nombre_comercial         varchar(200)   NOT NULL,
    identificacion           varchar(30)    NOT NULL,
    direccion                varchar(300),
    telefono                 varchar(30),
    zona_horaria             varchar(100)   NOT NULL DEFAULT 'America/Bogota',
    iva_predeterminado       numeric(5,2),
    dias_limite_apartado     integer,
    porcentaje_minimo_apartado numeric(5,2) NOT NULL DEFAULT 20,
    dias_limite_cambio       integer        NOT NULL DEFAULT 15,
    modo_turno_predeterminado varchar(20)   NOT NULL DEFAULT 'INDIVIDUAL',
    rpo_minutos              integer        NOT NULL DEFAULT 30,
    rto_minutos              integer        NOT NULL DEFAULT 120,
    dias_prueba_restauracion integer        NOT NULL DEFAULT 90,
    encabezado_comprobante   text,
    pie_comprobante          text,
    activo                   boolean        NOT NULL DEFAULT true,
    fecha_creacion           timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion       timestamptz,
    version                  bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_establecimiento PRIMARY KEY (id),
    CONSTRAINT uq_establecimiento_identificacion UNIQUE (identificacion),
    CONSTRAINT ck_establecimiento_nombre CHECK (btrim(nombre_comercial) <> ''),
    CONSTRAINT ck_establecimiento_identificacion CHECK (btrim(identificacion) <> ''),
    CONSTRAINT ck_establecimiento_zona CHECK (btrim(zona_horaria) <> ''),
    CONSTRAINT ck_establecimiento_iva CHECK (
        iva_predeterminado IS NULL OR iva_predeterminado BETWEEN 0 AND 100
    ),
    CONSTRAINT ck_establecimiento_dias_apartado CHECK (
        dias_limite_apartado IS NULL OR dias_limite_apartado > 0
    ),
    CONSTRAINT ck_establecimiento_porcentaje_apartado CHECK (
        porcentaje_minimo_apartado > 0 AND porcentaje_minimo_apartado <= 100
    ),
    CONSTRAINT ck_establecimiento_dias_cambio CHECK (dias_limite_cambio > 0),
    CONSTRAINT ck_establecimiento_modo_turno CHECK (
        modo_turno_predeterminado IN ('INDIVIDUAL', 'COMPARTIDO')
    ),
    CONSTRAINT ck_establecimiento_recuperacion CHECK (
        rpo_minutos > 0
        AND rto_minutos > 0
        AND dias_prueba_restauracion > 0
    ),
    CONSTRAINT ck_establecimiento_version CHECK (version > 0)
);

CREATE TABLE configuracion.instalacion (
    id                    uuid           NOT NULL,
    establecimiento_id    uuid           NOT NULL,
    codigo                varchar(50)    NOT NULL,
    serie                 varchar(10)    NOT NULL,
    fecha_instalacion     timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version_aplicacion    varchar(50)    NOT NULL,
    version_esquema       varchar(100)   NOT NULL,
    activo                boolean        NOT NULL DEFAULT true,
    version               bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_instalacion PRIMARY KEY (id),
    CONSTRAINT uq_instalacion_codigo UNIQUE (codigo),
    CONSTRAINT fk_instalacion_establecimiento
        FOREIGN KEY (establecimiento_id)
        REFERENCES configuracion.establecimiento (id) ON DELETE RESTRICT,
    CONSTRAINT ck_instalacion_codigo CHECK (btrim(codigo) <> ''),
    CONSTRAINT ck_instalacion_serie CHECK (btrim(serie) <> ''),
    CONSTRAINT ck_instalacion_version CHECK (version > 0)
);

CREATE TABLE configuracion.terminal (
    id                    uuid           NOT NULL,
    instalacion_id        uuid           NOT NULL,
    codigo                varchar(50)    NOT NULL,
    nombre                varchar(100)   NOT NULL,
    activo                boolean        NOT NULL DEFAULT true,
    fecha_creacion        timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion    timestamptz,
    version               bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_terminal PRIMARY KEY (id),
    CONSTRAINT uq_terminal_instalacion_codigo UNIQUE (instalacion_id, codigo),
    CONSTRAINT fk_terminal_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_terminal_codigo CHECK (btrim(codigo) <> ''),
    CONSTRAINT ck_terminal_nombre CHECK (btrim(nombre) <> ''),
    CONSTRAINT ck_terminal_version CHECK (version > 0)
);

CREATE TABLE configuracion.motivo_operacion (
    id                    uuid           NOT NULL,
    establecimiento_id    uuid           NOT NULL,
    tipo_operacion        varchar(40)    NOT NULL,
    codigo                varchar(50)    NOT NULL,
    nombre                varchar(150)   NOT NULL,
    descripcion           varchar(500),
    orden_visual          integer        NOT NULL DEFAULT 0,
    activo                boolean        NOT NULL DEFAULT true,
    fecha_creacion        timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion    timestamptz,
    version               bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_motivo_operacion PRIMARY KEY (id),
    CONSTRAINT uq_motivo_operacion_tipo_codigo
        UNIQUE (establecimiento_id, tipo_operacion, codigo),
    CONSTRAINT fk_motivo_operacion_establecimiento
        FOREIGN KEY (establecimiento_id)
        REFERENCES configuracion.establecimiento (id) ON DELETE RESTRICT,
    CONSTRAINT ck_motivo_operacion_tipo CHECK (
        tipo_operacion IN (
            'ANULACION_VENTA', 'ANULACION_PAGO', 'ANULACION_COMPRA',
            'ANULACION_CAMBIO',
            'DIFERENCIA_CIERRE', 'CANCELACION_APARTADO',
            'CIERRE_PEDIDO_PENDIENTE', 'CANCELACION_PEDIDO',
            'AJUSTE_INVENTARIO'
        )
    ),
    CONSTRAINT ck_motivo_operacion_codigo CHECK (btrim(codigo) <> ''),
    CONSTRAINT ck_motivo_operacion_nombre CHECK (btrim(nombre) <> ''),
    CONSTRAINT ck_motivo_operacion_orden CHECK (orden_visual >= 0),
    CONSTRAINT ck_motivo_operacion_version CHECK (version > 0)
);

-- =============================================================================
-- 3. SEGURIDAD, IDENTIDAD Y AUTORIZACION
-- =============================================================================

CREATE TABLE seguridad.usuario (
    id                           uuid           NOT NULL,
    nombre_usuario               varchar(100)   NOT NULL,
    nombre_usuario_normalizado   varchar(100)   NOT NULL,
    nombre_completo              varchar(200)   NOT NULL,
    correo                       varchar(254),
    password_hash                text           NOT NULL,
    sello_seguridad              varchar(100)   NOT NULL,
    sello_concurrencia           varchar(100)   NOT NULL,
    activo                       boolean        NOT NULL DEFAULT true,
    intentos_fallidos            integer        NOT NULL DEFAULT 0,
    bloqueo_hasta                timestamptz,
    ultimo_acceso                timestamptz,
    fecha_creacion               timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion           timestamptz,
    version                      bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_usuario PRIMARY KEY (id),
    CONSTRAINT uq_usuario_nombre UNIQUE (nombre_usuario),
    CONSTRAINT uq_usuario_nombre_normalizado UNIQUE (nombre_usuario_normalizado),
    CONSTRAINT ck_usuario_nombre CHECK (btrim(nombre_usuario) <> ''),
    CONSTRAINT ck_usuario_nombre_normalizado CHECK (btrim(nombre_usuario_normalizado) <> ''),
    CONSTRAINT ck_usuario_nombre_completo CHECK (btrim(nombre_completo) <> ''),
    CONSTRAINT ck_usuario_intentos CHECK (intentos_fallidos >= 0),
    CONSTRAINT ck_usuario_version CHECK (version > 0)
);

CREATE TABLE seguridad.rol (
    id                    uuid           NOT NULL,
    codigo                varchar(50)    NOT NULL,
    nombre                varchar(100)   NOT NULL,
    descripcion           varchar(500),
    es_predefinido        boolean        NOT NULL DEFAULT false,
    permisos_editables    boolean        NOT NULL DEFAULT true,
    activo                boolean        NOT NULL DEFAULT true,
    fecha_creacion        timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion    timestamptz,
    version               bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_rol PRIMARY KEY (id),
    CONSTRAINT uq_rol_codigo UNIQUE (codigo),
    CONSTRAINT uq_rol_nombre UNIQUE (nombre),
    CONSTRAINT ck_rol_codigo CHECK (btrim(codigo) <> ''),
    CONSTRAINT ck_rol_nombre CHECK (btrim(nombre) <> ''),
    CONSTRAINT ck_rol_predefinido CHECK (
        es_predefinido = false
        OR codigo IN ('ADMINISTRADOR', 'SUPERVISOR', 'CAJERO')
    ),
    CONSTRAINT ck_rol_version CHECK (version > 0)
);

CREATE TABLE seguridad.permiso (
    id                    uuid           NOT NULL,
    codigo                varchar(100)   NOT NULL,
    nombre                varchar(150)   NOT NULL,
    descripcion           varchar(500),
    modulo                varchar(50)    NOT NULL,
    activo                boolean        NOT NULL DEFAULT true,
    fecha_creacion        timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT pk_permiso PRIMARY KEY (id),
    CONSTRAINT uq_permiso_codigo UNIQUE (codigo),
    CONSTRAINT ck_permiso_codigo CHECK (btrim(codigo) <> ''),
    CONSTRAINT ck_permiso_nombre CHECK (btrim(nombre) <> ''),
    CONSTRAINT ck_permiso_modulo CHECK (btrim(modulo) <> '')
);

CREATE TABLE seguridad.usuario_rol (
    usuario_id          uuid          NOT NULL,
    rol_id              uuid          NOT NULL,
    asignado_por_id     uuid,
    fecha_asignacion    timestamptz   NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT pk_usuario_rol PRIMARY KEY (usuario_id, rol_id),
    CONSTRAINT uq_usuario_rol_usuario UNIQUE (usuario_id),
    CONSTRAINT fk_usuario_rol_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_usuario_rol_rol
        FOREIGN KEY (rol_id)
        REFERENCES seguridad.rol (id) ON DELETE RESTRICT,
    CONSTRAINT fk_usuario_rol_asignado_por
        FOREIGN KEY (asignado_por_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT
);

CREATE TABLE seguridad.rol_permiso (
    rol_id              uuid          NOT NULL,
    permiso_id          uuid          NOT NULL,
    fecha_asignacion    timestamptz   NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT pk_rol_permiso PRIMARY KEY (rol_id, permiso_id),
    CONSTRAINT fk_rol_permiso_rol
        FOREIGN KEY (rol_id)
        REFERENCES seguridad.rol (id) ON DELETE RESTRICT,
    CONSTRAINT fk_rol_permiso_permiso
        FOREIGN KEY (permiso_id)
        REFERENCES seguridad.permiso (id) ON DELETE RESTRICT
);

CREATE TABLE seguridad.limite_operacion_rol (
    id                    uuid           NOT NULL,
    rol_id                uuid           NOT NULL,
    codigo_operacion      varchar(100)   NOT NULL,
    tipo_limite           varchar(20)    NOT NULL,
    valor_maximo          numeric(18,4)  NOT NULL,
    activo                boolean        NOT NULL DEFAULT true,
    fecha_creacion        timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion    timestamptz,
    version               bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_limite_operacion_rol PRIMARY KEY (id),
    CONSTRAINT uq_limite_operacion_rol
        UNIQUE (rol_id, codigo_operacion),
    CONSTRAINT fk_limite_operacion_rol_rol
        FOREIGN KEY (rol_id)
        REFERENCES seguridad.rol (id) ON DELETE RESTRICT,
    CONSTRAINT ck_limite_operacion_codigo CHECK (btrim(codigo_operacion) <> ''),
    CONSTRAINT ck_limite_operacion_tipo
        CHECK (tipo_limite IN ('PORCENTAJE', 'VALOR')),
    CONSTRAINT ck_limite_operacion_valor CHECK (valor_maximo >= 0),
    CONSTRAINT ck_limite_operacion_version CHECK (version > 0)
);

CREATE TABLE seguridad.credencial_usuario (
    id                    uuid           NOT NULL,
    usuario_id            uuid           NOT NULL,
    token_hash            varchar(128)   NOT NULL,
    fragmento_visible     varchar(12)    NOT NULL,
    formato_codigo        varchar(20)    NOT NULL DEFAULT 'CODE128',
    estado                varchar(20)    NOT NULL DEFAULT 'ACTIVA',
    emitida_por_id        uuid           NOT NULL,
    revocada_por_id       uuid,
    fecha_emision         timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_vencimiento     timestamptz,
    fecha_revocacion      timestamptz,
    motivo_revocacion     text,
    version               bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_credencial_usuario PRIMARY KEY (id),
    CONSTRAINT uq_credencial_usuario_hash UNIQUE (token_hash),
    CONSTRAINT fk_credencial_usuario_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_credencial_usuario_emisor
        FOREIGN KEY (emitida_por_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_credencial_usuario_revocador
        FOREIGN KEY (revocada_por_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT ck_credencial_usuario_hash CHECK (btrim(token_hash) <> ''),
    CONSTRAINT ck_credencial_usuario_fragmento CHECK (btrim(fragmento_visible) <> ''),
    CONSTRAINT ck_credencial_usuario_formato CHECK (formato_codigo = 'CODE128'),
    CONSTRAINT ck_credencial_usuario_estado
        CHECK (estado IN ('ACTIVA', 'REVOCADA', 'VENCIDA')),
    CONSTRAINT ck_credencial_usuario_vencimiento CHECK (
        fecha_vencimiento IS NULL OR fecha_vencimiento > fecha_emision
    ),
    CONSTRAINT ck_credencial_usuario_revocacion CHECK (
        (
            estado = 'ACTIVA'
            AND revocada_por_id IS NULL
            AND fecha_revocacion IS NULL
            AND motivo_revocacion IS NULL
        )
        OR
        (
            estado IN ('REVOCADA', 'VENCIDA')
            AND fecha_revocacion IS NOT NULL
            AND fecha_revocacion >= fecha_emision
        )
    ),
    CONSTRAINT ck_credencial_usuario_version CHECK (version > 0)
);

CREATE TABLE seguridad.autorizacion_operacion (
    id                         uuid           NOT NULL,
    usuario_solicitante_id     uuid           NOT NULL,
    usuario_autorizador_id     uuid,
    credencial_autorizador_id  uuid,
    permiso_id                 uuid           NOT NULL,
    tipo_operacion             varchar(100)   NOT NULL,
    correlacion_id             uuid           NOT NULL,
    descripcion_operacion      text           NOT NULL,
    motivo                     text,
    metodo_autenticacion       varchar(30),
    resultado                  varchar(20),
    estado                     varchar(20)    NOT NULL DEFAULT 'PENDIENTE',
    fecha_solicitud            timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_expiracion           timestamptz    NOT NULL,
    fecha_utilizacion          timestamptz,

    CONSTRAINT pk_autorizacion_operacion PRIMARY KEY (id),
    CONSTRAINT fk_autorizacion_solicitante
        FOREIGN KEY (usuario_solicitante_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_autorizacion_autorizador
        FOREIGN KEY (usuario_autorizador_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_autorizacion_permiso
        FOREIGN KEY (permiso_id)
        REFERENCES seguridad.permiso (id) ON DELETE RESTRICT,
    CONSTRAINT fk_autorizacion_credencial
        FOREIGN KEY (credencial_autorizador_id)
        REFERENCES seguridad.credencial_usuario (id) ON DELETE RESTRICT,
    CONSTRAINT ck_autorizacion_tipo CHECK (btrim(tipo_operacion) <> ''),
    CONSTRAINT ck_autorizacion_descripcion CHECK (btrim(descripcion_operacion) <> ''),
    CONSTRAINT ck_autorizacion_motivo CHECK (motivo IS NULL OR btrim(motivo) <> ''),
    CONSTRAINT ck_autorizacion_metodo CHECK (
        metodo_autenticacion IS NULL
        OR metodo_autenticacion IN ('PASSWORD', 'CODIGO_BARRAS_PIN')
    ),
    CONSTRAINT ck_autorizacion_resultado
        CHECK (resultado IS NULL OR resultado IN ('EXITOSA', 'FALLIDA')),
    CONSTRAINT ck_autorizacion_estado
        CHECK (estado IN ('PENDIENTE', 'AUTORIZADA', 'RECHAZADA', 'EXPIRADA', 'UTILIZADA')),
    CONSTRAINT ck_autorizacion_metodo_credencial CHECK (
        (metodo_autenticacion IS NOT NULL
         AND metodo_autenticacion = 'CODIGO_BARRAS_PIN'
         AND credencial_autorizador_id IS NOT NULL)
        OR
        (metodo_autenticacion IS DISTINCT FROM 'CODIGO_BARRAS_PIN'
         AND credencial_autorizador_id IS NULL)
    ),
    CONSTRAINT ck_autorizacion_transicion CHECK (
        (
            estado = 'PENDIENTE'
            AND usuario_autorizador_id IS NULL
            AND metodo_autenticacion IS NULL
            AND resultado IS NULL
            AND fecha_utilizacion IS NULL
        )
        OR
        (
            estado = 'AUTORIZADA'
            AND usuario_autorizador_id IS NOT NULL
            AND metodo_autenticacion IS NOT NULL
            AND resultado IS NOT NULL
            AND resultado = 'EXITOSA'
            AND fecha_utilizacion IS NULL
        )
        OR
        (
            estado = 'RECHAZADA'
            AND usuario_autorizador_id IS NOT NULL
            AND metodo_autenticacion IS NOT NULL
            AND resultado IS NOT NULL
            AND resultado = 'FALLIDA'
            AND fecha_utilizacion IS NULL
        )
        OR
        (
            estado = 'EXPIRADA'
            AND resultado IS NULL
            AND fecha_utilizacion IS NULL
        )
        OR
        (
            estado = 'UTILIZADA'
            AND usuario_autorizador_id IS NOT NULL
            AND metodo_autenticacion IS NOT NULL
            AND resultado IS NOT NULL
            AND resultado = 'EXITOSA'
            AND fecha_utilizacion IS NOT NULL
        )
    ),
    CONSTRAINT ck_autorizacion_expiracion
        CHECK (fecha_expiracion > fecha_solicitud),
    CONSTRAINT ck_autorizacion_utilizacion
        CHECK (fecha_utilizacion IS NULL OR fecha_utilizacion >= fecha_solicitud)
);

CREATE TABLE seguridad.usuario_claim (
    id              uuid           NOT NULL,
    usuario_id      uuid           NOT NULL,
    tipo_claim      varchar(100)   NOT NULL,
    valor_claim     text           NOT NULL,

    CONSTRAINT pk_usuario_claim PRIMARY KEY (id),
    CONSTRAINT fk_usuario_claim_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT ck_usuario_claim_tipo CHECK (btrim(tipo_claim) <> ''),
    CONSTRAINT ck_usuario_claim_valor CHECK (btrim(valor_claim) <> '')
);

CREATE TABLE seguridad.rol_claim (
    id              uuid           NOT NULL,
    rol_id          uuid           NOT NULL,
    tipo_claim      varchar(100)   NOT NULL,
    valor_claim     text           NOT NULL,

    CONSTRAINT pk_rol_claim PRIMARY KEY (id),
    CONSTRAINT fk_rol_claim_rol
        FOREIGN KEY (rol_id)
        REFERENCES seguridad.rol (id) ON DELETE RESTRICT,
    CONSTRAINT ck_rol_claim_tipo CHECK (btrim(tipo_claim) <> ''),
    CONSTRAINT ck_rol_claim_valor CHECK (btrim(valor_claim) <> '')
);

CREATE TABLE seguridad.usuario_login (
    proveedor_login     varchar(100)   NOT NULL,
    clave_proveedor     varchar(200)   NOT NULL,
    usuario_id          uuid           NOT NULL,
    nombre_proveedor    varchar(200),

    CONSTRAINT pk_usuario_login PRIMARY KEY (proveedor_login, clave_proveedor),
    CONSTRAINT fk_usuario_login_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT ck_usuario_login_proveedor CHECK (btrim(proveedor_login) <> ''),
    CONSTRAINT ck_usuario_login_clave CHECK (btrim(clave_proveedor) <> '')
);

CREATE TABLE seguridad.usuario_token (
    usuario_id          uuid           NOT NULL,
    proveedor_login     varchar(100)   NOT NULL,
    nombre_token        varchar(100)   NOT NULL,
    valor_token         text,

    CONSTRAINT pk_usuario_token PRIMARY KEY (usuario_id, proveedor_login, nombre_token),
    CONSTRAINT fk_usuario_token_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT ck_usuario_token_proveedor CHECK (btrim(proveedor_login) <> ''),
    CONSTRAINT ck_usuario_token_nombre CHECK (btrim(nombre_token) <> '')
);

-- =============================================================================
-- 4. CONFIGURACION OPERATIVA
-- =============================================================================

CREATE TABLE configuracion.consecutivo_documento (
    id                  uuid           NOT NULL,
    instalacion_id      uuid           NOT NULL,
    tipo_documento      varchar(30)    NOT NULL,
    prefijo             varchar(10)    NOT NULL,
    serie               varchar(10)    NOT NULL,
    ultimo_numero       bigint         NOT NULL DEFAULT 0,
    version             bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_consecutivo_documento PRIMARY KEY (id),
    CONSTRAINT uq_consecutivo_inst_tipo_serie
        UNIQUE (instalacion_id, tipo_documento, serie),
    CONSTRAINT fk_consecutivo_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_consecutivo_tipo
        CHECK (tipo_documento IN (
            'VENTA', 'COMPRA', 'APARTADO', 'PAGO_CREDITO',
            'PAGO_APARTADO', 'CAMBIO_VENTA', 'PEDIDO_COMPRA'
        )),
    CONSTRAINT ck_consecutivo_prefijo CHECK (btrim(prefijo) <> ''),
    CONSTRAINT ck_consecutivo_serie CHECK (btrim(serie) <> ''),
    CONSTRAINT ck_consecutivo_numero CHECK (ultimo_numero >= 0),
    CONSTRAINT ck_consecutivo_version CHECK (version > 0)
);

CREATE TABLE configuracion.destino_respaldo (
    id                         uuid           NOT NULL,
    instalacion_id             uuid           NOT NULL,
    nombre                     varchar(150)   NOT NULL,
    tipo_destino               varchar(30)    NOT NULL,
    ubicacion_base             text           NOT NULL,
    requiere_cifrado           boolean        NOT NULL DEFAULT false,
    referencia_secreto         varchar(200),
    retencion_diaria           integer        NOT NULL DEFAULT 7,
    retencion_semanal          integer        NOT NULL DEFAULT 4,
    retencion_mensual          integer        NOT NULL DEFAULT 12,
    conservar_pre_actualizacion boolean       NOT NULL DEFAULT true,
    activo                     boolean        NOT NULL DEFAULT true,
    fecha_creacion             timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion         timestamptz,
    version                    bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_destino_respaldo PRIMARY KEY (id),
    CONSTRAINT uq_destino_respaldo_nombre UNIQUE (instalacion_id, nombre),
    CONSTRAINT fk_destino_respaldo_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_destino_respaldo_nombre CHECK (btrim(nombre) <> ''),
    CONSTRAINT ck_destino_respaldo_tipo CHECK (
        tipo_destino IN ('LOCAL_FISICO_SEPARADO', 'EXTERNO_CIFRADO')
    ),
    CONSTRAINT ck_destino_respaldo_ubicacion CHECK (btrim(ubicacion_base) <> ''),
    CONSTRAINT ck_destino_respaldo_cifrado CHECK (
        tipo_destino <> 'EXTERNO_CIFRADO' OR requiere_cifrado = true
    ),
    CONSTRAINT ck_destino_respaldo_retencion CHECK (
        retencion_diaria >= 1
        AND retencion_semanal >= 0
        AND retencion_mensual >= 0
    ),
    CONSTRAINT ck_destino_respaldo_version CHECK (version > 0)
);

CREATE TABLE configuracion.ejecucion_respaldo (
    id                      uuid           NOT NULL,
    instalacion_id          uuid           NOT NULL,
    fecha_inicio            timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_fin               timestamptz,
    estrategia              varchar(30)    NOT NULL,
    disparador              varchar(30)    NOT NULL,
    resultado               varchar(20)    NOT NULL DEFAULT 'EN_PROCESO',
    tamano_bytes            bigint,
    hash_integridad         varchar(128),
    ruta_artefacto_local    text,
    inicio_wal              varchar(64),
    fin_wal                 varchar(64),
    error_sanitizado        text,

    CONSTRAINT pk_ejecucion_respaldo PRIMARY KEY (id),
    CONSTRAINT fk_respaldo_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_respaldo_estrategia
        CHECK (estrategia IN ('WAL_CONTINUO', 'BASE_FISICO', 'LOGICO_PG_DUMP')),
    CONSTRAINT ck_respaldo_disparador CHECK (
        disparador IN (
            'CONTINUO', 'PROGRAMADO', 'CIERRE_CAJA',
            'PRE_ACTUALIZACION', 'MANUAL'
        )
    ),
    CONSTRAINT ck_respaldo_resultado
        CHECK (resultado IN ('EN_PROCESO', 'EXITOSO', 'FALLIDO')),
    CONSTRAINT ck_respaldo_tamano CHECK (tamano_bytes IS NULL OR tamano_bytes >= 0),
    CONSTRAINT ck_respaldo_fechas CHECK (fecha_fin IS NULL OR fecha_fin >= fecha_inicio),
    CONSTRAINT ck_respaldo_completado CHECK (
        resultado = 'EN_PROCESO'
        OR fecha_fin IS NOT NULL
    )
);

CREATE TABLE configuracion.copia_respaldo (
    id                      uuid           NOT NULL,
    ejecucion_respaldo_id   uuid           NOT NULL,
    destino_respaldo_id     uuid           NOT NULL,
    estado                  varchar(20)    NOT NULL DEFAULT 'PENDIENTE',
    intentos                integer        NOT NULL DEFAULT 0,
    ubicacion_final         text,
    cifrado                 boolean        NOT NULL DEFAULT false,
    hash_verificado         boolean        NOT NULL DEFAULT false,
    fecha_ultimo_intento    timestamptz,
    fecha_completada        timestamptz,
    error_sanitizado        text,

    CONSTRAINT pk_copia_respaldo PRIMARY KEY (id),
    CONSTRAINT uq_copia_respaldo_ejecucion_destino
        UNIQUE (ejecucion_respaldo_id, destino_respaldo_id),
    CONSTRAINT fk_copia_respaldo_ejecucion
        FOREIGN KEY (ejecucion_respaldo_id)
        REFERENCES configuracion.ejecucion_respaldo (id) ON DELETE RESTRICT,
    CONSTRAINT fk_copia_respaldo_destino
        FOREIGN KEY (destino_respaldo_id)
        REFERENCES configuracion.destino_respaldo (id) ON DELETE RESTRICT,
    CONSTRAINT ck_copia_respaldo_estado
        CHECK (estado IN ('PENDIENTE', 'ENVIANDO', 'COMPLETADA', 'FALLIDA')),
    CONSTRAINT ck_copia_respaldo_intentos CHECK (intentos >= 0),
    CONSTRAINT ck_copia_respaldo_completada CHECK (
        (estado = 'COMPLETADA'
         AND fecha_completada IS NOT NULL
         AND ubicacion_final IS NOT NULL
         AND btrim(ubicacion_final) <> ''
         AND hash_verificado = true)
        OR estado <> 'COMPLETADA'
    )
);

CREATE TABLE configuracion.prueba_restauracion (
    id                      uuid           NOT NULL,
    copia_respaldo_id       uuid           NOT NULL,
    ejecutada_por_id        uuid           NOT NULL,
    autorizacion_operacion_id uuid         NOT NULL,
    fecha_inicio            timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_fin               timestamptz,
    resultado               varchar(20)    NOT NULL DEFAULT 'EN_PROCESO',
    rpo_observado_minutos   integer,
    rto_observado_minutos   integer,
    integridad_verificada   boolean        NOT NULL DEFAULT false,
    aplicacion_verificada   boolean        NOT NULL DEFAULT false,
    observaciones           text,
    error_sanitizado        text,

    CONSTRAINT pk_prueba_restauracion PRIMARY KEY (id),
    CONSTRAINT fk_prueba_restauracion_copia
        FOREIGN KEY (copia_respaldo_id)
        REFERENCES configuracion.copia_respaldo (id) ON DELETE RESTRICT,
    CONSTRAINT fk_prueba_restauracion_usuario
        FOREIGN KEY (ejecutada_por_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_prueba_restauracion_autorizacion
        FOREIGN KEY (autorizacion_operacion_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_prueba_restauracion_resultado
        CHECK (resultado IN ('EN_PROCESO', 'EXITOSA', 'FALLIDA')),
    CONSTRAINT ck_prueba_restauracion_metricas CHECK (
        (rpo_observado_minutos IS NULL OR rpo_observado_minutos >= 0)
        AND (rto_observado_minutos IS NULL OR rto_observado_minutos >= 0)
    ),
    CONSTRAINT ck_prueba_restauracion_fechas CHECK (
        fecha_fin IS NULL OR fecha_fin >= fecha_inicio
    ),
    CONSTRAINT ck_prueba_restauracion_final CHECK (
        resultado = 'EN_PROCESO' OR fecha_fin IS NOT NULL
    )
);

CREATE TABLE configuracion.perfil_impresora (
    id                    uuid           NOT NULL,
    terminal_id           uuid           NOT NULL,
    nombre                varchar(150)   NOT NULL,
    tipo_impresora        varchar(20)    NOT NULL,
    nombre_sistema        varchar(300)   NOT NULL,
    ancho_mm              numeric(8,2),
    alto_mm               numeric(8,2),
    resolucion_dpi        integer,
    es_predeterminada     boolean        NOT NULL DEFAULT false,
    activo                boolean        NOT NULL DEFAULT true,
    fecha_creacion        timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion    timestamptz,
    version               bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_perfil_impresora PRIMARY KEY (id),
    CONSTRAINT uq_perfil_impresora_nombre UNIQUE (terminal_id, nombre),
    CONSTRAINT fk_perfil_impresora_terminal
        FOREIGN KEY (terminal_id)
        REFERENCES configuracion.terminal (id) ON DELETE RESTRICT,
    CONSTRAINT ck_perfil_impresora_nombre CHECK (btrim(nombre) <> ''),
    CONSTRAINT ck_perfil_impresora_sistema CHECK (btrim(nombre_sistema) <> ''),
    CONSTRAINT ck_perfil_impresora_tipo
        CHECK (tipo_impresora IN ('RECIBOS', 'ETIQUETAS', 'HIBRIDA')),
    CONSTRAINT ck_perfil_impresora_dimensiones CHECK (
        (ancho_mm IS NULL OR ancho_mm > 0)
        AND (alto_mm IS NULL OR alto_mm > 0)
        AND (resolucion_dpi IS NULL OR resolucion_dpi > 0)
    ),
    CONSTRAINT ck_perfil_impresora_version CHECK (version > 0)
);

CREATE TABLE configuracion.plantilla_impresion (
    id                    uuid           NOT NULL,
    establecimiento_id    uuid           NOT NULL,
    codigo                varchar(50)    NOT NULL,
    nombre                varchar(150)   NOT NULL,
    tipo_salida           varchar(30)    NOT NULL,
    formato_codigo        varchar(20),
    ancho_mm              numeric(8,2),
    alto_mm               numeric(8,2),
    configuracion         jsonb          NOT NULL DEFAULT '{}'::jsonb,
    activa                boolean        NOT NULL DEFAULT true,
    fecha_creacion        timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion    timestamptz,
    version               bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_plantilla_impresion PRIMARY KEY (id),
    CONSTRAINT uq_plantilla_impresion_codigo
        UNIQUE (establecimiento_id, codigo),
    CONSTRAINT fk_plantilla_impresion_establecimiento
        FOREIGN KEY (establecimiento_id)
        REFERENCES configuracion.establecimiento (id) ON DELETE RESTRICT,
    CONSTRAINT ck_plantilla_impresion_codigo CHECK (btrim(codigo) <> ''),
    CONSTRAINT ck_plantilla_impresion_nombre CHECK (btrim(nombre) <> ''),
    CONSTRAINT ck_plantilla_impresion_tipo CHECK (
        tipo_salida IN ('COMPROBANTE', 'ETIQUETA_PRODUCTO', 'CREDENCIAL_USUARIO')
    ),
    CONSTRAINT ck_plantilla_impresion_formato CHECK (
        (tipo_salida = 'COMPROBANTE' AND formato_codigo IS NULL)
        OR
        (tipo_salida IN ('ETIQUETA_PRODUCTO', 'CREDENCIAL_USUARIO')
         AND formato_codigo IS NOT NULL
         AND formato_codigo = 'CODE128')
    ),
    CONSTRAINT ck_plantilla_impresion_dimensiones CHECK (
        (ancho_mm IS NULL OR ancho_mm > 0)
        AND (alto_mm IS NULL OR alto_mm > 0)
    ),
    CONSTRAINT ck_plantilla_impresion_version CHECK (version > 0)
);

-- =============================================================================
-- 5. CATALOGOS Y MAESTROS
-- =============================================================================

CREATE TABLE catalogo.metodo_pago (
    id                    uuid           NOT NULL,
    codigo                varchar(50)    NOT NULL,
    nombre                varchar(100)   NOT NULL,
    afecta_efectivo       boolean        NOT NULL DEFAULT false,
    requiere_referencia   boolean        NOT NULL DEFAULT false,
    orden_visual          integer        NOT NULL DEFAULT 0,
    activo                boolean        NOT NULL DEFAULT true,
    fecha_creacion        timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version               bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_metodo_pago PRIMARY KEY (id),
    CONSTRAINT uq_metodo_pago_codigo UNIQUE (codigo),
    CONSTRAINT ck_metodo_pago_codigo CHECK (btrim(codigo) <> ''),
    CONSTRAINT ck_metodo_pago_nombre CHECK (btrim(nombre) <> ''),
    CONSTRAINT ck_metodo_pago_orden CHECK (orden_visual >= 0),
    CONSTRAINT ck_metodo_pago_version CHECK (version > 0)
);

CREATE TABLE catalogo.categoria (
    id                       uuid           NOT NULL,
    nombre                   varchar(100)   NOT NULL,
    descripcion              varchar(500),
    activo                   boolean        NOT NULL DEFAULT true,
    usuario_creacion_id      uuid           NOT NULL,
    usuario_modificacion_id  uuid,
    fecha_creacion           timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion       timestamptz,
    version                  bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_categoria PRIMARY KEY (id),
    CONSTRAINT uq_categoria_nombre UNIQUE (nombre),
    CONSTRAINT fk_categoria_usuario_creacion
        FOREIGN KEY (usuario_creacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_categoria_usuario_modificacion
        FOREIGN KEY (usuario_modificacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT ck_categoria_nombre CHECK (btrim(nombre) <> ''),
    CONSTRAINT ck_categoria_version CHECK (version > 0)
);

CREATE TABLE catalogo.unidad_medida (
    id               uuid           NOT NULL,
    codigo           varchar(30)    NOT NULL,
    nombre           varchar(100)   NOT NULL,
    simbolo          varchar(20)    NOT NULL,
    activo           boolean        NOT NULL DEFAULT true,
    fecha_creacion   timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT pk_unidad_medida PRIMARY KEY (id),
    CONSTRAINT uq_unidad_medida_codigo UNIQUE (codigo),
    CONSTRAINT ck_unidad_codigo CHECK (btrim(codigo) <> ''),
    CONSTRAINT ck_unidad_nombre CHECK (btrim(nombre) <> ''),
    CONSTRAINT ck_unidad_simbolo CHECK (btrim(simbolo) <> '')
);

CREATE TABLE catalogo.producto (
    id                       uuid           NOT NULL,
    categoria_id             uuid           NOT NULL,
    unidad_medida_id         uuid           NOT NULL,
    proveedor_id             uuid,
    codigo_interno           varchar(50)    NOT NULL,
    codigo_barras            varchar(100),
    formato_codigo_barras    varchar(20),
    codigo_barras_generado   boolean        NOT NULL DEFAULT false,
    nombre                   varchar(200)   NOT NULL,
    descripcion              text,
    precio_minorista         numeric(18,0)  NOT NULL,
    precio_mayorista         numeric(18,0),
    costo_promedio           numeric(18,4),
    porcentaje_iva           numeric(5,2),
    stock_actual             integer        NOT NULL DEFAULT 0,
    stock_reservado          integer        NOT NULL DEFAULT 0,
    stock_minimo             integer        NOT NULL DEFAULT 0,
    activo                   boolean        NOT NULL DEFAULT true,
    usuario_creacion_id      uuid           NOT NULL,
    usuario_modificacion_id  uuid,
    fecha_creacion           timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion       timestamptz,
    version                  bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_producto PRIMARY KEY (id),
    CONSTRAINT uq_producto_codigo_interno UNIQUE (codigo_interno),
    CONSTRAINT uq_producto_codigo_barras UNIQUE (codigo_barras),
    CONSTRAINT fk_producto_categoria
        FOREIGN KEY (categoria_id)
        REFERENCES catalogo.categoria (id) ON DELETE RESTRICT,
    CONSTRAINT fk_producto_unidad
        FOREIGN KEY (unidad_medida_id)
        REFERENCES catalogo.unidad_medida (id) ON DELETE RESTRICT,
    CONSTRAINT fk_producto_usuario_creacion
        FOREIGN KEY (usuario_creacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_producto_usuario_modificacion
        FOREIGN KEY (usuario_modificacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT ck_producto_codigo CHECK (btrim(codigo_interno) <> ''),
    CONSTRAINT ck_producto_codigo_barras
        CHECK (codigo_barras IS NULL OR btrim(codigo_barras) <> ''),
    CONSTRAINT ck_producto_formato_codigo CHECK (
        (codigo_barras IS NULL AND formato_codigo_barras IS NULL
         AND codigo_barras_generado = false)
        OR
        (codigo_barras IS NOT NULL
         AND formato_codigo_barras IS NOT NULL
         AND formato_codigo_barras IN ('CODE128', 'EAN13', 'EAN8', 'UPC_A', 'OTRO'))
    ),
    CONSTRAINT ck_producto_nombre CHECK (btrim(nombre) <> ''),
    CONSTRAINT ck_producto_precio_minorista CHECK (precio_minorista >= 0),
    CONSTRAINT ck_producto_precio_mayorista
        CHECK (precio_mayorista IS NULL OR precio_mayorista >= 0),
    CONSTRAINT ck_producto_costo CHECK (costo_promedio IS NULL OR costo_promedio >= 0),
    CONSTRAINT ck_producto_iva CHECK (
        porcentaje_iva IS NULL OR porcentaje_iva BETWEEN 0 AND 100
    ),
    CONSTRAINT ck_producto_stock CHECK (
        stock_actual >= 0
        AND stock_reservado >= 0
        AND stock_reservado <= stock_actual
        AND stock_minimo >= 0
    ),
    CONSTRAINT ck_producto_version CHECK (version > 0)
);

CREATE TABLE catalogo.cliente (
    id                       uuid           NOT NULL,
    tipo_documento           varchar(20),
    numero_documento         varchar(50),
    nombre_completo          varchar(200)   NOT NULL,
    telefono                 varchar(30),
    direccion                varchar(300),
    correo                   varchar(254),
    observaciones            text,
    activo                   boolean        NOT NULL DEFAULT true,
    usuario_creacion_id      uuid           NOT NULL,
    usuario_modificacion_id  uuid,
    fecha_creacion           timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion       timestamptz,
    version                  bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_cliente PRIMARY KEY (id),
    CONSTRAINT uq_cliente_documento UNIQUE (tipo_documento, numero_documento),
    CONSTRAINT fk_cliente_usuario_creacion
        FOREIGN KEY (usuario_creacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_cliente_usuario_modificacion
        FOREIGN KEY (usuario_modificacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT ck_cliente_documento CHECK (
        (tipo_documento IS NULL AND numero_documento IS NULL)
        OR
        (tipo_documento IS NOT NULL
         AND btrim(tipo_documento) <> ''
         AND numero_documento IS NOT NULL
         AND btrim(numero_documento) <> '')
    ),
    CONSTRAINT ck_cliente_nombre CHECK (btrim(nombre_completo) <> ''),
    CONSTRAINT ck_cliente_version CHECK (version > 0)
);

CREATE TABLE catalogo.proveedor (
    id                       uuid           NOT NULL,
    tipo_documento           varchar(20),
    numero_documento         varchar(50),
    nombre_razon_social      varchar(200)   NOT NULL,
    telefono                 varchar(30),
    direccion                varchar(300),
    correo                   varchar(254),
    observaciones            text,
    activo                   boolean        NOT NULL DEFAULT true,
    usuario_creacion_id      uuid           NOT NULL,
    usuario_modificacion_id  uuid,
    fecha_creacion           timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion       timestamptz,
    version                  bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_proveedor PRIMARY KEY (id),
    CONSTRAINT uq_proveedor_documento UNIQUE (tipo_documento, numero_documento),
    CONSTRAINT fk_proveedor_usuario_creacion
        FOREIGN KEY (usuario_creacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_proveedor_usuario_modificacion
        FOREIGN KEY (usuario_modificacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT ck_proveedor_documento CHECK (
        (tipo_documento IS NULL AND numero_documento IS NULL)
        OR
        (tipo_documento IS NOT NULL
         AND btrim(tipo_documento) <> ''
         AND numero_documento IS NOT NULL
         AND btrim(numero_documento) <> '')
    ),
    CONSTRAINT ck_proveedor_nombre CHECK (btrim(nombre_razon_social) <> ''),
    CONSTRAINT ck_proveedor_version CHECK (version > 0)
);

ALTER TABLE catalogo.producto
    ADD CONSTRAINT fk_producto_proveedor
    FOREIGN KEY (proveedor_id)
    REFERENCES catalogo.proveedor (id) ON DELETE RESTRICT;

-- =============================================================================
-- 6. CAJA
-- =============================================================================

CREATE TABLE caja.caja (
    id                    uuid           NOT NULL,
    instalacion_id        uuid           NOT NULL,
    codigo                varchar(50)    NOT NULL,
    nombre                varchar(100)   NOT NULL,
    activo                boolean        NOT NULL DEFAULT true,
    fecha_creacion        timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion    timestamptz,
    version               bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_caja PRIMARY KEY (id),
    CONSTRAINT uq_caja_instalacion_codigo UNIQUE (instalacion_id, codigo),
    CONSTRAINT fk_caja_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_caja_codigo CHECK (btrim(codigo) <> ''),
    CONSTRAINT ck_caja_nombre CHECK (btrim(nombre) <> ''),
    CONSTRAINT ck_caja_version CHECK (version > 0)
);

CREATE TABLE caja.turno_caja (
    id                    uuid           NOT NULL,
    caja_id               uuid           NOT NULL,
    terminal_id           uuid           NOT NULL,
    modo_operacion        varchar(20)    NOT NULL,
    usuario_apertura_id   uuid           NOT NULL,
    usuario_responsable_id uuid,
    usuario_cierre_id     uuid,
    motivo_diferencia_id  uuid,
    fecha_operativa       date           NOT NULL,
    fecha_hora_apertura   timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_hora_cierre     timestamptz,
    monto_inicial         numeric(18,0)  NOT NULL DEFAULT 0,
    efectivo_esperado     numeric(18,0),
    efectivo_contado      numeric(18,0),
    diferencia            numeric(18,0),
    estado                varchar(20)    NOT NULL DEFAULT 'ABIERTA',
    observaciones         text,
    observacion_diferencia text,
    version               bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_turno_caja PRIMARY KEY (id),
    CONSTRAINT fk_turno_caja_caja
        FOREIGN KEY (caja_id)
        REFERENCES caja.caja (id) ON DELETE RESTRICT,
    CONSTRAINT fk_turno_caja_terminal
        FOREIGN KEY (terminal_id)
        REFERENCES configuracion.terminal (id) ON DELETE RESTRICT,
    CONSTRAINT fk_turno_caja_usuario_apertura
        FOREIGN KEY (usuario_apertura_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_turno_caja_usuario_responsable
        FOREIGN KEY (usuario_responsable_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_turno_caja_usuario_cierre
        FOREIGN KEY (usuario_cierre_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_turno_caja_motivo_diferencia
        FOREIGN KEY (motivo_diferencia_id)
        REFERENCES configuracion.motivo_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_turno_caja_modo CHECK (
        (modo_operacion = 'INDIVIDUAL'
         AND usuario_responsable_id IS NOT NULL
         AND usuario_responsable_id = usuario_apertura_id)
        OR
        (modo_operacion = 'COMPARTIDO' AND usuario_responsable_id IS NULL)
    ),
    CONSTRAINT ck_turno_caja_montos CHECK (
        monto_inicial >= 0
        AND (efectivo_esperado IS NULL OR efectivo_esperado >= 0)
        AND (efectivo_contado IS NULL OR efectivo_contado >= 0)
    ),
    CONSTRAINT ck_turno_caja_estado CHECK (estado IN ('ABIERTA', 'CERRADA')),
    CONSTRAINT ck_turno_caja_cierre CHECK (
        (
            estado = 'ABIERTA'
            AND usuario_cierre_id IS NULL
            AND fecha_hora_cierre IS NULL
            AND efectivo_esperado IS NULL
            AND efectivo_contado IS NULL
            AND diferencia IS NULL
            AND motivo_diferencia_id IS NULL
            AND observacion_diferencia IS NULL
        )
        OR
        (
            estado = 'CERRADA'
            AND usuario_cierre_id IS NOT NULL
            AND fecha_hora_cierre IS NOT NULL
            AND fecha_hora_cierre >= fecha_hora_apertura
            AND efectivo_esperado IS NOT NULL
            AND efectivo_contado IS NOT NULL
            AND diferencia IS NOT NULL
        )
    ),
    CONSTRAINT ck_turno_caja_diferencia CHECK (
        diferencia IS NULL OR diferencia = efectivo_contado - efectivo_esperado
    ),
    CONSTRAINT ck_turno_caja_motivo_diferencia CHECK (
        diferencia IS NULL
        OR (diferencia = 0 AND motivo_diferencia_id IS NULL)
        OR (diferencia <> 0 AND motivo_diferencia_id IS NOT NULL)
    ),
    CONSTRAINT ck_turno_caja_version CHECK (version > 0)
);

CREATE TABLE caja.sesion_operador (
    id                    uuid           NOT NULL,
    turno_caja_id         uuid           NOT NULL,
    terminal_id           uuid           NOT NULL,
    usuario_id            uuid           NOT NULL,
    credencial_usuario_id uuid           NOT NULL,
    fecha_inicio          timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_ultimo_uso      timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_fin             timestamptz,
    estado                varchar(20)    NOT NULL DEFAULT 'ACTIVA',
    motivo_cierre         varchar(30),
    correlacion_id        uuid           NOT NULL,

    CONSTRAINT pk_sesion_operador PRIMARY KEY (id),
    CONSTRAINT fk_sesion_operador_turno
        FOREIGN KEY (turno_caja_id)
        REFERENCES caja.turno_caja (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sesion_operador_terminal
        FOREIGN KEY (terminal_id)
        REFERENCES configuracion.terminal (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sesion_operador_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sesion_operador_credencial
        FOREIGN KEY (credencial_usuario_id)
        REFERENCES seguridad.credencial_usuario (id) ON DELETE RESTRICT,
    CONSTRAINT ck_sesion_operador_estado
        CHECK (estado IN ('ACTIVA', 'CERRADA', 'EXPIRADA', 'INTERRUMPIDA')),
    CONSTRAINT ck_sesion_operador_motivo CHECK (
        motivo_cierre IS NULL
        OR motivo_cierre IN (
            'CAMBIO_OPERADOR', 'INACTIVIDAD', 'MANUAL',
            'CIERRE_TURNO', 'RECUPERACION_ENERGIA'
        )
    ),
    CONSTRAINT ck_sesion_operador_fechas CHECK (
        fecha_ultimo_uso >= fecha_inicio
        AND (fecha_fin IS NULL OR fecha_fin >= fecha_inicio)
    ),
    CONSTRAINT ck_sesion_operador_cierre CHECK (
        (estado = 'ACTIVA' AND fecha_fin IS NULL AND motivo_cierre IS NULL)
        OR
        (estado <> 'ACTIVA' AND fecha_fin IS NOT NULL AND motivo_cierre IS NOT NULL)
    )
);

CREATE TABLE caja.movimiento_caja (
    id                         uuid           NOT NULL,
    turno_caja_id              uuid           NOT NULL,
    usuario_id                 uuid           NOT NULL,
    sesion_operador_id         uuid,
    movimiento_revertido_id    uuid,
    tipo                       varchar(20)    NOT NULL,
    categoria_movimiento       varchar(50)    NOT NULL,
    valor                      numeric(18,0)  NOT NULL,
    concepto                   text,
    fecha_hora                 timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    correlacion_id             uuid           NOT NULL,

    CONSTRAINT pk_movimiento_caja PRIMARY KEY (id),
    CONSTRAINT fk_movimiento_caja_turno
        FOREIGN KEY (turno_caja_id)
        REFERENCES caja.turno_caja (id) ON DELETE RESTRICT,
    CONSTRAINT fk_movimiento_caja_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_movimiento_caja_sesion
        FOREIGN KEY (sesion_operador_id)
        REFERENCES caja.sesion_operador (id) ON DELETE RESTRICT,
    CONSTRAINT fk_movimiento_caja_revertido
        FOREIGN KEY (movimiento_revertido_id)
        REFERENCES caja.movimiento_caja (id) ON DELETE RESTRICT,
    CONSTRAINT ck_movimiento_caja_tipo
        CHECK (tipo IN ('APERTURA', 'INGRESO', 'EGRESO', 'REVERSO')),
    CONSTRAINT ck_movimiento_caja_categoria CHECK (btrim(categoria_movimiento) <> ''),
    CONSTRAINT ck_movimiento_caja_valor CHECK (valor > 0),
    CONSTRAINT ck_movimiento_caja_concepto CHECK (
        (categoria_movimiento = 'OTRO'
         AND concepto IS NOT NULL
         AND btrim(concepto) <> '')
        OR
        (categoria_movimiento <> 'OTRO'
         AND (concepto IS NULL OR btrim(concepto) <> ''))
    ),
    CONSTRAINT ck_movimiento_caja_no_autorreferencia
        CHECK (movimiento_revertido_id IS NULL OR movimiento_revertido_id <> id)
);

-- =============================================================================
-- 7. VENTAS, PAGOS, CREDITOS, APARTADOS Y CAMBIOS
-- =============================================================================

CREATE TABLE ventas.borrador_venta (
    id                    uuid           NOT NULL,
    instalacion_id        uuid           NOT NULL,
    terminal_id           uuid           NOT NULL,
    turno_caja_id         uuid           NOT NULL,
    usuario_id            uuid           NOT NULL,
    sesion_operador_id    uuid,
    cliente_id            uuid,
    venta_confirmada_id   uuid,
    tipo_venta            varchar(20)    NOT NULL DEFAULT 'CONTADO',
    ambito_descuento      varchar(20)    NOT NULL DEFAULT 'NINGUNO',
    tipo_descuento        varchar(20),
    valor_descuento_solicitado numeric(18,4),
    motivo_descuento      text,
    estado                varchar(20)    NOT NULL DEFAULT 'ACTIVO',
    fecha_creacion        timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion    timestamptz,
    fecha_cierre          timestamptz,
    correlacion_id        uuid           NOT NULL,
    version               bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_borrador_venta PRIMARY KEY (id),
    CONSTRAINT uq_borrador_venta_confirmada UNIQUE (venta_confirmada_id),
    CONSTRAINT fk_borrador_venta_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_borrador_venta_terminal
        FOREIGN KEY (terminal_id)
        REFERENCES configuracion.terminal (id) ON DELETE RESTRICT,
    CONSTRAINT fk_borrador_venta_turno
        FOREIGN KEY (turno_caja_id)
        REFERENCES caja.turno_caja (id) ON DELETE RESTRICT,
    CONSTRAINT fk_borrador_venta_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_borrador_venta_sesion
        FOREIGN KEY (sesion_operador_id)
        REFERENCES caja.sesion_operador (id) ON DELETE RESTRICT,
    CONSTRAINT fk_borrador_venta_cliente
        FOREIGN KEY (cliente_id)
        REFERENCES catalogo.cliente (id) ON DELETE RESTRICT,
    CONSTRAINT ck_borrador_venta_tipo
        CHECK (tipo_venta IN ('CONTADO', 'CREDITO', 'APARTADO')),
    CONSTRAINT ck_borrador_venta_descuento CHECK (
        (
            ambito_descuento = 'NINGUNO'
            AND tipo_descuento IS NULL
            AND valor_descuento_solicitado IS NULL
            AND motivo_descuento IS NULL
        )
        OR
        (
            ambito_descuento = 'PRODUCTO'
            AND tipo_descuento IS NULL
            AND valor_descuento_solicitado IS NULL
            AND (motivo_descuento IS NULL OR btrim(motivo_descuento) <> '')
        )
        OR
        (
            ambito_descuento = 'VENTA'
            AND tipo_descuento IS NOT NULL
            AND tipo_descuento IN ('PORCENTAJE', 'VALOR_FIJO')
            AND valor_descuento_solicitado IS NOT NULL
            AND valor_descuento_solicitado > 0
            AND (
                tipo_descuento <> 'PORCENTAJE'
                OR valor_descuento_solicitado <= 100
            )
            AND (motivo_descuento IS NULL OR btrim(motivo_descuento) <> '')
        )
    ),
    CONSTRAINT ck_borrador_venta_estado
        CHECK (estado IN ('ACTIVO', 'RECUPERADO', 'DESCARTADO', 'CONVERTIDO')),
    CONSTRAINT ck_borrador_venta_cierre CHECK (
        (estado IN ('ACTIVO', 'RECUPERADO')
         AND fecha_cierre IS NULL
         AND venta_confirmada_id IS NULL)
        OR
        (estado = 'DESCARTADO'
         AND fecha_cierre IS NOT NULL
         AND venta_confirmada_id IS NULL)
        OR
        (estado = 'CONVERTIDO'
         AND fecha_cierre IS NOT NULL
         AND venta_confirmada_id IS NOT NULL)
    ),
    CONSTRAINT ck_borrador_venta_version CHECK (version > 0)
);

CREATE TABLE ventas.detalle_borrador_venta (
    id                       uuid           NOT NULL,
    borrador_venta_id        uuid           NOT NULL,
    producto_id              uuid           NOT NULL,
    cantidad                 integer        NOT NULL,
    tipo_precio              varchar(20)    NOT NULL,
    precio_unitario          numeric(18,0)  NOT NULL,
    tipo_descuento           varchar(20),
    porcentaje_descuento     numeric(5,2),
    valor_descuento          numeric(18,0)  NOT NULL DEFAULT 0,
    orden                    integer        NOT NULL,
    fecha_modificacion       timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version                  bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_detalle_borrador_venta PRIMARY KEY (id),
    CONSTRAINT uq_detalle_borrador_producto
        UNIQUE (borrador_venta_id, producto_id),
    CONSTRAINT uq_detalle_borrador_orden
        UNIQUE (borrador_venta_id, orden),
    CONSTRAINT fk_detalle_borrador_borrador
        FOREIGN KEY (borrador_venta_id)
        REFERENCES ventas.borrador_venta (id) ON DELETE RESTRICT,
    CONSTRAINT fk_detalle_borrador_producto
        FOREIGN KEY (producto_id)
        REFERENCES catalogo.producto (id) ON DELETE RESTRICT,
    CONSTRAINT ck_detalle_borrador_cantidad CHECK (cantidad > 0),
    CONSTRAINT ck_detalle_borrador_tipo_precio
        CHECK (tipo_precio IN ('MINORISTA', 'MAYORISTA', 'RESERVA')),
    CONSTRAINT ck_detalle_borrador_precio CHECK (precio_unitario >= 0),
    CONSTRAINT ck_detalle_borrador_descuento CHECK (
        (tipo_descuento IS NULL
         AND porcentaje_descuento IS NULL
         AND valor_descuento = 0)
        OR
        (tipo_descuento IS NOT NULL
         AND tipo_descuento = 'PORCENTAJE'
         AND porcentaje_descuento IS NOT NULL
         AND porcentaje_descuento > 0
         AND porcentaje_descuento <= 100
         AND valor_descuento >= 0)
        OR
        (tipo_descuento IS NOT NULL
         AND tipo_descuento = 'VALOR_FIJO'
         AND porcentaje_descuento IS NULL
         AND valor_descuento > 0)
    ),
    CONSTRAINT ck_detalle_borrador_orden CHECK (orden >= 0),
    CONSTRAINT ck_detalle_borrador_version CHECK (version > 0)
);

CREATE TABLE ventas.venta (
    id                    uuid           NOT NULL,
    instalacion_id        uuid           NOT NULL,
    turno_caja_id         uuid           NOT NULL,
    usuario_id            uuid           NOT NULL,
    sesion_operador_id    uuid,
    cliente_id            uuid,
    prefijo               varchar(10)    NOT NULL,
    serie                 varchar(10)    NOT NULL,
    consecutivo           bigint         NOT NULL,
    fecha_hora            timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_operativa       date           NOT NULL,
    fecha_limite_cambio   date           NOT NULL,
    tipo_venta            varchar(20)    NOT NULL,
    ambito_descuento      varchar(20)    NOT NULL DEFAULT 'NINGUNO',
    tipo_descuento        varchar(20),
    valor_descuento_solicitado numeric(18,4),
    motivo_descuento      text,
    autorizacion_descuento_id uuid,
    subtotal_bruto        numeric(18,0)  NOT NULL,
    descuento_total       numeric(18,0)  NOT NULL DEFAULT 0,
    base_gravable_total   numeric(18,4),
    impuesto_incluido_total numeric(18,4),
    iva_discriminado_completo boolean    NOT NULL DEFAULT false,
    total                 numeric(18,0)  NOT NULL,
    estado                varchar(20)    NOT NULL DEFAULT 'CONFIRMADA',
    version               bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_venta PRIMARY KEY (id),
    CONSTRAINT uq_venta_instalacion_serie_numero
        UNIQUE (instalacion_id, serie, consecutivo),
    CONSTRAINT fk_venta_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_venta_turno_caja
        FOREIGN KEY (turno_caja_id)
        REFERENCES caja.turno_caja (id) ON DELETE RESTRICT,
    CONSTRAINT fk_venta_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_venta_sesion_operador
        FOREIGN KEY (sesion_operador_id)
        REFERENCES caja.sesion_operador (id) ON DELETE RESTRICT,
    CONSTRAINT fk_venta_cliente
        FOREIGN KEY (cliente_id)
        REFERENCES catalogo.cliente (id) ON DELETE RESTRICT,
    CONSTRAINT fk_venta_autorizacion_descuento
        FOREIGN KEY (autorizacion_descuento_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_venta_prefijo CHECK (btrim(prefijo) <> ''),
    CONSTRAINT ck_venta_serie CHECK (btrim(serie) <> ''),
    CONSTRAINT ck_venta_consecutivo CHECK (consecutivo > 0),
    CONSTRAINT ck_venta_tipo CHECK (tipo_venta IN ('CONTADO', 'CREDITO', 'APARTADO')),
    CONSTRAINT ck_venta_cliente_requerido
        CHECK (tipo_venta = 'CONTADO' OR cliente_id IS NOT NULL),
    CONSTRAINT ck_venta_fecha_cambio
        CHECK (fecha_limite_cambio >= fecha_operativa),
    CONSTRAINT ck_venta_descuento CHECK (
        (
            ambito_descuento = 'NINGUNO'
            AND tipo_descuento IS NULL
            AND valor_descuento_solicitado IS NULL
            AND descuento_total = 0
            AND motivo_descuento IS NULL
            AND autorizacion_descuento_id IS NULL
        )
        OR
        (
            ambito_descuento = 'PRODUCTO'
            AND tipo_descuento IS NULL
            AND valor_descuento_solicitado IS NULL
            AND descuento_total >= 0
            AND (motivo_descuento IS NULL OR btrim(motivo_descuento) <> '')
        )
        OR
        (
            ambito_descuento = 'VENTA'
            AND tipo_descuento IS NOT NULL
            AND tipo_descuento IN ('PORCENTAJE', 'VALOR_FIJO')
            AND valor_descuento_solicitado IS NOT NULL
            AND valor_descuento_solicitado > 0
            AND descuento_total > 0
            AND (motivo_descuento IS NULL OR btrim(motivo_descuento) <> '')
            AND (
                tipo_descuento <> 'PORCENTAJE'
                OR valor_descuento_solicitado <= 100
            )
        )
    ),
    CONSTRAINT ck_venta_montos CHECK (
        subtotal_bruto >= 0
        AND descuento_total >= 0
        AND total >= 0
        AND descuento_total <= subtotal_bruto
        AND total = subtotal_bruto - descuento_total
    ),
    CONSTRAINT ck_venta_iva_incluido CHECK (
        (
            iva_discriminado_completo = true
            AND base_gravable_total IS NOT NULL
            AND base_gravable_total >= 0
            AND impuesto_incluido_total IS NOT NULL
            AND impuesto_incluido_total >= 0
            AND base_gravable_total + impuesto_incluido_total = total
        )
        OR
        (
            iva_discriminado_completo = false
            AND base_gravable_total IS NULL
            AND impuesto_incluido_total IS NULL
        )
    ),
    CONSTRAINT ck_venta_estado CHECK (estado IN ('CONFIRMADA', 'ANULADA')),
    CONSTRAINT ck_venta_version CHECK (version > 0)
);

CREATE TABLE ventas.detalle_venta (
    id                       uuid           NOT NULL,
    venta_id                 uuid           NOT NULL,
    producto_id              uuid           NOT NULL,
    codigo_producto          varchar(100)   NOT NULL,
    nombre_producto          varchar(200)   NOT NULL,
    unidad_medida            varchar(30)    NOT NULL,
    cantidad                 integer        NOT NULL,
    tipo_precio              varchar(20)    NOT NULL,
    precio_unitario          numeric(18,0)  NOT NULL,
    costo_unitario           numeric(18,4),
    porcentaje_iva           numeric(5,2),
    subtotal_bruto           numeric(18,0)  NOT NULL,
    origen_descuento         varchar(20)    NOT NULL DEFAULT 'NINGUNO',
    tipo_descuento           varchar(20),
    porcentaje_descuento     numeric(5,2),
    valor_descuento          numeric(18,0)  NOT NULL DEFAULT 0,
    base_gravable            numeric(18,4),
    valor_iva                numeric(18,4),
    subtotal_neto            numeric(18,0)  NOT NULL,

    CONSTRAINT pk_detalle_venta PRIMARY KEY (id),
    CONSTRAINT fk_detalle_venta_venta
        FOREIGN KEY (venta_id)
        REFERENCES ventas.venta (id) ON DELETE RESTRICT,
    CONSTRAINT fk_detalle_venta_producto
        FOREIGN KEY (producto_id)
        REFERENCES catalogo.producto (id) ON DELETE RESTRICT,
    CONSTRAINT ck_detalle_venta_codigo CHECK (btrim(codigo_producto) <> ''),
    CONSTRAINT ck_detalle_venta_nombre CHECK (btrim(nombre_producto) <> ''),
    CONSTRAINT ck_detalle_venta_unidad CHECK (btrim(unidad_medida) <> ''),
    CONSTRAINT ck_detalle_venta_cantidad CHECK (cantidad > 0),
    CONSTRAINT ck_detalle_venta_tipo_precio
        CHECK (tipo_precio IN ('MINORISTA', 'MAYORISTA', 'RESERVA')),
    CONSTRAINT ck_detalle_venta_valores CHECK (
        precio_unitario >= 0
        AND (costo_unitario IS NULL OR costo_unitario >= 0)
        AND (porcentaje_iva IS NULL OR porcentaje_iva BETWEEN 0 AND 100)
        AND subtotal_bruto = precio_unitario * cantidad
        AND valor_descuento >= 0
        AND valor_descuento <= subtotal_bruto
        AND subtotal_neto = subtotal_bruto - valor_descuento
    ),
    CONSTRAINT ck_detalle_venta_descuento CHECK (
        (
            origen_descuento = 'NINGUNO'
            AND tipo_descuento IS NULL
            AND porcentaje_descuento IS NULL
            AND valor_descuento = 0
        )
        OR
        (
            origen_descuento IN ('PRODUCTO', 'VENTA')
            AND tipo_descuento IS NOT NULL
            AND tipo_descuento = 'PORCENTAJE'
            AND porcentaje_descuento IS NOT NULL
            AND porcentaje_descuento > 0
            AND porcentaje_descuento <= 100
        )
        OR
        (
            origen_descuento IN ('PRODUCTO', 'VENTA')
            AND tipo_descuento IS NOT NULL
            AND tipo_descuento = 'VALOR_FIJO'
            AND porcentaje_descuento IS NULL
            AND (
                (origen_descuento = 'PRODUCTO' AND valor_descuento > 0)
                OR (origen_descuento = 'VENTA' AND valor_descuento >= 0)
            )
        )
    ),
    CONSTRAINT ck_detalle_venta_iva_incluido CHECK (
        (
            porcentaje_iva IS NULL
            AND base_gravable IS NULL
            AND valor_iva IS NULL
        )
        OR
        (
            porcentaje_iva IS NOT NULL
            AND base_gravable IS NOT NULL
            AND base_gravable >= 0
            AND valor_iva IS NOT NULL
            AND valor_iva >= 0
            AND base_gravable = round(
                subtotal_neto * 100 / (100 + porcentaje_iva), 4
            )
            AND base_gravable + valor_iva = subtotal_neto
        )
    )
);

ALTER TABLE ventas.borrador_venta
    ADD CONSTRAINT fk_borrador_venta_confirmada
    FOREIGN KEY (venta_confirmada_id)
    REFERENCES ventas.venta (id) ON DELETE RESTRICT;

CREATE TABLE ventas.pago_venta (
    id                       uuid           NOT NULL,
    venta_id                 uuid           NOT NULL,
    metodo_pago_id           uuid           NOT NULL,
    movimiento_caja_id       uuid,
    usuario_id               uuid           NOT NULL,
    sesion_operador_id       uuid,
    valor_aplicado           numeric(18,0)  NOT NULL,
    valor_recibido           numeric(18,0),
    cambio                   numeric(18,0)  NOT NULL DEFAULT 0,
    referencia               varchar(200),
    fecha_hora               timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    estado                   varchar(20)    NOT NULL DEFAULT 'APLICADO',
    usuario_anulacion_id     uuid,
    autorizacion_anulacion_id uuid,
    motivo_anulacion_id      uuid,
    fecha_anulacion          timestamptz,
    observacion_anulacion    text,

    CONSTRAINT pk_pago_venta PRIMARY KEY (id),
    CONSTRAINT uq_pago_venta_movimiento_caja UNIQUE (movimiento_caja_id),
    CONSTRAINT fk_pago_venta_venta
        FOREIGN KEY (venta_id)
        REFERENCES ventas.venta (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_venta_metodo
        FOREIGN KEY (metodo_pago_id)
        REFERENCES catalogo.metodo_pago (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_venta_movimiento_caja
        FOREIGN KEY (movimiento_caja_id)
        REFERENCES caja.movimiento_caja (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_venta_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_venta_sesion
        FOREIGN KEY (sesion_operador_id)
        REFERENCES caja.sesion_operador (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_venta_usuario_anulacion
        FOREIGN KEY (usuario_anulacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_venta_autorizacion_anulacion
        FOREIGN KEY (autorizacion_anulacion_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_venta_motivo_anulacion
        FOREIGN KEY (motivo_anulacion_id)
        REFERENCES configuracion.motivo_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_pago_venta_valores CHECK (
        valor_aplicado > 0
        AND (
            (valor_recibido IS NULL AND cambio = 0)
            OR
            (valor_recibido IS NOT NULL
             AND valor_recibido >= valor_aplicado
             AND cambio = valor_recibido - valor_aplicado)
        )
    ),
    CONSTRAINT ck_pago_venta_estado CHECK (estado IN ('APLICADO', 'ANULADO')),
    CONSTRAINT ck_pago_venta_anulacion CHECK (
        (
            estado = 'APLICADO'
            AND usuario_anulacion_id IS NULL
            AND autorizacion_anulacion_id IS NULL
            AND motivo_anulacion_id IS NULL
            AND fecha_anulacion IS NULL
            AND observacion_anulacion IS NULL
        )
        OR
        (
            estado = 'ANULADO'
            AND usuario_anulacion_id IS NOT NULL
            AND autorizacion_anulacion_id IS NOT NULL
            AND motivo_anulacion_id IS NOT NULL
            AND fecha_anulacion IS NOT NULL
            AND (
                observacion_anulacion IS NULL
                OR btrim(observacion_anulacion) <> ''
            )
        )
    ),
    CONSTRAINT ck_pago_venta_referencia CHECK (
        referencia IS NULL OR btrim(referencia) <> ''
    )
);

CREATE TABLE ventas.anulacion_venta (
    id                           uuid          NOT NULL,
    venta_id                     uuid          NOT NULL,
    usuario_solicitante_id       uuid          NOT NULL,
    usuario_autorizador_id       uuid          NOT NULL,
    autorizacion_operacion_id    uuid          NOT NULL,
    motivo_operacion_id          uuid          NOT NULL,
    fecha_hora                   timestamptz   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    observacion                  text,
    correlacion_id               uuid          NOT NULL,

    CONSTRAINT pk_anulacion_venta PRIMARY KEY (id),
    CONSTRAINT uq_anulacion_venta_venta UNIQUE (venta_id),
    CONSTRAINT uq_anulacion_venta_autorizacion UNIQUE (autorizacion_operacion_id),
    CONSTRAINT fk_anulacion_venta_venta
        FOREIGN KEY (venta_id)
        REFERENCES ventas.venta (id) ON DELETE RESTRICT,
    CONSTRAINT fk_anulacion_venta_solicitante
        FOREIGN KEY (usuario_solicitante_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_anulacion_venta_autorizador
        FOREIGN KEY (usuario_autorizador_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_anulacion_venta_autorizacion
        FOREIGN KEY (autorizacion_operacion_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_anulacion_venta_motivo
        FOREIGN KEY (motivo_operacion_id)
        REFERENCES configuracion.motivo_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_anulacion_venta_usuarios
        CHECK (usuario_solicitante_id <> usuario_autorizador_id),
    CONSTRAINT ck_anulacion_venta_observacion
        CHECK (observacion IS NULL OR btrim(observacion) <> '')
);

CREATE TABLE ventas.credito (
    id                           uuid           NOT NULL,
    venta_id                     uuid           NOT NULL,
    autorizacion_operacion_id    uuid           NOT NULL,
    monto_original               numeric(18,0)  NOT NULL,
    monto_ajustado               numeric(18,0)  NOT NULL,
    saldo_pendiente              numeric(18,0)  NOT NULL,
    fecha_otorgamiento           date           NOT NULL,
    fecha_vencimiento            date           NOT NULL,
    fecha_pago                   date,
    estado                       varchar(20)    NOT NULL DEFAULT 'PENDIENTE',
    version                      bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_credito PRIMARY KEY (id),
    CONSTRAINT uq_credito_venta UNIQUE (venta_id),
    CONSTRAINT uq_credito_autorizacion UNIQUE (autorizacion_operacion_id),
    CONSTRAINT fk_credito_venta
        FOREIGN KEY (venta_id)
        REFERENCES ventas.venta (id) ON DELETE RESTRICT,
    CONSTRAINT fk_credito_autorizacion
        FOREIGN KEY (autorizacion_operacion_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_credito_montos CHECK (
        monto_original > 0
        AND monto_ajustado >= 0
        AND saldo_pendiente >= 0
        AND saldo_pendiente <= monto_ajustado
    ),
    CONSTRAINT ck_credito_fechas CHECK (fecha_vencimiento >= fecha_otorgamiento),
    CONSTRAINT ck_credito_estado
        CHECK (estado IN ('PENDIENTE', 'PAGADO', 'VENCIDO', 'ANULADO')),
    CONSTRAINT ck_credito_pago CHECK (
        (estado = 'PAGADO' AND saldo_pendiente = 0 AND fecha_pago IS NOT NULL)
        OR (estado IN ('PENDIENTE', 'VENCIDO') AND saldo_pendiente > 0 AND fecha_pago IS NULL)
        OR estado = 'ANULADO'
    ),
    CONSTRAINT ck_credito_version CHECK (version > 0)
);

CREATE TABLE ventas.pago_credito (
    id                       uuid           NOT NULL,
    credito_id               uuid           NOT NULL,
    instalacion_id           uuid           NOT NULL,
    turno_caja_id            uuid           NOT NULL,
    metodo_pago_id           uuid           NOT NULL,
    usuario_id               uuid           NOT NULL,
    sesion_operador_id       uuid,
    movimiento_caja_id       uuid,
    prefijo                  varchar(10)    NOT NULL,
    serie                    varchar(10)    NOT NULL,
    consecutivo              bigint         NOT NULL,
    valor_aplicado           numeric(18,0)  NOT NULL,
    valor_recibido           numeric(18,0),
    cambio                   numeric(18,0)  NOT NULL DEFAULT 0,
    referencia               varchar(200),
    fecha_hora               timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    estado                   varchar(20)    NOT NULL DEFAULT 'APLICADO',
    usuario_anulacion_id     uuid,
    autorizacion_anulacion_id uuid,
    motivo_anulacion_id      uuid,
    fecha_anulacion          timestamptz,
    observacion_anulacion    text,

    CONSTRAINT pk_pago_credito PRIMARY KEY (id),
    CONSTRAINT uq_pago_credito_inst_serie_numero
        UNIQUE (instalacion_id, serie, consecutivo),
    CONSTRAINT uq_pago_credito_movimiento_caja UNIQUE (movimiento_caja_id),
    CONSTRAINT fk_pago_credito_credito
        FOREIGN KEY (credito_id)
        REFERENCES ventas.credito (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_credito_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_credito_turno
        FOREIGN KEY (turno_caja_id)
        REFERENCES caja.turno_caja (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_credito_metodo
        FOREIGN KEY (metodo_pago_id)
        REFERENCES catalogo.metodo_pago (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_credito_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_credito_sesion
        FOREIGN KEY (sesion_operador_id)
        REFERENCES caja.sesion_operador (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_credito_movimiento_caja
        FOREIGN KEY (movimiento_caja_id)
        REFERENCES caja.movimiento_caja (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_credito_usuario_anulacion
        FOREIGN KEY (usuario_anulacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_credito_autorizacion_anulacion
        FOREIGN KEY (autorizacion_anulacion_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_credito_motivo_anulacion
        FOREIGN KEY (motivo_anulacion_id)
        REFERENCES configuracion.motivo_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_pago_credito_numero CHECK (
        btrim(prefijo) <> '' AND btrim(serie) <> '' AND consecutivo > 0
    ),
    CONSTRAINT ck_pago_credito_valores CHECK (
        valor_aplicado > 0
        AND (
            (valor_recibido IS NULL AND cambio = 0)
            OR
            (valor_recibido IS NOT NULL
             AND valor_recibido >= valor_aplicado
             AND cambio = valor_recibido - valor_aplicado)
        )
    ),
    CONSTRAINT ck_pago_credito_estado CHECK (estado IN ('APLICADO', 'ANULADO')),
    CONSTRAINT ck_pago_credito_anulacion CHECK (
        (
            estado = 'APLICADO'
            AND usuario_anulacion_id IS NULL
            AND autorizacion_anulacion_id IS NULL
            AND motivo_anulacion_id IS NULL
            AND fecha_anulacion IS NULL
            AND observacion_anulacion IS NULL
        )
        OR
        (
            estado = 'ANULADO'
            AND usuario_anulacion_id IS NOT NULL
            AND autorizacion_anulacion_id IS NOT NULL
            AND motivo_anulacion_id IS NOT NULL
            AND fecha_anulacion IS NOT NULL
            AND (
                observacion_anulacion IS NULL
                OR btrim(observacion_anulacion) <> ''
            )
        )
    ),
    CONSTRAINT ck_pago_credito_referencia CHECK (
        referencia IS NULL OR btrim(referencia) <> ''
    )
);

CREATE TABLE ventas.apartado (
    id                           uuid           NOT NULL,
    instalacion_id               uuid           NOT NULL,
    turno_caja_id                uuid           NOT NULL,
    cliente_id                   uuid           NOT NULL,
    usuario_id                   uuid           NOT NULL,
    sesion_operador_id           uuid,
    autorizacion_operacion_id    uuid           NOT NULL,
    venta_entrega_id             uuid,
    prefijo                      varchar(10)    NOT NULL,
    serie                        varchar(10)    NOT NULL,
    consecutivo                  bigint         NOT NULL,
    fecha_hora                   timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_limite                 date           NOT NULL,
    ambito_descuento             varchar(20)    NOT NULL DEFAULT 'NINGUNO',
    tipo_descuento               varchar(20),
    valor_descuento_solicitado   numeric(18,4),
    motivo_descuento             text,
    autorizacion_descuento_id    uuid,
    porcentaje_minimo_inicial    numeric(5,2)   NOT NULL,
    abono_inicial                numeric(18,0)  NOT NULL,
    subtotal_bruto               numeric(18,0)  NOT NULL,
    descuento_total              numeric(18,0)  NOT NULL DEFAULT 0,
    base_gravable_total          numeric(18,4),
    impuesto_incluido_total      numeric(18,4),
    iva_discriminado_completo    boolean        NOT NULL DEFAULT false,
    total                        numeric(18,0)  NOT NULL,
    saldo_pendiente              numeric(18,0)  NOT NULL,
    estado                       varchar(20)    NOT NULL DEFAULT 'ACTIVO',
    fecha_pago                   timestamptz,
    fecha_entrega                timestamptz,
    usuario_entrega_id           uuid,
    fecha_anulacion              timestamptz,
    usuario_anulacion_id         uuid,
    autorizacion_anulacion_id    uuid,
    motivo_anulacion_id          uuid,
    observacion_anulacion        text,
    total_abonado_cancelacion    numeric(18,0),
    valor_devuelto_cancelacion   numeric(18,0),
    valor_retenido_cancelacion   numeric(18,0),
    version                      bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_apartado PRIMARY KEY (id),
    CONSTRAINT uq_apartado_instalacion_serie_numero
        UNIQUE (instalacion_id, serie, consecutivo),
    CONSTRAINT uq_apartado_autorizacion UNIQUE (autorizacion_operacion_id),
    CONSTRAINT uq_apartado_venta_entrega UNIQUE (venta_entrega_id),
    CONSTRAINT fk_apartado_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_apartado_turno
        FOREIGN KEY (turno_caja_id)
        REFERENCES caja.turno_caja (id) ON DELETE RESTRICT,
    CONSTRAINT fk_apartado_cliente
        FOREIGN KEY (cliente_id)
        REFERENCES catalogo.cliente (id) ON DELETE RESTRICT,
    CONSTRAINT fk_apartado_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_apartado_sesion
        FOREIGN KEY (sesion_operador_id)
        REFERENCES caja.sesion_operador (id) ON DELETE RESTRICT,
    CONSTRAINT fk_apartado_autorizacion
        FOREIGN KEY (autorizacion_operacion_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_apartado_autorizacion_descuento
        FOREIGN KEY (autorizacion_descuento_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_apartado_venta_entrega
        FOREIGN KEY (venta_entrega_id)
        REFERENCES ventas.venta (id) ON DELETE RESTRICT,
    CONSTRAINT fk_apartado_usuario_entrega
        FOREIGN KEY (usuario_entrega_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_apartado_usuario_anulacion
        FOREIGN KEY (usuario_anulacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_apartado_autorizacion_anulacion
        FOREIGN KEY (autorizacion_anulacion_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_apartado_motivo_anulacion
        FOREIGN KEY (motivo_anulacion_id)
        REFERENCES configuracion.motivo_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_apartado_numero CHECK (
        btrim(prefijo) <> '' AND btrim(serie) <> '' AND consecutivo > 0
    ),
    CONSTRAINT ck_apartado_descuento CHECK (
        (
            ambito_descuento = 'NINGUNO'
            AND tipo_descuento IS NULL
            AND valor_descuento_solicitado IS NULL
            AND descuento_total = 0
            AND motivo_descuento IS NULL
            AND autorizacion_descuento_id IS NULL
        )
        OR
        (
            ambito_descuento = 'PRODUCTO'
            AND tipo_descuento IS NULL
            AND valor_descuento_solicitado IS NULL
            AND descuento_total >= 0
            AND (motivo_descuento IS NULL OR btrim(motivo_descuento) <> '')
        )
        OR
        (
            ambito_descuento = 'VENTA'
            AND tipo_descuento IS NOT NULL
            AND tipo_descuento IN ('PORCENTAJE', 'VALOR_FIJO')
            AND valor_descuento_solicitado IS NOT NULL
            AND valor_descuento_solicitado > 0
            AND descuento_total > 0
            AND (motivo_descuento IS NULL OR btrim(motivo_descuento) <> '')
            AND (
                tipo_descuento <> 'PORCENTAJE'
                OR valor_descuento_solicitado <= 100
            )
        )
    ),
    CONSTRAINT ck_apartado_montos CHECK (
        subtotal_bruto >= 0
        AND descuento_total >= 0
        AND descuento_total <= subtotal_bruto
        AND total > 0
        AND total = subtotal_bruto - descuento_total
        AND porcentaje_minimo_inicial > 0
        AND porcentaje_minimo_inicial <= 100
        AND abono_inicial >= round(total * porcentaje_minimo_inicial / 100, 0)
        AND abono_inicial <= total
        AND saldo_pendiente >= 0
        AND saldo_pendiente <= total
    ),
    CONSTRAINT ck_apartado_iva_incluido CHECK (
        (
            iva_discriminado_completo = true
            AND base_gravable_total IS NOT NULL
            AND base_gravable_total >= 0
            AND impuesto_incluido_total IS NOT NULL
            AND impuesto_incluido_total >= 0
            AND base_gravable_total + impuesto_incluido_total = total
        )
        OR
        (
            iva_discriminado_completo = false
            AND base_gravable_total IS NULL
            AND impuesto_incluido_total IS NULL
        )
    ),
    CONSTRAINT ck_apartado_estado
        CHECK (estado IN ('ACTIVO', 'PAGADO', 'ENTREGADO', 'ANULADO')),
    CONSTRAINT ck_apartado_transicion CHECK (
        (
            estado = 'ACTIVO'
            AND saldo_pendiente > 0
            AND fecha_pago IS NULL
            AND fecha_entrega IS NULL
            AND venta_entrega_id IS NULL
            AND usuario_entrega_id IS NULL
            AND fecha_anulacion IS NULL
            AND usuario_anulacion_id IS NULL
            AND autorizacion_anulacion_id IS NULL
            AND motivo_anulacion_id IS NULL
            AND observacion_anulacion IS NULL
            AND total_abonado_cancelacion IS NULL
            AND valor_devuelto_cancelacion IS NULL
            AND valor_retenido_cancelacion IS NULL
        )
        OR
        (
            estado = 'PAGADO'
            AND saldo_pendiente = 0
            AND fecha_pago IS NOT NULL
            AND fecha_entrega IS NULL
            AND venta_entrega_id IS NULL
            AND usuario_entrega_id IS NULL
            AND fecha_anulacion IS NULL
            AND usuario_anulacion_id IS NULL
            AND autorizacion_anulacion_id IS NULL
            AND motivo_anulacion_id IS NULL
            AND observacion_anulacion IS NULL
            AND total_abonado_cancelacion IS NULL
            AND valor_devuelto_cancelacion IS NULL
            AND valor_retenido_cancelacion IS NULL
        )
        OR
        (
            estado = 'ENTREGADO'
            AND saldo_pendiente = 0
            AND fecha_pago IS NOT NULL
            AND fecha_entrega IS NOT NULL
            AND venta_entrega_id IS NOT NULL
            AND usuario_entrega_id IS NOT NULL
            AND fecha_anulacion IS NULL
            AND usuario_anulacion_id IS NULL
            AND autorizacion_anulacion_id IS NULL
            AND motivo_anulacion_id IS NULL
            AND observacion_anulacion IS NULL
            AND total_abonado_cancelacion IS NULL
            AND valor_devuelto_cancelacion IS NULL
            AND valor_retenido_cancelacion IS NULL
        )
        OR
        (
            estado = 'ANULADO'
            AND fecha_anulacion IS NOT NULL
            AND usuario_anulacion_id IS NOT NULL
            AND autorizacion_anulacion_id IS NOT NULL
            AND motivo_anulacion_id IS NOT NULL
            AND total_abonado_cancelacion IS NOT NULL
            AND total_abonado_cancelacion >= 0
            AND valor_devuelto_cancelacion IS NOT NULL
            AND valor_devuelto_cancelacion >= 0
            AND valor_retenido_cancelacion IS NOT NULL
            AND valor_retenido_cancelacion >= 0
            AND valor_devuelto_cancelacion + valor_retenido_cancelacion
                = total_abonado_cancelacion
            AND (
                observacion_anulacion IS NULL
                OR btrim(observacion_anulacion) <> ''
            )
        )
    ),
    CONSTRAINT ck_apartado_version CHECK (version > 0)
);

CREATE TABLE ventas.detalle_apartado (
    id                       uuid           NOT NULL,
    apartado_id              uuid           NOT NULL,
    producto_id              uuid           NOT NULL,
    codigo_producto          varchar(100)   NOT NULL,
    nombre_producto          varchar(200)   NOT NULL,
    unidad_medida            varchar(30)    NOT NULL,
    cantidad                 integer        NOT NULL,
    precio_reserva           numeric(18,0)  NOT NULL,
    costo_unitario           numeric(18,4),
    porcentaje_iva           numeric(5,2),
    subtotal_bruto           numeric(18,0)  NOT NULL,
    origen_descuento         varchar(20)    NOT NULL DEFAULT 'NINGUNO',
    tipo_descuento           varchar(20),
    porcentaje_descuento     numeric(5,2),
    valor_descuento          numeric(18,0)  NOT NULL DEFAULT 0,
    base_gravable            numeric(18,4),
    valor_iva                numeric(18,4),
    subtotal_neto            numeric(18,0)  NOT NULL,

    CONSTRAINT pk_detalle_apartado PRIMARY KEY (id),
    CONSTRAINT fk_detalle_apartado_apartado
        FOREIGN KEY (apartado_id)
        REFERENCES ventas.apartado (id) ON DELETE RESTRICT,
    CONSTRAINT fk_detalle_apartado_producto
        FOREIGN KEY (producto_id)
        REFERENCES catalogo.producto (id) ON DELETE RESTRICT,
    CONSTRAINT ck_detalle_apartado_codigo CHECK (btrim(codigo_producto) <> ''),
    CONSTRAINT ck_detalle_apartado_nombre CHECK (btrim(nombre_producto) <> ''),
    CONSTRAINT ck_detalle_apartado_unidad CHECK (btrim(unidad_medida) <> ''),
    CONSTRAINT ck_detalle_apartado_cantidad CHECK (cantidad > 0),
    CONSTRAINT ck_detalle_apartado_valores CHECK (
        precio_reserva >= 0
        AND (costo_unitario IS NULL OR costo_unitario >= 0)
        AND (porcentaje_iva IS NULL OR porcentaje_iva BETWEEN 0 AND 100)
        AND subtotal_bruto = precio_reserva * cantidad
        AND (porcentaje_descuento IS NULL OR porcentaje_descuento BETWEEN 0 AND 100)
        AND valor_descuento >= 0
        AND valor_descuento <= subtotal_bruto
        AND subtotal_neto = subtotal_bruto - valor_descuento
    ),
    CONSTRAINT ck_detalle_apartado_descuento CHECK (
        (
            origen_descuento = 'NINGUNO'
            AND tipo_descuento IS NULL
            AND porcentaje_descuento IS NULL
            AND valor_descuento = 0
        )
        OR
        (
            origen_descuento IN ('PRODUCTO', 'VENTA')
            AND tipo_descuento IS NOT NULL
            AND tipo_descuento = 'PORCENTAJE'
            AND porcentaje_descuento IS NOT NULL
            AND porcentaje_descuento > 0
            AND porcentaje_descuento <= 100
        )
        OR
        (
            origen_descuento IN ('PRODUCTO', 'VENTA')
            AND tipo_descuento IS NOT NULL
            AND tipo_descuento = 'VALOR_FIJO'
            AND porcentaje_descuento IS NULL
            AND (
                (origen_descuento = 'PRODUCTO' AND valor_descuento > 0)
                OR (origen_descuento = 'VENTA' AND valor_descuento >= 0)
            )
        )
    ),
    CONSTRAINT ck_detalle_apartado_iva_incluido CHECK (
        (
            porcentaje_iva IS NULL
            AND base_gravable IS NULL
            AND valor_iva IS NULL
        )
        OR
        (
            porcentaje_iva IS NOT NULL
            AND base_gravable IS NOT NULL
            AND base_gravable >= 0
            AND valor_iva IS NOT NULL
            AND valor_iva >= 0
            AND base_gravable = round(
                subtotal_neto * 100 / (100 + porcentaje_iva), 4
            )
            AND base_gravable + valor_iva = subtotal_neto
        )
    )
);

CREATE TABLE ventas.pago_apartado (
    id                       uuid           NOT NULL,
    apartado_id              uuid           NOT NULL,
    instalacion_id           uuid           NOT NULL,
    turno_caja_id            uuid           NOT NULL,
    metodo_pago_id           uuid           NOT NULL,
    usuario_id               uuid           NOT NULL,
    sesion_operador_id       uuid,
    movimiento_caja_id       uuid,
    prefijo                  varchar(10)    NOT NULL,
    serie                    varchar(10)    NOT NULL,
    consecutivo              bigint         NOT NULL,
    valor_aplicado           numeric(18,0)  NOT NULL,
    valor_recibido           numeric(18,0),
    cambio                   numeric(18,0)  NOT NULL DEFAULT 0,
    referencia               varchar(200),
    fecha_hora               timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    estado                   varchar(20)    NOT NULL DEFAULT 'APLICADO',
    usuario_anulacion_id     uuid,
    autorizacion_anulacion_id uuid,
    motivo_anulacion_id      uuid,
    fecha_anulacion          timestamptz,
    observacion_anulacion    text,

    CONSTRAINT pk_pago_apartado PRIMARY KEY (id),
    CONSTRAINT uq_pago_apartado_inst_serie_numero
        UNIQUE (instalacion_id, serie, consecutivo),
    CONSTRAINT uq_pago_apartado_movimiento_caja UNIQUE (movimiento_caja_id),
    CONSTRAINT fk_pago_apartado_apartado
        FOREIGN KEY (apartado_id)
        REFERENCES ventas.apartado (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_apartado_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_apartado_turno
        FOREIGN KEY (turno_caja_id)
        REFERENCES caja.turno_caja (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_apartado_metodo
        FOREIGN KEY (metodo_pago_id)
        REFERENCES catalogo.metodo_pago (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_apartado_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_apartado_sesion
        FOREIGN KEY (sesion_operador_id)
        REFERENCES caja.sesion_operador (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_apartado_movimiento_caja
        FOREIGN KEY (movimiento_caja_id)
        REFERENCES caja.movimiento_caja (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_apartado_usuario_anulacion
        FOREIGN KEY (usuario_anulacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_apartado_autorizacion_anulacion
        FOREIGN KEY (autorizacion_anulacion_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_apartado_motivo_anulacion
        FOREIGN KEY (motivo_anulacion_id)
        REFERENCES configuracion.motivo_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_pago_apartado_numero CHECK (
        btrim(prefijo) <> '' AND btrim(serie) <> '' AND consecutivo > 0
    ),
    CONSTRAINT ck_pago_apartado_valores CHECK (
        valor_aplicado > 0
        AND (
            (valor_recibido IS NULL AND cambio = 0)
            OR
            (valor_recibido IS NOT NULL
             AND valor_recibido >= valor_aplicado
             AND cambio = valor_recibido - valor_aplicado)
        )
    ),
    CONSTRAINT ck_pago_apartado_estado CHECK (estado IN ('APLICADO', 'ANULADO')),
    CONSTRAINT ck_pago_apartado_anulacion CHECK (
        (
            estado = 'APLICADO'
            AND usuario_anulacion_id IS NULL
            AND autorizacion_anulacion_id IS NULL
            AND motivo_anulacion_id IS NULL
            AND fecha_anulacion IS NULL
            AND observacion_anulacion IS NULL
        )
        OR
        (
            estado = 'ANULADO'
            AND usuario_anulacion_id IS NOT NULL
            AND autorizacion_anulacion_id IS NOT NULL
            AND motivo_anulacion_id IS NOT NULL
            AND fecha_anulacion IS NOT NULL
            AND (
                observacion_anulacion IS NULL
                OR btrim(observacion_anulacion) <> ''
            )
        )
    ),
    CONSTRAINT ck_pago_apartado_referencia CHECK (
        referencia IS NULL OR btrim(referencia) <> ''
    )
);

CREATE TABLE ventas.reembolso_apartado (
    id                    uuid           NOT NULL,
    apartado_id           uuid           NOT NULL,
    turno_caja_id         uuid           NOT NULL,
    metodo_pago_id        uuid           NOT NULL,
    usuario_id            uuid           NOT NULL,
    sesion_operador_id    uuid,
    movimiento_caja_id    uuid,
    valor                 numeric(18,0)  NOT NULL,
    referencia            varchar(200),
    fecha_hora            timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    correlacion_id        uuid           NOT NULL,

    CONSTRAINT pk_reembolso_apartado PRIMARY KEY (id),
    CONSTRAINT uq_reembolso_apartado_movimiento UNIQUE (movimiento_caja_id),
    CONSTRAINT fk_reembolso_apartado_apartado
        FOREIGN KEY (apartado_id)
        REFERENCES ventas.apartado (id) ON DELETE RESTRICT,
    CONSTRAINT fk_reembolso_apartado_turno
        FOREIGN KEY (turno_caja_id)
        REFERENCES caja.turno_caja (id) ON DELETE RESTRICT,
    CONSTRAINT fk_reembolso_apartado_metodo
        FOREIGN KEY (metodo_pago_id)
        REFERENCES catalogo.metodo_pago (id) ON DELETE RESTRICT,
    CONSTRAINT fk_reembolso_apartado_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_reembolso_apartado_sesion
        FOREIGN KEY (sesion_operador_id)
        REFERENCES caja.sesion_operador (id) ON DELETE RESTRICT,
    CONSTRAINT fk_reembolso_apartado_movimiento
        FOREIGN KEY (movimiento_caja_id)
        REFERENCES caja.movimiento_caja (id) ON DELETE RESTRICT,
    CONSTRAINT ck_reembolso_apartado_valor CHECK (valor > 0),
    CONSTRAINT ck_reembolso_apartado_referencia CHECK (
        referencia IS NULL OR btrim(referencia) <> ''
    )
);

CREATE TABLE ventas.cambio_venta (
    id                           uuid           NOT NULL,
    venta_id                     uuid           NOT NULL,
    credito_id                   uuid,
    instalacion_id               uuid           NOT NULL,
    turno_caja_id                uuid           NOT NULL,
    autorizacion_operacion_id    uuid           NOT NULL,
    usuario_id                   uuid           NOT NULL,
    sesion_operador_id           uuid,
    prefijo                      varchar(10)    NOT NULL,
    serie                        varchar(10)    NOT NULL,
    consecutivo                  bigint         NOT NULL,
    fecha_hora                   timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    motivo                       text,
    total_devuelto               numeric(18,0)  NOT NULL,
    total_entregado              numeric(18,0)  NOT NULL,
    diferencia                   numeric(18,0)  NOT NULL,
    tratamiento_diferencia       varchar(40)    NOT NULL,
    valor_ajuste_credito         numeric(18,0)  NOT NULL DEFAULT 0,
    valor_pago_o_devolucion      numeric(18,0)  NOT NULL DEFAULT 0,
    estado                       varchar(20)    NOT NULL DEFAULT 'CONFIRMADO',
    usuario_anulacion_id         uuid,
    autorizacion_anulacion_id    uuid,
    motivo_anulacion_id          uuid,
    fecha_anulacion              timestamptz,
    observacion_anulacion        text,
    correlacion_id               uuid           NOT NULL,

    CONSTRAINT pk_cambio_venta PRIMARY KEY (id),
    CONSTRAINT uq_cambio_venta_inst_serie_numero
        UNIQUE (instalacion_id, serie, consecutivo),
    CONSTRAINT uq_cambio_venta_autorizacion UNIQUE (autorizacion_operacion_id),
    CONSTRAINT fk_cambio_venta_venta
        FOREIGN KEY (venta_id)
        REFERENCES ventas.venta (id) ON DELETE RESTRICT,
    CONSTRAINT fk_cambio_venta_credito
        FOREIGN KEY (credito_id)
        REFERENCES ventas.credito (id) ON DELETE RESTRICT,
    CONSTRAINT fk_cambio_venta_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_cambio_venta_turno
        FOREIGN KEY (turno_caja_id)
        REFERENCES caja.turno_caja (id) ON DELETE RESTRICT,
    CONSTRAINT fk_cambio_venta_autorizacion
        FOREIGN KEY (autorizacion_operacion_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_cambio_venta_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_cambio_venta_sesion
        FOREIGN KEY (sesion_operador_id)
        REFERENCES caja.sesion_operador (id) ON DELETE RESTRICT,
    CONSTRAINT fk_cambio_venta_usuario_anulacion
        FOREIGN KEY (usuario_anulacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_cambio_venta_autorizacion_anulacion
        FOREIGN KEY (autorizacion_anulacion_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_cambio_venta_motivo_anulacion
        FOREIGN KEY (motivo_anulacion_id)
        REFERENCES configuracion.motivo_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_cambio_venta_numero CHECK (
        btrim(prefijo) <> '' AND btrim(serie) <> '' AND consecutivo > 0
    ),
    CONSTRAINT ck_cambio_venta_motivo
        CHECK (motivo IS NULL OR btrim(motivo) <> ''),
    CONSTRAINT ck_cambio_venta_valores CHECK (
        total_devuelto >= 0
        AND total_entregado >= 0
        AND diferencia = total_entregado - total_devuelto
        AND valor_ajuste_credito >= 0
        AND valor_pago_o_devolucion >= 0
    ),
    CONSTRAINT ck_cambio_venta_tratamiento CHECK (
        (
            diferencia = 0
            AND tratamiento_diferencia = 'SIN_DIFERENCIA'
            AND valor_ajuste_credito = 0
            AND valor_pago_o_devolucion = 0
        )
        OR
        (
            diferencia > 0
            AND tratamiento_diferencia = 'PAGO_INMEDIATO'
            AND valor_ajuste_credito = 0
            AND valor_pago_o_devolucion = diferencia
        )
        OR
        (
            diferencia > 0
            AND tratamiento_diferencia = 'AGREGAR_CREDITO'
            AND credito_id IS NOT NULL
            AND valor_ajuste_credito = diferencia
            AND valor_pago_o_devolucion = 0
        )
        OR
        (
            diferencia < 0
            AND tratamiento_diferencia = 'DEVOLUCION'
            AND credito_id IS NULL
            AND valor_ajuste_credito = 0
            AND valor_pago_o_devolucion = abs(diferencia)
        )
        OR
        (
            diferencia < 0
            AND tratamiento_diferencia IN (
                'REDUCIR_CREDITO', 'REDUCIR_CREDITO_Y_DEVOLVER'
            )
            AND credito_id IS NOT NULL
            AND valor_ajuste_credito > 0
            AND valor_ajuste_credito + valor_pago_o_devolucion = abs(diferencia)
            AND (
                (tratamiento_diferencia = 'REDUCIR_CREDITO'
                 AND valor_pago_o_devolucion = 0)
                OR
                (tratamiento_diferencia = 'REDUCIR_CREDITO_Y_DEVOLVER'
                 AND valor_pago_o_devolucion > 0)
            )
        )
    ),
    CONSTRAINT ck_cambio_venta_estado CHECK (estado IN ('CONFIRMADO', 'ANULADO')),
    CONSTRAINT ck_cambio_venta_anulacion CHECK (
        (
            estado = 'CONFIRMADO'
            AND usuario_anulacion_id IS NULL
            AND autorizacion_anulacion_id IS NULL
            AND motivo_anulacion_id IS NULL
            AND fecha_anulacion IS NULL
            AND observacion_anulacion IS NULL
        )
        OR
        (
            estado = 'ANULADO'
            AND usuario_anulacion_id IS NOT NULL
            AND autorizacion_anulacion_id IS NOT NULL
            AND motivo_anulacion_id IS NOT NULL
            AND fecha_anulacion IS NOT NULL
            AND (
                observacion_anulacion IS NULL
                OR btrim(observacion_anulacion) <> ''
            )
        )
    )
);

CREATE TABLE ventas.detalle_cambio_venta (
    id                       uuid           NOT NULL,
    cambio_venta_id          uuid           NOT NULL,
    detalle_venta_origen_id  uuid,
    producto_id              uuid           NOT NULL,
    tipo_detalle             varchar(20)    NOT NULL,
    codigo_producto          varchar(100)   NOT NULL,
    nombre_producto          varchar(200)   NOT NULL,
    unidad_medida            varchar(30)    NOT NULL,
    cantidad                 integer        NOT NULL,
    precio_unitario          numeric(18,0)  NOT NULL,
    porcentaje_iva           numeric(5,2),
    valor_descuento          numeric(18,0)  NOT NULL DEFAULT 0,
    base_gravable            numeric(18,4),
    valor_iva                numeric(18,4),
    subtotal_neto            numeric(18,0)  NOT NULL,

    CONSTRAINT pk_detalle_cambio_venta PRIMARY KEY (id),
    CONSTRAINT fk_detalle_cambio_cambio
        FOREIGN KEY (cambio_venta_id)
        REFERENCES ventas.cambio_venta (id) ON DELETE RESTRICT,
    CONSTRAINT fk_detalle_cambio_detalle_origen
        FOREIGN KEY (detalle_venta_origen_id)
        REFERENCES ventas.detalle_venta (id) ON DELETE RESTRICT,
    CONSTRAINT fk_detalle_cambio_producto
        FOREIGN KEY (producto_id)
        REFERENCES catalogo.producto (id) ON DELETE RESTRICT,
    CONSTRAINT ck_detalle_cambio_tipo
        CHECK (tipo_detalle IN ('DEVUELTO', 'ENTREGADO')),
    CONSTRAINT ck_detalle_cambio_origen CHECK (
        (tipo_detalle = 'DEVUELTO' AND detalle_venta_origen_id IS NOT NULL)
        OR (tipo_detalle = 'ENTREGADO' AND detalle_venta_origen_id IS NULL)
    ),
    CONSTRAINT ck_detalle_cambio_textos CHECK (
        btrim(codigo_producto) <> ''
        AND btrim(nombre_producto) <> ''
        AND btrim(unidad_medida) <> ''
    ),
    CONSTRAINT ck_detalle_cambio_valores CHECK (
        cantidad > 0
        AND precio_unitario >= 0
        AND (porcentaje_iva IS NULL OR porcentaje_iva BETWEEN 0 AND 100)
        AND valor_descuento >= 0
        AND valor_descuento <= precio_unitario * cantidad
        AND subtotal_neto = precio_unitario * cantidad - valor_descuento
    ),
    CONSTRAINT ck_detalle_cambio_iva_incluido CHECK (
        (
            porcentaje_iva IS NULL
            AND base_gravable IS NULL
            AND valor_iva IS NULL
        )
        OR
        (
            porcentaje_iva IS NOT NULL
            AND base_gravable IS NOT NULL
            AND base_gravable >= 0
            AND valor_iva IS NOT NULL
            AND valor_iva >= 0
            AND base_gravable = round(
                subtotal_neto * 100 / (100 + porcentaje_iva), 4
            )
            AND base_gravable + valor_iva = subtotal_neto
        )
    )
);

CREATE TABLE ventas.pago_cambio_venta (
    id                    uuid           NOT NULL,
    cambio_venta_id       uuid           NOT NULL,
    turno_caja_id         uuid           NOT NULL,
    metodo_pago_id        uuid           NOT NULL,
    usuario_id            uuid           NOT NULL,
    sesion_operador_id    uuid,
    movimiento_caja_id    uuid,
    tipo_movimiento       varchar(20)    NOT NULL,
    valor                 numeric(18,0)  NOT NULL,
    valor_recibido        numeric(18,0),
    cambio                numeric(18,0)  NOT NULL DEFAULT 0,
    referencia            varchar(200),
    fecha_hora            timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    estado                varchar(20)    NOT NULL DEFAULT 'APLICADO',
    usuario_anulacion_id  uuid,
    autorizacion_anulacion_id uuid,
    motivo_anulacion_id   uuid,
    fecha_anulacion       timestamptz,
    observacion_anulacion text,

    CONSTRAINT pk_pago_cambio_venta PRIMARY KEY (id),
    CONSTRAINT uq_pago_cambio_movimiento_caja UNIQUE (movimiento_caja_id),
    CONSTRAINT fk_pago_cambio_cambio
        FOREIGN KEY (cambio_venta_id)
        REFERENCES ventas.cambio_venta (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_cambio_turno
        FOREIGN KEY (turno_caja_id)
        REFERENCES caja.turno_caja (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_cambio_metodo
        FOREIGN KEY (metodo_pago_id)
        REFERENCES catalogo.metodo_pago (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_cambio_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_cambio_sesion
        FOREIGN KEY (sesion_operador_id)
        REFERENCES caja.sesion_operador (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_cambio_movimiento_caja
        FOREIGN KEY (movimiento_caja_id)
        REFERENCES caja.movimiento_caja (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_cambio_usuario_anulacion
        FOREIGN KEY (usuario_anulacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_cambio_autorizacion_anulacion
        FOREIGN KEY (autorizacion_anulacion_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pago_cambio_motivo_anulacion
        FOREIGN KEY (motivo_anulacion_id)
        REFERENCES configuracion.motivo_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_pago_cambio_tipo
        CHECK (tipo_movimiento IN ('COBRO', 'DEVOLUCION')),
    CONSTRAINT ck_pago_cambio_valores CHECK (
        valor > 0
        AND (
            (valor_recibido IS NULL AND cambio = 0)
            OR
            (valor_recibido IS NOT NULL
             AND tipo_movimiento = 'COBRO'
             AND valor_recibido >= valor
             AND cambio = valor_recibido - valor)
        )
    ),
    CONSTRAINT ck_pago_cambio_estado CHECK (estado IN ('APLICADO', 'ANULADO')),
    CONSTRAINT ck_pago_cambio_anulacion CHECK (
        (
            estado = 'APLICADO'
            AND usuario_anulacion_id IS NULL
            AND autorizacion_anulacion_id IS NULL
            AND motivo_anulacion_id IS NULL
            AND fecha_anulacion IS NULL
            AND observacion_anulacion IS NULL
        )
        OR
        (
            estado = 'ANULADO'
            AND usuario_anulacion_id IS NOT NULL
            AND autorizacion_anulacion_id IS NOT NULL
            AND motivo_anulacion_id IS NOT NULL
            AND fecha_anulacion IS NOT NULL
            AND (
                observacion_anulacion IS NULL
                OR btrim(observacion_anulacion) <> ''
            )
        )
    ),
    CONSTRAINT ck_pago_cambio_referencia CHECK (
        referencia IS NULL OR btrim(referencia) <> ''
    )
);

CREATE TABLE ventas.ajuste_credito_cambio (
    id                    uuid           NOT NULL,
    credito_id            uuid           NOT NULL,
    cambio_venta_id       uuid           NOT NULL,
    usuario_id            uuid           NOT NULL,
    tipo_ajuste           varchar(20)    NOT NULL,
    valor                 numeric(18,0)  NOT NULL,
    monto_ajustado_anterior numeric(18,0) NOT NULL,
    monto_ajustado_posterior numeric(18,0) NOT NULL,
    saldo_anterior        numeric(18,0)  NOT NULL,
    saldo_posterior       numeric(18,0)  NOT NULL,
    fecha_hora            timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    correlacion_id        uuid           NOT NULL,

    CONSTRAINT pk_ajuste_credito_cambio PRIMARY KEY (id),
    CONSTRAINT uq_ajuste_credito_cambio UNIQUE (cambio_venta_id),
    CONSTRAINT fk_ajuste_credito_credito
        FOREIGN KEY (credito_id)
        REFERENCES ventas.credito (id) ON DELETE RESTRICT,
    CONSTRAINT fk_ajuste_credito_cambio
        FOREIGN KEY (cambio_venta_id)
        REFERENCES ventas.cambio_venta (id) ON DELETE RESTRICT,
    CONSTRAINT fk_ajuste_credito_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT ck_ajuste_credito_tipo
        CHECK (tipo_ajuste IN ('AUMENTO', 'REDUCCION')),
    CONSTRAINT ck_ajuste_credito_valores CHECK (
        valor > 0
        AND monto_ajustado_anterior >= 0
        AND monto_ajustado_posterior >= 0
        AND saldo_anterior >= 0
        AND saldo_posterior >= 0
        AND (
            (tipo_ajuste = 'AUMENTO'
             AND monto_ajustado_posterior = monto_ajustado_anterior + valor
             AND saldo_posterior = saldo_anterior + valor)
            OR
            (tipo_ajuste = 'REDUCCION'
             AND valor <= saldo_anterior
             AND monto_ajustado_posterior = monto_ajustado_anterior - valor
             AND saldo_posterior = saldo_anterior - valor)
        )
    )
);

-- =============================================================================
-- 8. COMPRAS E INVENTARIO
-- =============================================================================

CREATE TABLE compras.pedido_compra (
    id                         uuid           NOT NULL,
    instalacion_id             uuid           NOT NULL,
    proveedor_id               uuid           NOT NULL,
    usuario_creacion_id        uuid           NOT NULL,
    prefijo                    varchar(10)    NOT NULL,
    serie                      varchar(10)    NOT NULL,
    consecutivo                bigint         NOT NULL,
    fecha_creacion             timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_envio                timestamptz,
    usuario_envio_id           uuid,
    fecha_cierre               timestamptz,
    usuario_cierre_id          uuid,
    autorizacion_cierre_id     uuid,
    motivo_cierre_id           uuid,
    observacion_cierre         text,
    fecha_cancelacion          timestamptz,
    usuario_cancelacion_id     uuid,
    autorizacion_cancelacion_id uuid,
    motivo_cancelacion_id      uuid,
    observacion_cancelacion    text,
    estado                     varchar(30)    NOT NULL DEFAULT 'BORRADOR',
    version                    bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_pedido_compra PRIMARY KEY (id),
    CONSTRAINT uq_pedido_compra_inst_serie_numero
        UNIQUE (instalacion_id, serie, consecutivo),
    CONSTRAINT fk_pedido_compra_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pedido_compra_proveedor
        FOREIGN KEY (proveedor_id)
        REFERENCES catalogo.proveedor (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pedido_compra_usuario_creacion
        FOREIGN KEY (usuario_creacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pedido_compra_usuario_envio
        FOREIGN KEY (usuario_envio_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pedido_compra_usuario_cierre
        FOREIGN KEY (usuario_cierre_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pedido_compra_autorizacion_cierre
        FOREIGN KEY (autorizacion_cierre_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pedido_compra_motivo_cierre
        FOREIGN KEY (motivo_cierre_id)
        REFERENCES configuracion.motivo_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pedido_compra_usuario_cancelacion
        FOREIGN KEY (usuario_cancelacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pedido_compra_autorizacion_cancelacion
        FOREIGN KEY (autorizacion_cancelacion_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_pedido_compra_motivo_cancelacion
        FOREIGN KEY (motivo_cancelacion_id)
        REFERENCES configuracion.motivo_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_pedido_compra_numero CHECK (
        btrim(prefijo) <> '' AND btrim(serie) <> '' AND consecutivo > 0
    ),
    CONSTRAINT ck_pedido_compra_estado CHECK (
        estado IN (
            'BORRADOR', 'ENVIADO', 'RECIBIDO_PARCIAL', 'COMPLETADO',
            'CERRADO_CON_PENDIENTES', 'CANCELADO'
        )
    ),
    CONSTRAINT ck_pedido_compra_fechas CHECK (
        (fecha_envio IS NULL OR fecha_envio >= fecha_creacion)
        AND (fecha_cierre IS NULL OR fecha_cierre >= fecha_creacion)
        AND (fecha_cancelacion IS NULL OR fecha_cancelacion >= fecha_creacion)
    ),
    CONSTRAINT ck_pedido_compra_transicion CHECK (
        (
            estado = 'BORRADOR'
            AND fecha_envio IS NULL
            AND usuario_envio_id IS NULL
            AND fecha_cierre IS NULL
            AND usuario_cierre_id IS NULL
            AND autorizacion_cierre_id IS NULL
            AND motivo_cierre_id IS NULL
            AND observacion_cierre IS NULL
            AND fecha_cancelacion IS NULL
            AND usuario_cancelacion_id IS NULL
            AND autorizacion_cancelacion_id IS NULL
            AND motivo_cancelacion_id IS NULL
            AND observacion_cancelacion IS NULL
        )
        OR
        (
            estado IN ('ENVIADO', 'RECIBIDO_PARCIAL')
            AND fecha_envio IS NOT NULL
            AND usuario_envio_id IS NOT NULL
            AND fecha_cierre IS NULL
            AND usuario_cierre_id IS NULL
            AND autorizacion_cierre_id IS NULL
            AND motivo_cierre_id IS NULL
            AND observacion_cierre IS NULL
            AND fecha_cancelacion IS NULL
            AND usuario_cancelacion_id IS NULL
            AND autorizacion_cancelacion_id IS NULL
            AND motivo_cancelacion_id IS NULL
            AND observacion_cancelacion IS NULL
        )
        OR
        (
            estado = 'COMPLETADO'
            AND fecha_envio IS NOT NULL
            AND usuario_envio_id IS NOT NULL
            AND fecha_cierre IS NOT NULL
            AND usuario_cierre_id IS NOT NULL
            AND autorizacion_cierre_id IS NULL
            AND motivo_cierre_id IS NULL
            AND observacion_cierre IS NULL
            AND fecha_cancelacion IS NULL
            AND usuario_cancelacion_id IS NULL
            AND autorizacion_cancelacion_id IS NULL
            AND motivo_cancelacion_id IS NULL
            AND observacion_cancelacion IS NULL
        )
        OR
        (
            estado = 'CERRADO_CON_PENDIENTES'
            AND fecha_envio IS NOT NULL
            AND usuario_envio_id IS NOT NULL
            AND fecha_cierre IS NOT NULL
            AND usuario_cierre_id IS NOT NULL
            AND autorizacion_cierre_id IS NOT NULL
            AND motivo_cierre_id IS NOT NULL
            AND fecha_cancelacion IS NULL
            AND usuario_cancelacion_id IS NULL
            AND autorizacion_cancelacion_id IS NULL
            AND motivo_cancelacion_id IS NULL
            AND observacion_cancelacion IS NULL
            AND (observacion_cierre IS NULL OR btrim(observacion_cierre) <> '')
        )
        OR
        (
            estado = 'CANCELADO'
            AND fecha_cierre IS NULL
            AND usuario_cierre_id IS NULL
            AND autorizacion_cierre_id IS NULL
            AND motivo_cierre_id IS NULL
            AND observacion_cierre IS NULL
            AND fecha_cancelacion IS NOT NULL
            AND usuario_cancelacion_id IS NOT NULL
            AND autorizacion_cancelacion_id IS NOT NULL
            AND motivo_cancelacion_id IS NOT NULL
            AND (
                observacion_cancelacion IS NULL
                OR btrim(observacion_cancelacion) <> ''
            )
        )
    ),
    CONSTRAINT ck_pedido_compra_version CHECK (version > 0)
);

CREATE TABLE compras.detalle_pedido_compra (
    id                         uuid           NOT NULL,
    pedido_compra_id           uuid           NOT NULL,
    producto_id                uuid           NOT NULL,
    codigo_producto            varchar(100)   NOT NULL,
    nombre_producto            varchar(200)   NOT NULL,
    stock_disponible_origen    integer        NOT NULL,
    stock_minimo_origen        integer        NOT NULL,
    pendiente_otros_pedidos    integer        NOT NULL DEFAULT 0,
    cantidad_sugerida          integer        NOT NULL,
    cantidad_solicitada        integer        NOT NULL,
    cantidad_recibida          integer        NOT NULL DEFAULT 0,
    cantidad_excedente         integer        NOT NULL DEFAULT 0,
    autorizacion_exceso_id     uuid,
    origen_necesidad           varchar(20)    NOT NULL,
    costo_estimado             numeric(18,4),
    observacion                text,
    version                    bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_detalle_pedido_compra PRIMARY KEY (id),
    CONSTRAINT uq_detalle_pedido_producto UNIQUE (pedido_compra_id, producto_id),
    CONSTRAINT fk_detalle_pedido_pedido
        FOREIGN KEY (pedido_compra_id)
        REFERENCES compras.pedido_compra (id) ON DELETE RESTRICT,
    CONSTRAINT fk_detalle_pedido_producto
        FOREIGN KEY (producto_id)
        REFERENCES catalogo.producto (id) ON DELETE RESTRICT,
    CONSTRAINT fk_detalle_pedido_autorizacion_exceso
        FOREIGN KEY (autorizacion_exceso_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_detalle_pedido_textos CHECK (
        btrim(codigo_producto) <> '' AND btrim(nombre_producto) <> ''
    ),
    CONSTRAINT ck_detalle_pedido_cantidades CHECK (
        stock_disponible_origen >= 0
        AND stock_minimo_origen >= 0
        AND pendiente_otros_pedidos >= 0
        AND cantidad_sugerida = greatest(
            0,
            stock_minimo_origen
            - (stock_disponible_origen + pendiente_otros_pedidos)
        )
        AND cantidad_solicitada > 0
        AND cantidad_recibida >= 0
        AND cantidad_excedente = greatest(0, cantidad_recibida - cantidad_solicitada)
        AND (
            cantidad_excedente = 0
            OR autorizacion_exceso_id IS NOT NULL
        )
    ),
    CONSTRAINT ck_detalle_pedido_origen
        CHECK (origen_necesidad IN ('AGOTADO', 'BAJO_MINIMO', 'MANUAL')),
    CONSTRAINT ck_detalle_pedido_costo
        CHECK (costo_estimado IS NULL OR costo_estimado >= 0),
    CONSTRAINT ck_detalle_pedido_observacion
        CHECK (observacion IS NULL OR btrim(observacion) <> ''),
    CONSTRAINT ck_detalle_pedido_version CHECK (version > 0)
);

CREATE TABLE compras.compra (
    id                           uuid           NOT NULL,
    instalacion_id               uuid           NOT NULL,
    proveedor_id                 uuid           NOT NULL,
    pedido_compra_id             uuid,
    usuario_id                   uuid           NOT NULL,
    sesion_operador_id           uuid,
    prefijo                      varchar(10),
    serie                        varchar(10),
    consecutivo                  bigint,
    numero_documento_proveedor   varchar(100),
    fecha_documento              date           NOT NULL,
    fecha_hora_registro          timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_hora_confirmacion      timestamptz,
    modo_iva                     varchar(30)    NOT NULL DEFAULT 'NO_DISCRIMINADO',
    subtotal_bruto               numeric(18,2)  NOT NULL DEFAULT 0,
    impuesto_total               numeric(18,2),
    total                        numeric(18,2)  NOT NULL DEFAULT 0,
    estado                       varchar(20)    NOT NULL DEFAULT 'BORRADOR',
    usuario_anulacion_id         uuid,
    autorizacion_anulacion_id    uuid,
    motivo_anulacion_id          uuid,
    fecha_anulacion              timestamptz,
    observacion_anulacion        text,
    version                      bigint         NOT NULL DEFAULT 1,

    CONSTRAINT pk_compra PRIMARY KEY (id),
    CONSTRAINT uq_compra_instalacion_serie_numero
        UNIQUE (instalacion_id, serie, consecutivo),
    CONSTRAINT uq_compra_proveedor_documento
        UNIQUE (proveedor_id, numero_documento_proveedor),
    CONSTRAINT fk_compra_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_compra_proveedor
        FOREIGN KEY (proveedor_id)
        REFERENCES catalogo.proveedor (id) ON DELETE RESTRICT,
    CONSTRAINT fk_compra_pedido
        FOREIGN KEY (pedido_compra_id)
        REFERENCES compras.pedido_compra (id) ON DELETE RESTRICT,
    CONSTRAINT fk_compra_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_compra_sesion
        FOREIGN KEY (sesion_operador_id)
        REFERENCES caja.sesion_operador (id) ON DELETE RESTRICT,
    CONSTRAINT fk_compra_usuario_anulacion
        FOREIGN KEY (usuario_anulacion_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_compra_autorizacion_anulacion
        FOREIGN KEY (autorizacion_anulacion_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_compra_motivo_anulacion
        FOREIGN KEY (motivo_anulacion_id)
        REFERENCES configuracion.motivo_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_compra_documento CHECK (
        numero_documento_proveedor IS NULL
        OR btrim(numero_documento_proveedor) <> ''
    ),
    CONSTRAINT ck_compra_modo_iva CHECK (
        modo_iva IN ('INCLUIDO', 'SEPARADO', 'NO_DISCRIMINADO')
    ),
    CONSTRAINT ck_compra_montos CHECK (
        subtotal_bruto >= 0
        AND total >= 0
        AND (
            (modo_iva = 'SEPARADO'
             AND impuesto_total IS NOT NULL
             AND impuesto_total >= 0
             AND total = subtotal_bruto + impuesto_total)
            OR
            (modo_iva = 'INCLUIDO'
             AND impuesto_total IS NOT NULL
             AND impuesto_total >= 0
             AND total = subtotal_bruto)
            OR
            (modo_iva = 'NO_DISCRIMINADO'
             AND impuesto_total IS NULL
             AND total = subtotal_bruto)
        )
    ),
    CONSTRAINT ck_compra_estado
        CHECK (estado IN ('BORRADOR', 'CONFIRMADA', 'ANULADA')),
    CONSTRAINT ck_compra_confirmacion CHECK (
        (
            estado = 'BORRADOR'
            AND prefijo IS NULL
            AND serie IS NULL
            AND consecutivo IS NULL
            AND fecha_hora_confirmacion IS NULL
            AND usuario_anulacion_id IS NULL
            AND autorizacion_anulacion_id IS NULL
            AND motivo_anulacion_id IS NULL
            AND fecha_anulacion IS NULL
            AND observacion_anulacion IS NULL
        )
        OR
        (
            estado = 'CONFIRMADA'
            AND prefijo IS NOT NULL
            AND serie IS NOT NULL
            AND consecutivo IS NOT NULL
            AND btrim(prefijo) <> ''
            AND btrim(serie) <> ''
            AND consecutivo > 0
            AND fecha_hora_confirmacion IS NOT NULL
            AND usuario_anulacion_id IS NULL
            AND autorizacion_anulacion_id IS NULL
            AND motivo_anulacion_id IS NULL
            AND fecha_anulacion IS NULL
            AND observacion_anulacion IS NULL
        )
        OR
        (
            estado = 'ANULADA'
            AND prefijo IS NOT NULL
            AND serie IS NOT NULL
            AND consecutivo IS NOT NULL
            AND btrim(prefijo) <> ''
            AND btrim(serie) <> ''
            AND consecutivo > 0
            AND fecha_hora_confirmacion IS NOT NULL
            AND usuario_anulacion_id IS NOT NULL
            AND autorizacion_anulacion_id IS NOT NULL
            AND motivo_anulacion_id IS NOT NULL
            AND fecha_anulacion IS NOT NULL
            AND (
                observacion_anulacion IS NULL
                OR btrim(observacion_anulacion) <> ''
            )
        )
    ),
    CONSTRAINT ck_compra_version CHECK (version > 0)
);

CREATE TABLE compras.detalle_compra (
    id                         uuid           NOT NULL,
    compra_id                  uuid           NOT NULL,
    producto_id                uuid           NOT NULL,
    detalle_pedido_compra_id   uuid,
    cantidad                   integer        NOT NULL,
    modo_iva                   varchar(30)    NOT NULL,
    costo_unitario_documento   numeric(18,4)  NOT NULL,
    porcentaje_iva             numeric(5,2),
    subtotal_bruto             numeric(18,4)  NOT NULL,
    base_gravable              numeric(18,4),
    valor_iva                  numeric(18,4),
    total_linea                numeric(18,4)  NOT NULL,
    costo_promedio_anterior    numeric(18,4),
    costo_promedio_resultante  numeric(18,4)  NOT NULL,
    precio_venta_anterior      numeric(18,0)  NOT NULL,
    precio_venta_nuevo         numeric(18,0)  NOT NULL,
    es_sustituto               boolean        NOT NULL DEFAULT false,
    autorizacion_excepcion_id  uuid,

    CONSTRAINT pk_detalle_compra PRIMARY KEY (id),
    CONSTRAINT fk_detalle_compra_compra
        FOREIGN KEY (compra_id)
        REFERENCES compras.compra (id) ON DELETE RESTRICT,
    CONSTRAINT fk_detalle_compra_producto
        FOREIGN KEY (producto_id)
        REFERENCES catalogo.producto (id) ON DELETE RESTRICT,
    CONSTRAINT fk_detalle_compra_detalle_pedido
        FOREIGN KEY (detalle_pedido_compra_id)
        REFERENCES compras.detalle_pedido_compra (id) ON DELETE RESTRICT,
    CONSTRAINT fk_detalle_compra_autorizacion_excepcion
        FOREIGN KEY (autorizacion_excepcion_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT ck_detalle_compra_valores CHECK (
        cantidad > 0
        AND costo_unitario_documento >= 0
        AND (porcentaje_iva IS NULL OR porcentaje_iva BETWEEN 0 AND 100)
        AND subtotal_bruto = costo_unitario_documento * cantidad
        AND total_linea >= 0
        AND (costo_promedio_anterior IS NULL OR costo_promedio_anterior >= 0)
        AND costo_promedio_resultante >= 0
        AND precio_venta_anterior > 0
        AND precio_venta_nuevo > 0
    ),
    CONSTRAINT ck_detalle_compra_iva CHECK (
        (
            modo_iva = 'SEPARADO'
            AND porcentaje_iva IS NOT NULL
            AND base_gravable = subtotal_bruto
            AND valor_iva IS NOT NULL
            AND valor_iva >= 0
            AND valor_iva = round(
                base_gravable * porcentaje_iva / 100, 4
            )
            AND total_linea = subtotal_bruto + valor_iva
        )
        OR
        (
            modo_iva = 'INCLUIDO'
            AND porcentaje_iva IS NOT NULL
            AND base_gravable IS NOT NULL
            AND base_gravable >= 0
            AND valor_iva IS NOT NULL
            AND valor_iva >= 0
            AND base_gravable = round(
                total_linea * 100 / (100 + porcentaje_iva), 4
            )
            AND total_linea = subtotal_bruto
            AND base_gravable + valor_iva = total_linea
        )
        OR
        (
            modo_iva = 'NO_DISCRIMINADO'
            AND porcentaje_iva IS NULL
            AND base_gravable IS NULL
            AND valor_iva IS NULL
            AND total_linea = subtotal_bruto
        )
    ),
    CONSTRAINT ck_detalle_compra_sustituto CHECK (
        (es_sustituto = false AND autorizacion_excepcion_id IS NULL)
        OR
        (es_sustituto = true
         AND detalle_pedido_compra_id IS NOT NULL
         AND autorizacion_excepcion_id IS NOT NULL)
    )
);

CREATE TABLE compras.movimiento_inventario (
    id                         uuid           NOT NULL,
    producto_id                uuid           NOT NULL,
    usuario_id                 uuid           NOT NULL,
    sesion_operador_id         uuid,
    autorizacion_operacion_id  uuid,
    motivo_operacion_id        uuid,
    venta_id                   uuid,
    compra_id                  uuid,
    apartado_id                uuid,
    cambio_venta_id            uuid,
    anulacion_venta_id         uuid,
    movimiento_revertido_id    uuid,
    tipo_movimiento            varchar(30)    NOT NULL,
    cantidad_stock             integer        NOT NULL DEFAULT 0,
    cantidad_reservada         integer        NOT NULL DEFAULT 0,
    stock_anterior             integer        NOT NULL,
    stock_posterior            integer        NOT NULL,
    reservado_anterior         integer        NOT NULL,
    reservado_posterior        integer        NOT NULL,
    costo_promedio_anterior    numeric(18,4),
    costo_promedio_posterior   numeric(18,4),
    fecha_hora                 timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    motivo                     text,
    correlacion_id             uuid           NOT NULL,

    CONSTRAINT pk_movimiento_inventario PRIMARY KEY (id),
    CONSTRAINT fk_movimiento_inventario_producto
        FOREIGN KEY (producto_id)
        REFERENCES catalogo.producto (id) ON DELETE RESTRICT,
    CONSTRAINT fk_movimiento_inventario_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_movimiento_inventario_sesion
        FOREIGN KEY (sesion_operador_id)
        REFERENCES caja.sesion_operador (id) ON DELETE RESTRICT,
    CONSTRAINT fk_movimiento_inventario_autorizacion
        FOREIGN KEY (autorizacion_operacion_id)
        REFERENCES seguridad.autorizacion_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_movimiento_inventario_motivo
        FOREIGN KEY (motivo_operacion_id)
        REFERENCES configuracion.motivo_operacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_movimiento_inventario_venta
        FOREIGN KEY (venta_id)
        REFERENCES ventas.venta (id) ON DELETE RESTRICT,
    CONSTRAINT fk_movimiento_inventario_compra
        FOREIGN KEY (compra_id)
        REFERENCES compras.compra (id) ON DELETE RESTRICT,
    CONSTRAINT fk_movimiento_inventario_apartado
        FOREIGN KEY (apartado_id)
        REFERENCES ventas.apartado (id) ON DELETE RESTRICT,
    CONSTRAINT fk_movimiento_inventario_cambio
        FOREIGN KEY (cambio_venta_id)
        REFERENCES ventas.cambio_venta (id) ON DELETE RESTRICT,
    CONSTRAINT fk_movimiento_inventario_anulacion
        FOREIGN KEY (anulacion_venta_id)
        REFERENCES ventas.anulacion_venta (id) ON DELETE RESTRICT,
    CONSTRAINT fk_movimiento_inventario_revertido
        FOREIGN KEY (movimiento_revertido_id)
        REFERENCES compras.movimiento_inventario (id) ON DELETE RESTRICT,
    CONSTRAINT ck_movimiento_inventario_tipo CHECK (
        tipo_movimiento IN (
            'COMPRA', 'ANULACION_COMPRA', 'VENTA', 'ANULACION_VENTA',
            'RESERVA_APARTADO', 'LIBERACION_APARTADO', 'ENTREGA_APARTADO',
            'CAMBIO_DEVOLUCION', 'CAMBIO_ENTREGA',
            'AJUSTE_ENTRADA', 'AJUSTE_SALIDA', 'REVERSO'
        )
    ),
    CONSTRAINT ck_movimiento_inventario_cantidades CHECK (
        (cantidad_stock <> 0 OR cantidad_reservada <> 0)
        AND stock_posterior = stock_anterior + cantidad_stock
        AND reservado_posterior = reservado_anterior + cantidad_reservada
        AND stock_anterior >= 0
        AND stock_posterior >= 0
        AND reservado_anterior >= 0
        AND reservado_posterior >= 0
        AND reservado_anterior <= stock_anterior
        AND reservado_posterior <= stock_posterior
    ),
    CONSTRAINT ck_movimiento_inventario_costos CHECK (
        (costo_promedio_anterior IS NULL OR costo_promedio_anterior >= 0)
        AND (costo_promedio_posterior IS NULL OR costo_promedio_posterior >= 0)
    ),
    CONSTRAINT ck_movimiento_inventario_ajuste CHECK (
        (
            tipo_movimiento IN ('AJUSTE_ENTRADA', 'AJUSTE_SALIDA')
            AND autorizacion_operacion_id IS NOT NULL
            AND motivo_operacion_id IS NOT NULL
        )
        OR
        (
            tipo_movimiento NOT IN ('AJUSTE_ENTRADA', 'AJUSTE_SALIDA')
            AND motivo_operacion_id IS NULL
        )
    ),
    CONSTRAINT ck_movimiento_inventario_fuente CHECK (
        num_nonnulls(
            venta_id,
            compra_id,
            apartado_id,
            cambio_venta_id,
            anulacion_venta_id,
            movimiento_revertido_id
        ) <= 1
    ),
    CONSTRAINT ck_movimiento_inventario_no_autorreferencia
        CHECK (movimiento_revertido_id IS NULL OR movimiento_revertido_id <> id)
);

-- =============================================================================
-- 9. DOCUMENTOS INMUTABLES Y COLA DE IMPRESION
-- =============================================================================

CREATE TABLE configuracion.documento_emitido (
    id                    uuid           NOT NULL,
    instalacion_id        uuid           NOT NULL,
    terminal_id           uuid           NOT NULL,
    emitido_por_id        uuid           NOT NULL,
    tipo_documento        varchar(40)    NOT NULL,
    entidad_tipo          varchar(100)   NOT NULL,
    entidad_id            uuid           NOT NULL,
    numero_visible        varchar(100),
    version_documento     integer        NOT NULL DEFAULT 1,
    datos_snapshot        jsonb          NOT NULL,
    plantilla_snapshot    jsonb          NOT NULL,
    hash_snapshot         varchar(128)   NOT NULL,
    fecha_emision         timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT pk_documento_emitido PRIMARY KEY (id),
    CONSTRAINT uq_documento_emitido_origen
        UNIQUE (instalacion_id, tipo_documento, entidad_id, version_documento),
    CONSTRAINT fk_documento_emitido_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_documento_emitido_terminal
        FOREIGN KEY (terminal_id)
        REFERENCES configuracion.terminal (id) ON DELETE RESTRICT,
    CONSTRAINT fk_documento_emitido_usuario
        FOREIGN KEY (emitido_por_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT ck_documento_emitido_tipo CHECK (
        tipo_documento IN (
            'COMPROBANTE_VENTA', 'RECIBO_PAGO_CREDITO',
            'COMPROBANTE_APARTADO', 'RECIBO_PAGO_APARTADO',
            'COMPROBANTE_CAMBIO', 'COMPROBANTE_COMPRA',
            'PEDIDO_COMPRA', 'CIERRE_CAJA',
            'ETIQUETA_PRODUCTO'
        )
    ),
    CONSTRAINT ck_documento_emitido_entidad CHECK (btrim(entidad_tipo) <> ''),
    CONSTRAINT ck_documento_emitido_numero CHECK (
        numero_visible IS NULL OR btrim(numero_visible) <> ''
    ),
    CONSTRAINT ck_documento_emitido_version CHECK (version_documento > 0),
    CONSTRAINT ck_documento_emitido_hash CHECK (btrim(hash_snapshot) <> '')
);

CREATE TABLE configuracion.trabajo_impresion (
    id                    uuid           NOT NULL,
    documento_emitido_id  uuid           NOT NULL,
    perfil_impresora_id   uuid           NOT NULL,
    plantilla_impresion_id uuid          NOT NULL,
    terminal_id           uuid           NOT NULL,
    solicitado_por_id     uuid           NOT NULL,
    clave_idempotencia    varchar(100)   NOT NULL,
    tipo_copia            varchar(20)    NOT NULL DEFAULT 'ORIGINAL',
    numero_reimpresion    integer        NOT NULL DEFAULT 0,
    estado                varchar(20)    NOT NULL DEFAULT 'PENDIENTE',
    intentos              integer        NOT NULL DEFAULT 0,
    contenido_renderizado bytea          NOT NULL,
    hash_contenido        varchar(128)   NOT NULL,
    fecha_solicitud       timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_ultimo_intento  timestamptz,
    fecha_impresion       timestamptz,
    error_sanitizado      text,

    CONSTRAINT pk_trabajo_impresion PRIMARY KEY (id),
    CONSTRAINT uq_trabajo_impresion_idempotencia
        UNIQUE (terminal_id, clave_idempotencia),
    CONSTRAINT uq_trabajo_impresion_copia
        UNIQUE (documento_emitido_id, tipo_copia, numero_reimpresion),
    CONSTRAINT fk_trabajo_impresion_documento
        FOREIGN KEY (documento_emitido_id)
        REFERENCES configuracion.documento_emitido (id) ON DELETE RESTRICT,
    CONSTRAINT fk_trabajo_impresion_perfil
        FOREIGN KEY (perfil_impresora_id)
        REFERENCES configuracion.perfil_impresora (id) ON DELETE RESTRICT,
    CONSTRAINT fk_trabajo_impresion_plantilla
        FOREIGN KEY (plantilla_impresion_id)
        REFERENCES configuracion.plantilla_impresion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_trabajo_impresion_terminal
        FOREIGN KEY (terminal_id)
        REFERENCES configuracion.terminal (id) ON DELETE RESTRICT,
    CONSTRAINT fk_trabajo_impresion_usuario
        FOREIGN KEY (solicitado_por_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT ck_trabajo_impresion_clave CHECK (btrim(clave_idempotencia) <> ''),
    CONSTRAINT ck_trabajo_impresion_tipo CHECK (
        (tipo_copia = 'ORIGINAL' AND numero_reimpresion = 0)
        OR
        (tipo_copia = 'REIMPRESION' AND numero_reimpresion > 0)
    ),
    CONSTRAINT ck_trabajo_impresion_estado CHECK (
        estado IN ('PENDIENTE', 'IMPRIMIENDO', 'IMPRESO', 'FALLIDO', 'CANCELADO')
    ),
    CONSTRAINT ck_trabajo_impresion_intentos CHECK (intentos >= 0),
    CONSTRAINT ck_trabajo_impresion_hash CHECK (btrim(hash_contenido) <> ''),
    CONSTRAINT ck_trabajo_impresion_final CHECK (
        (estado = 'IMPRESO' AND fecha_impresion IS NOT NULL)
        OR estado <> 'IMPRESO'
    )
);

CREATE FUNCTION configuracion.bloquear_documento_emitido_inmutable()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
BEGIN
    RAISE EXCEPTION
        'Los documentos emitidos son inmutables; cree un nuevo documento o una reimpresion.';
END;
$funcion$;

CREATE TRIGGER tg_documento_emitido_inmutable
BEFORE UPDATE OR DELETE ON configuracion.documento_emitido
FOR EACH ROW
EXECUTE FUNCTION configuracion.bloquear_documento_emitido_inmutable();

-- =============================================================================
-- 10. AUDITORIA E IDEMPOTENCIA
-- =============================================================================

CREATE TABLE auditoria.evento_auditoria (
    id                       uuid           NOT NULL,
    usuario_id               uuid,
    usuario_autorizador_id   uuid,
    sesion_operador_id       uuid,
    instalacion_id           uuid           NOT NULL,
    terminal_id              uuid,
    fecha_hora               timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    accion                   varchar(100)   NOT NULL,
    entidad                  varchar(100),
    entidad_id               uuid,
    resultado                varchar(20)    NOT NULL,
    motivo                   text,
    datos_anteriores         jsonb,
    datos_nuevos             jsonb,
    correlacion_id           uuid           NOT NULL,

    CONSTRAINT pk_evento_auditoria PRIMARY KEY (id),
    CONSTRAINT fk_evento_auditoria_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_evento_auditoria_autorizador
        FOREIGN KEY (usuario_autorizador_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_evento_auditoria_sesion
        FOREIGN KEY (sesion_operador_id)
        REFERENCES caja.sesion_operador (id) ON DELETE RESTRICT,
    CONSTRAINT fk_evento_auditoria_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_evento_auditoria_terminal
        FOREIGN KEY (terminal_id)
        REFERENCES configuracion.terminal (id) ON DELETE RESTRICT,
    CONSTRAINT ck_evento_auditoria_accion CHECK (btrim(accion) <> ''),
    CONSTRAINT ck_evento_auditoria_resultado
        CHECK (resultado IN ('EXITOSO', 'FALLIDO')),
    CONSTRAINT ck_evento_auditoria_entidad CHECK (
        (entidad IS NULL AND entidad_id IS NULL)
        OR (entidad IS NOT NULL AND btrim(entidad) <> '')
    )
);

CREATE TABLE auditoria.operacion_idempotente (
    id                    uuid           NOT NULL,
    instalacion_id        uuid           NOT NULL,
    terminal_id           uuid           NOT NULL,
    usuario_id            uuid           NOT NULL,
    sesion_operador_id    uuid,
    clave_idempotencia    varchar(100)   NOT NULL,
    tipo_operacion        varchar(100)   NOT NULL,
    hash_solicitud        varchar(128)   NOT NULL,
    entidad               varchar(100),
    entidad_id            uuid,
    resultado             jsonb,
    correlacion_id        uuid           NOT NULL,
    fecha_registro        timestamptz    NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT pk_operacion_idempotente PRIMARY KEY (id),
    CONSTRAINT uq_idempotente_instalacion_clave
        UNIQUE (instalacion_id, clave_idempotencia),
    CONSTRAINT fk_idempotente_instalacion
        FOREIGN KEY (instalacion_id)
        REFERENCES configuracion.instalacion (id) ON DELETE RESTRICT,
    CONSTRAINT fk_idempotente_terminal
        FOREIGN KEY (terminal_id)
        REFERENCES configuracion.terminal (id) ON DELETE RESTRICT,
    CONSTRAINT fk_idempotente_usuario
        FOREIGN KEY (usuario_id)
        REFERENCES seguridad.usuario (id) ON DELETE RESTRICT,
    CONSTRAINT fk_idempotente_sesion
        FOREIGN KEY (sesion_operador_id)
        REFERENCES caja.sesion_operador (id) ON DELETE RESTRICT,
    CONSTRAINT ck_idempotente_clave CHECK (btrim(clave_idempotencia) <> ''),
    CONSTRAINT ck_idempotente_tipo CHECK (btrim(tipo_operacion) <> ''),
    CONSTRAINT ck_idempotente_hash CHECK (btrim(hash_solicitud) <> ''),
    CONSTRAINT ck_idempotente_entidad CHECK (
        (entidad IS NULL AND entidad_id IS NULL)
        OR (entidad IS NOT NULL AND btrim(entidad) <> '')
    )
);

-- =============================================================================
-- 11. REGLAS TRANSACCIONALES ENTRE TABLAS
-- =============================================================================

CREATE FUNCTION configuracion.validar_cambio_modo_turno()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
BEGIN
    IF NEW.modo_turno_predeterminado IS DISTINCT FROM OLD.modo_turno_predeterminado
       AND (
           EXISTS (
               SELECT 1
               FROM caja.turno_caja t
               JOIN caja.caja c ON c.id = t.caja_id
               JOIN configuracion.instalacion i ON i.id = c.instalacion_id
               WHERE i.establecimiento_id = NEW.id
                 AND t.estado = 'ABIERTA'
           )
           OR EXISTS (
               SELECT 1
               FROM ventas.borrador_venta b
               JOIN configuracion.instalacion i ON i.id = b.instalacion_id
               WHERE i.establecimiento_id = NEW.id
                 AND b.estado IN ('ACTIVO', 'RECUPERADO')
           )
           OR EXISTS (
               SELECT 1
               FROM caja.sesion_operador s
               JOIN caja.turno_caja t ON t.id = s.turno_caja_id
               JOIN caja.caja c ON c.id = t.caja_id
               JOIN configuracion.instalacion i ON i.id = c.instalacion_id
               WHERE i.establecimiento_id = NEW.id
                 AND s.estado = 'ACTIVA'
           )
       )
    THEN
        RAISE EXCEPTION
            'No se puede cambiar el modo de turno con un turno abierto o una venta en borrador.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_establecimiento_validar_modo_turno
BEFORE UPDATE OF modo_turno_predeterminado ON configuracion.establecimiento
FOR EACH ROW
EXECUTE FUNCTION configuracion.validar_cambio_modo_turno();

CREATE FUNCTION seguridad.validar_credencial_autorizador()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
BEGIN
    IF NEW.metodo_autenticacion = 'CODIGO_BARRAS_PIN'
       AND NOT EXISTS (
           SELECT 1
           FROM seguridad.credencial_usuario c
           WHERE c.id = NEW.credencial_autorizador_id
             AND c.usuario_id = NEW.usuario_autorizador_id
             AND c.estado = 'ACTIVA'
             AND (c.fecha_vencimiento IS NULL OR c.fecha_vencimiento > CURRENT_TIMESTAMP)
       )
    THEN
        RAISE EXCEPTION
            'La credencial usada para autorizar no pertenece al autorizador o no esta activa.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_autorizacion_validar_credencial
BEFORE INSERT OR UPDATE OF usuario_autorizador_id, credencial_autorizador_id,
    metodo_autenticacion, estado
ON seguridad.autorizacion_operacion
FOR EACH ROW EXECUTE FUNCTION seguridad.validar_credencial_autorizador();

CREATE FUNCTION configuracion.validar_tipo_motivo()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_motivo_id uuid;
BEGIN
    v_motivo_id := (to_jsonb(NEW) ->> TG_ARGV[0])::uuid;

    IF v_motivo_id IS NOT NULL
       AND NOT EXISTS (
           SELECT 1
           FROM configuracion.motivo_operacion m
           WHERE m.id = v_motivo_id
             AND m.tipo_operacion = TG_ARGV[1]
             AND m.activo = true
       )
    THEN
        RAISE EXCEPTION
            'El motivo seleccionado no corresponde al tipo de operacion %.',
            TG_ARGV[1];
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_turno_validar_motivo_diferencia
BEFORE INSERT OR UPDATE OF motivo_diferencia_id ON caja.turno_caja
FOR EACH ROW EXECUTE FUNCTION configuracion.validar_tipo_motivo(
    'motivo_diferencia_id', 'DIFERENCIA_CIERRE'
);

CREATE TRIGGER tg_pago_venta_validar_motivo_anulacion
BEFORE INSERT OR UPDATE OF motivo_anulacion_id ON ventas.pago_venta
FOR EACH ROW EXECUTE FUNCTION configuracion.validar_tipo_motivo(
    'motivo_anulacion_id', 'ANULACION_PAGO'
);

CREATE TRIGGER tg_anulacion_venta_validar_motivo
BEFORE INSERT OR UPDATE OF motivo_operacion_id ON ventas.anulacion_venta
FOR EACH ROW EXECUTE FUNCTION configuracion.validar_tipo_motivo(
    'motivo_operacion_id', 'ANULACION_VENTA'
);

CREATE TRIGGER tg_pago_credito_validar_motivo_anulacion
BEFORE INSERT OR UPDATE OF motivo_anulacion_id ON ventas.pago_credito
FOR EACH ROW EXECUTE FUNCTION configuracion.validar_tipo_motivo(
    'motivo_anulacion_id', 'ANULACION_PAGO'
);

CREATE TRIGGER tg_apartado_validar_motivo_anulacion
BEFORE INSERT OR UPDATE OF motivo_anulacion_id ON ventas.apartado
FOR EACH ROW EXECUTE FUNCTION configuracion.validar_tipo_motivo(
    'motivo_anulacion_id', 'CANCELACION_APARTADO'
);

CREATE TRIGGER tg_pago_apartado_validar_motivo_anulacion
BEFORE INSERT OR UPDATE OF motivo_anulacion_id ON ventas.pago_apartado
FOR EACH ROW EXECUTE FUNCTION configuracion.validar_tipo_motivo(
    'motivo_anulacion_id', 'ANULACION_PAGO'
);

CREATE TRIGGER tg_pago_cambio_validar_motivo_anulacion
BEFORE INSERT OR UPDATE OF motivo_anulacion_id ON ventas.pago_cambio_venta
FOR EACH ROW EXECUTE FUNCTION configuracion.validar_tipo_motivo(
    'motivo_anulacion_id', 'ANULACION_PAGO'
);

CREATE TRIGGER tg_cambio_validar_motivo_anulacion
BEFORE INSERT OR UPDATE OF motivo_anulacion_id ON ventas.cambio_venta
FOR EACH ROW EXECUTE FUNCTION configuracion.validar_tipo_motivo(
    'motivo_anulacion_id', 'ANULACION_CAMBIO'
);

CREATE TRIGGER tg_pedido_validar_motivo_cierre
BEFORE INSERT OR UPDATE OF motivo_cierre_id ON compras.pedido_compra
FOR EACH ROW EXECUTE FUNCTION configuracion.validar_tipo_motivo(
    'motivo_cierre_id', 'CIERRE_PEDIDO_PENDIENTE'
);

CREATE TRIGGER tg_pedido_validar_motivo_cancelacion
BEFORE INSERT OR UPDATE OF motivo_cancelacion_id ON compras.pedido_compra
FOR EACH ROW EXECUTE FUNCTION configuracion.validar_tipo_motivo(
    'motivo_cancelacion_id', 'CANCELACION_PEDIDO'
);

CREATE TRIGGER tg_compra_validar_motivo_anulacion
BEFORE INSERT OR UPDATE OF motivo_anulacion_id ON compras.compra
FOR EACH ROW EXECUTE FUNCTION configuracion.validar_tipo_motivo(
    'motivo_anulacion_id', 'ANULACION_COMPRA'
);

CREATE TRIGGER tg_mov_inventario_validar_motivo
BEFORE INSERT OR UPDATE OF motivo_operacion_id ON compras.movimiento_inventario
FOR EACH ROW EXECUTE FUNCTION configuracion.validar_tipo_motivo(
    'motivo_operacion_id', 'AJUSTE_INVENTARIO'
);

CREATE FUNCTION caja.validar_inicio_sesion_operador()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
BEGIN
    IF NEW.estado = 'ACTIVA'
       AND NOT EXISTS (
           SELECT 1
           FROM caja.turno_caja t
           JOIN seguridad.credencial_usuario c
             ON c.id = NEW.credencial_usuario_id
            AND c.usuario_id = NEW.usuario_id
           WHERE t.id = NEW.turno_caja_id
             AND t.terminal_id = NEW.terminal_id
             AND t.modo_operacion = 'COMPARTIDO'
             AND t.estado = 'ABIERTA'
             AND c.estado = 'ACTIVA'
             AND (c.fecha_vencimiento IS NULL OR c.fecha_vencimiento > CURRENT_TIMESTAMP)
       )
    THEN
        RAISE EXCEPTION
            'La sesion rapida requiere turno COMPARTIDO abierto y credencial activa del operador.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_sesion_operador_validar_inicio
BEFORE INSERT OR UPDATE OF turno_caja_id, terminal_id, usuario_id,
    credencial_usuario_id, estado
ON caja.sesion_operador
FOR EACH ROW
EXECUTE FUNCTION caja.validar_inicio_sesion_operador();

CREATE FUNCTION caja.validar_cierre_turno_sesiones()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
BEGIN
    IF NEW.estado = 'CERRADA'
       AND EXISTS (
           SELECT 1
           FROM caja.sesion_operador s
           WHERE s.turno_caja_id = NEW.id
             AND s.estado = 'ACTIVA'
       )
    THEN
        RAISE EXCEPTION
            'Debe cerrar la sesion rapida activa antes de cerrar el turno.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_turno_caja_validar_sesiones
BEFORE UPDATE OF estado ON caja.turno_caja
FOR EACH ROW
EXECUTE FUNCTION caja.validar_cierre_turno_sesiones();

CREATE FUNCTION caja.proteger_modo_turno_historico()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
BEGIN
    IF NEW.modo_operacion IS DISTINCT FROM OLD.modo_operacion
       OR NEW.usuario_responsable_id IS DISTINCT FROM OLD.usuario_responsable_id
    THEN
        RAISE EXCEPTION
            'El modo y el responsable son datos historicos inmutables del turno.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_turno_caja_proteger_modo
BEFORE UPDATE OF modo_operacion, usuario_responsable_id ON caja.turno_caja
FOR EACH ROW
EXECUTE FUNCTION caja.proteger_modo_turno_historico();

CREATE FUNCTION caja.actor_valido_turno(
    p_turno_caja_id uuid,
    p_usuario_id uuid,
    p_sesion_operador_id uuid
)
RETURNS boolean
LANGUAGE sql
STABLE
AS $funcion$
    SELECT COALESCE((
        SELECT CASE
            WHEN t.modo_operacion = 'INDIVIDUAL' THEN
                p_sesion_operador_id IS NULL
                AND t.usuario_responsable_id = p_usuario_id
            WHEN t.modo_operacion = 'COMPARTIDO' THEN
                p_sesion_operador_id IS NOT NULL
                AND EXISTS (
                    SELECT 1
                    FROM caja.sesion_operador s
                    JOIN seguridad.credencial_usuario c
                      ON c.id = s.credencial_usuario_id
                    WHERE s.id = p_sesion_operador_id
                      AND s.turno_caja_id = t.id
                      AND s.terminal_id = t.terminal_id
                      AND s.usuario_id = p_usuario_id
                      AND s.estado = 'ACTIVA'
                      AND c.usuario_id = p_usuario_id
                      AND c.estado = 'ACTIVA'
                      AND (
                          c.fecha_vencimiento IS NULL
                          OR c.fecha_vencimiento > CURRENT_TIMESTAMP
                      )
                )
            ELSE false
        END
        FROM caja.turno_caja t
        WHERE t.id = p_turno_caja_id
          AND t.estado = 'ABIERTA'
    ), false);
$funcion$;

CREATE FUNCTION caja.validar_actor_operacion()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
BEGIN
    IF NOT caja.actor_valido_turno(
        NEW.turno_caja_id,
        NEW.usuario_id,
        NEW.sesion_operador_id
    )
    THEN
        RAISE EXCEPTION
            'El operador o la sesion no corresponden al modo del turno de caja.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_borrador_venta_validar_actor
BEFORE INSERT OR UPDATE OF turno_caja_id, usuario_id, sesion_operador_id
ON ventas.borrador_venta
FOR EACH ROW EXECUTE FUNCTION caja.validar_actor_operacion();

CREATE TRIGGER tg_venta_validar_actor
BEFORE INSERT OR UPDATE OF turno_caja_id, usuario_id, sesion_operador_id
ON ventas.venta
FOR EACH ROW EXECUTE FUNCTION caja.validar_actor_operacion();

CREATE TRIGGER tg_pago_credito_validar_actor
BEFORE INSERT OR UPDATE OF turno_caja_id, usuario_id, sesion_operador_id
ON ventas.pago_credito
FOR EACH ROW EXECUTE FUNCTION caja.validar_actor_operacion();

CREATE TRIGGER tg_apartado_validar_actor
BEFORE INSERT OR UPDATE OF turno_caja_id, usuario_id, sesion_operador_id
ON ventas.apartado
FOR EACH ROW EXECUTE FUNCTION caja.validar_actor_operacion();

CREATE TRIGGER tg_pago_apartado_validar_actor
BEFORE INSERT OR UPDATE OF turno_caja_id, usuario_id, sesion_operador_id
ON ventas.pago_apartado
FOR EACH ROW EXECUTE FUNCTION caja.validar_actor_operacion();

CREATE TRIGGER tg_reembolso_apartado_validar_actor
BEFORE INSERT OR UPDATE OF turno_caja_id, usuario_id, sesion_operador_id
ON ventas.reembolso_apartado
FOR EACH ROW EXECUTE FUNCTION caja.validar_actor_operacion();

CREATE TRIGGER tg_cambio_venta_validar_actor
BEFORE INSERT OR UPDATE OF turno_caja_id, usuario_id, sesion_operador_id
ON ventas.cambio_venta
FOR EACH ROW EXECUTE FUNCTION caja.validar_actor_operacion();

CREATE TRIGGER tg_pago_cambio_validar_actor
BEFORE INSERT OR UPDATE OF turno_caja_id, usuario_id, sesion_operador_id
ON ventas.pago_cambio_venta
FOR EACH ROW EXECUTE FUNCTION caja.validar_actor_operacion();

CREATE FUNCTION caja.validar_actor_movimiento_caja()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_usuario_apertura uuid;
BEGIN
    IF NEW.tipo = 'APERTURA' THEN
        SELECT usuario_apertura_id
          INTO v_usuario_apertura
          FROM caja.turno_caja
         WHERE id = NEW.turno_caja_id;

        IF v_usuario_apertura IS NULL
           OR NEW.usuario_id <> v_usuario_apertura
           OR NEW.sesion_operador_id IS NOT NULL
        THEN
            RAISE EXCEPTION
                'El movimiento de apertura debe pertenecer al usuario que abrio el turno.';
        END IF;
    ELSIF NOT caja.actor_valido_turno(
        NEW.turno_caja_id,
        NEW.usuario_id,
        NEW.sesion_operador_id
    ) THEN
        RAISE EXCEPTION
            'El operador o la sesion no corresponden al movimiento de caja.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_movimiento_caja_validar_actor
BEFORE INSERT OR UPDATE OF turno_caja_id, usuario_id, sesion_operador_id, tipo
ON caja.movimiento_caja
FOR EACH ROW EXECUTE FUNCTION caja.validar_actor_movimiento_caja();

CREATE FUNCTION ventas.validar_actor_pago_venta()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_turno_caja_id uuid;
BEGIN
    SELECT turno_caja_id
      INTO v_turno_caja_id
      FROM ventas.venta
     WHERE id = NEW.venta_id;

    IF NOT caja.actor_valido_turno(
        v_turno_caja_id,
        NEW.usuario_id,
        NEW.sesion_operador_id
    )
    THEN
        RAISE EXCEPTION
            'El operador o la sesion no corresponden al pago de la venta.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_pago_venta_validar_actor
BEFORE INSERT OR UPDATE OF venta_id, usuario_id, sesion_operador_id
ON ventas.pago_venta
FOR EACH ROW EXECUTE FUNCTION ventas.validar_actor_pago_venta();

CREATE FUNCTION ventas.validar_cierre_sesion_venta()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
BEGIN
    IF NEW.sesion_operador_id IS NOT NULL
       AND EXISTS (
           SELECT 1
           FROM caja.sesion_operador s
           WHERE s.id = NEW.sesion_operador_id
             AND s.estado = 'ACTIVA'
       )
    THEN
        RAISE EXCEPTION
            'La sesion rapida debe cerrarse al confirmar la venta; el siguiente operador debe escanear su credencial.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE CONSTRAINT TRIGGER tg_venta_validar_cierre_sesion
AFTER INSERT OR UPDATE OF sesion_operador_id ON ventas.venta
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_cierre_sesion_venta();

CREATE FUNCTION ventas.validar_anulacion_venta()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_venta_id uuid;
    v_estado varchar(20);
    v_anulaciones integer;
BEGIN
    IF TG_TABLE_NAME = 'venta' THEN
        v_venta_id := NEW.id;
    ELSIF TG_OP = 'DELETE' THEN
        v_venta_id := OLD.venta_id;
    ELSE
        v_venta_id := NEW.venta_id;
    END IF;

    SELECT estado
      INTO v_estado
      FROM ventas.venta
     WHERE id = v_venta_id;

    IF NOT FOUND THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;

    SELECT count(*)
      INTO v_anulaciones
      FROM ventas.anulacion_venta
     WHERE venta_id = v_venta_id;

    IF (v_estado = 'CONFIRMADA' AND v_anulaciones <> 0)
       OR (v_estado = 'ANULADA' AND v_anulaciones <> 1)
    THEN
        RAISE EXCEPTION
            'El estado de la venta no coincide con su registro de anulacion.';
    END IF;

    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE CONSTRAINT TRIGGER tg_venta_validar_anulacion_cabecera
AFTER INSERT OR UPDATE ON ventas.venta
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_anulacion_venta();

CREATE CONSTRAINT TRIGGER tg_venta_validar_anulacion_registro
AFTER INSERT OR UPDATE OR DELETE ON ventas.anulacion_venta
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_anulacion_venta();

CREATE FUNCTION ventas.proteger_estado_venta()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
BEGIN
    IF NEW.estado IS DISTINCT FROM OLD.estado
       AND NOT (OLD.estado = 'CONFIRMADA' AND NEW.estado = 'ANULADA')
    THEN
        RAISE EXCEPTION 'Transicion de estado no permitida para la venta.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_venta_proteger_estado
BEFORE UPDATE OF estado ON ventas.venta
FOR EACH ROW EXECUTE FUNCTION ventas.proteger_estado_venta();

CREATE FUNCTION ventas.proteger_datos_venta_confirmada()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
BEGIN
    IF (to_jsonb(NEW) - ARRAY['estado', 'version'])
       IS DISTINCT FROM
       (to_jsonb(OLD) - ARRAY['estado', 'version'])
    THEN
        RAISE EXCEPTION
            'Los datos comerciales de una venta confirmada son inmutables.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_venta_proteger_datos
BEFORE UPDATE ON ventas.venta
FOR EACH ROW EXECUTE FUNCTION ventas.proteger_datos_venta_confirmada();

CREATE FUNCTION ventas.proteger_detalle_venta()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
BEGIN
    RAISE EXCEPTION
        'Los productos historicos de una venta no se modifican ni eliminan.';
END;
$funcion$;

CREATE TRIGGER tg_detalle_venta_inmutable
BEFORE UPDATE OR DELETE ON ventas.detalle_venta
FOR EACH ROW EXECUTE FUNCTION ventas.proteger_detalle_venta();

CREATE FUNCTION ventas.proteger_pago_historico()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
BEGIN
    IF OLD.estado = 'ANULADO' AND to_jsonb(NEW) IS DISTINCT FROM to_jsonb(OLD) THEN
        RAISE EXCEPTION 'Un pago anulado es completamente inmutable.';
    END IF;

    IF NEW.estado IS DISTINCT FROM OLD.estado
       AND NOT (OLD.estado = 'APLICADO' AND NEW.estado = 'ANULADO')
    THEN
        RAISE EXCEPTION 'Transicion de estado no permitida para el pago.';
    END IF;

    IF (to_jsonb(NEW) - ARRAY[
            'estado',
            'usuario_anulacion_id',
            'autorizacion_anulacion_id',
            'motivo_anulacion_id',
            'fecha_anulacion',
            'observacion_anulacion'
        ])
       IS DISTINCT FROM
       (to_jsonb(OLD) - ARRAY[
            'estado',
            'usuario_anulacion_id',
            'autorizacion_anulacion_id',
            'motivo_anulacion_id',
            'fecha_anulacion',
            'observacion_anulacion'
        ])
    THEN
        RAISE EXCEPTION
            'Los valores historicos de un pago aplicado son inmutables.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_pago_venta_proteger_historial
BEFORE UPDATE ON ventas.pago_venta
FOR EACH ROW EXECUTE FUNCTION ventas.proteger_pago_historico();

CREATE TRIGGER tg_pago_credito_proteger_historial
BEFORE UPDATE ON ventas.pago_credito
FOR EACH ROW EXECUTE FUNCTION ventas.proteger_pago_historico();

CREATE TRIGGER tg_pago_apartado_proteger_historial
BEFORE UPDATE ON ventas.pago_apartado
FOR EACH ROW EXECUTE FUNCTION ventas.proteger_pago_historico();

CREATE TRIGGER tg_pago_cambio_proteger_historial
BEFORE UPDATE ON ventas.pago_cambio_venta
FOR EACH ROW EXECUTE FUNCTION ventas.proteger_pago_historico();

CREATE FUNCTION ventas.validar_contacto_cliente_operacion()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_cliente_id uuid;
    v_tiene_contacto boolean;
BEGIN
    IF TG_TABLE_NAME = 'credito' THEN
        SELECT v.cliente_id
          INTO v_cliente_id
          FROM ventas.venta v
         WHERE v.id = NEW.venta_id;
    ELSE
        v_cliente_id := NEW.cliente_id;
    END IF;

    SELECT (
        (tipo_documento IS NOT NULL AND numero_documento IS NOT NULL)
        OR (telefono IS NOT NULL AND btrim(telefono) <> '')
    )
      INTO v_tiene_contacto
      FROM catalogo.cliente
     WHERE id = v_cliente_id;

    IF COALESCE(v_tiene_contacto, false) = false THEN
        RAISE EXCEPTION
            'Un credito o apartado requiere documento completo o telefono del cliente.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_credito_validar_contacto_cliente
BEFORE INSERT OR UPDATE OF venta_id ON ventas.credito
FOR EACH ROW EXECUTE FUNCTION ventas.validar_contacto_cliente_operacion();

CREATE TRIGGER tg_apartado_validar_contacto_cliente
BEFORE INSERT OR UPDATE OF cliente_id ON ventas.apartado
FOR EACH ROW EXECUTE FUNCTION ventas.validar_contacto_cliente_operacion();

CREATE FUNCTION catalogo.proteger_contacto_cliente_cartera()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
BEGIN
    IF NOT (
        (NEW.tipo_documento IS NOT NULL AND NEW.numero_documento IS NOT NULL)
        OR (NEW.telefono IS NOT NULL AND btrim(NEW.telefono) <> '')
    )
       AND (
           EXISTS (
               SELECT 1
               FROM ventas.venta v
               JOIN ventas.credito c ON c.venta_id = v.id
               WHERE v.cliente_id = NEW.id
                 AND c.estado IN ('PENDIENTE', 'VENCIDO')
           )
           OR EXISTS (
               SELECT 1
               FROM ventas.apartado a
               WHERE a.cliente_id = NEW.id
                 AND a.estado IN ('ACTIVO', 'PAGADO')
           )
       )
    THEN
        RAISE EXCEPTION
            'No se puede retirar documento y telefono mientras el cliente tenga cartera o apartados activos.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_cliente_proteger_contacto_cartera
BEFORE UPDATE OF tipo_documento, numero_documento, telefono
ON catalogo.cliente
FOR EACH ROW EXECUTE FUNCTION catalogo.proteger_contacto_cliente_cartera();

CREATE FUNCTION ventas.validar_cambio_venta()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_estado_venta varchar(20);
    v_fecha_limite date;
    v_fecha_local date;
    v_credito_id uuid;
    v_estado_credito varchar(20);
BEGIN
    SELECT v.estado,
           v.fecha_limite_cambio,
           (NEW.fecha_hora AT TIME ZONE e.zona_horaria)::date,
           c.id,
           c.estado
      INTO v_estado_venta,
           v_fecha_limite,
           v_fecha_local,
           v_credito_id,
           v_estado_credito
      FROM ventas.venta v
      JOIN configuracion.instalacion i ON i.id = v.instalacion_id
      JOIN configuracion.establecimiento e ON e.id = i.establecimiento_id
      LEFT JOIN ventas.credito c ON c.venta_id = v.id
     WHERE v.id = NEW.venta_id;

    IF v_estado_venta IS NULL OR v_estado_venta <> 'CONFIRMADA' THEN
        RAISE EXCEPTION 'Solo se permiten cambios sobre ventas confirmadas.';
    END IF;

    IF v_fecha_local > v_fecha_limite THEN
        RAISE EXCEPTION 'La venta se encuentra fuera del plazo permitido para cambios.';
    END IF;

    IF v_credito_id IS NOT NULL
       AND v_estado_credito IN ('PENDIENTE', 'VENCIDO')
       AND NEW.credito_id IS DISTINCT FROM v_credito_id
    THEN
        RAISE EXCEPTION
            'El cambio de una venta con credito pendiente debe vincular ese credito.';
    END IF;

    IF v_credito_id IS NOT NULL
       AND v_estado_credito NOT IN ('PENDIENTE', 'VENCIDO')
       AND NEW.credito_id IS NOT NULL
    THEN
        RAISE EXCEPTION
            'Un credito pagado o anulado no puede recibir ajustes por cambio.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_cambio_venta_validar_origen
BEFORE INSERT OR UPDATE OF venta_id, credito_id, fecha_hora
ON ventas.cambio_venta
FOR EACH ROW EXECUTE FUNCTION ventas.validar_cambio_venta();

CREATE FUNCTION ventas.validar_detalle_cambio_origen()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_venta_cambio_id uuid;
    v_venta_detalle_id uuid;
    v_producto_origen_id uuid;
BEGIN
    IF NEW.tipo_detalle = 'ENTREGADO' THEN
        RETURN NEW;
    END IF;

    SELECT venta_id
      INTO v_venta_cambio_id
      FROM ventas.cambio_venta
     WHERE id = NEW.cambio_venta_id;

    SELECT venta_id, producto_id
      INTO v_venta_detalle_id, v_producto_origen_id
      FROM ventas.detalle_venta
     WHERE id = NEW.detalle_venta_origen_id;

    IF v_venta_detalle_id IS DISTINCT FROM v_venta_cambio_id
       OR v_producto_origen_id IS DISTINCT FROM NEW.producto_id
    THEN
        RAISE EXCEPTION
            'El producto devuelto debe pertenecer a la venta y linea originales.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_detalle_cambio_validar_origen
BEFORE INSERT OR UPDATE OF cambio_venta_id, detalle_venta_origen_id,
    producto_id, tipo_detalle
ON ventas.detalle_cambio_venta
FOR EACH ROW EXECUTE FUNCTION ventas.validar_detalle_cambio_origen();

CREATE FUNCTION ventas.validar_cantidad_devuelta()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_detalle_origen_id uuid;
    v_cantidad_vendida integer;
    v_cantidad_devuelta integer;
BEGIN
    IF TG_OP = 'DELETE' THEN
        v_detalle_origen_id := OLD.detalle_venta_origen_id;
    ELSE
        v_detalle_origen_id := NEW.detalle_venta_origen_id;
    END IF;

    IF v_detalle_origen_id IS NULL THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;

    SELECT cantidad
      INTO v_cantidad_vendida
      FROM ventas.detalle_venta
     WHERE id = v_detalle_origen_id;

    SELECT COALESCE(sum(d.cantidad), 0)
      INTO v_cantidad_devuelta
      FROM ventas.detalle_cambio_venta d
      JOIN ventas.cambio_venta c ON c.id = d.cambio_venta_id
     WHERE d.detalle_venta_origen_id = v_detalle_origen_id
       AND d.tipo_detalle = 'DEVUELTO'
       AND c.estado = 'CONFIRMADO';

    IF v_cantidad_devuelta > v_cantidad_vendida THEN
        RAISE EXCEPTION
            'La cantidad acumulada devuelta supera la cantidad vendida.';
    END IF;

    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE CONSTRAINT TRIGGER tg_detalle_cambio_validar_cantidad
AFTER INSERT OR UPDATE OR DELETE ON ventas.detalle_cambio_venta
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_cantidad_devuelta();

CREATE FUNCTION compras.validar_producto_pedido()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_proveedor_producto uuid;
    v_producto_activo boolean;
    v_proveedor_pedido uuid;
    v_proveedor_activo boolean;
    v_estado_pedido varchar(30);
BEGIN
    SELECT p.proveedor_id, p.activo
      INTO v_proveedor_producto, v_producto_activo
      FROM catalogo.producto p
     WHERE p.id = NEW.producto_id;

    SELECT pc.proveedor_id, pr.activo, pc.estado
      INTO v_proveedor_pedido, v_proveedor_activo, v_estado_pedido
      FROM compras.pedido_compra pc
      JOIN catalogo.proveedor pr ON pr.id = pc.proveedor_id
     WHERE pc.id = NEW.pedido_compra_id;

    IF v_estado_pedido <> 'BORRADOR' THEN
        RAISE EXCEPTION
            'Solo se pueden agregar o sustituir lineas en un pedido BORRADOR.';
    END IF;

    IF COALESCE(v_producto_activo, false) = false THEN
        RAISE EXCEPTION 'No se puede pedir un producto inactivo.';
    END IF;

    IF v_proveedor_producto IS NULL THEN
        RAISE EXCEPTION
            'El producto esta Sin proveedor y no puede agregarse automaticamente al pedido.';
    END IF;

    IF COALESCE(v_proveedor_activo, false) = false THEN
        RAISE EXCEPTION
            'El proveedor asignado esta inactivo y debe reemplazarse antes de crear el pedido.';
    END IF;

    IF v_proveedor_producto <> v_proveedor_pedido THEN
        RAISE EXCEPTION
            'El producto debe agruparse en el pedido de su proveedor asignado.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE FUNCTION compras.proteger_pedido_compra()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
BEGIN
    IF OLD.estado <> 'BORRADOR'
       AND ROW(
           NEW.instalacion_id,
           NEW.proveedor_id,
           NEW.usuario_creacion_id,
           NEW.prefijo,
           NEW.serie,
           NEW.consecutivo,
           NEW.fecha_creacion
       ) IS DISTINCT FROM ROW(
           OLD.instalacion_id,
           OLD.proveedor_id,
           OLD.usuario_creacion_id,
           OLD.prefijo,
           OLD.serie,
           OLD.consecutivo,
           OLD.fecha_creacion
       )
    THEN
        RAISE EXCEPTION 'Los datos comerciales de un pedido enviado son inmutables.';
    END IF;

    IF NEW.estado IS DISTINCT FROM OLD.estado
       AND NOT (
           (OLD.estado = 'BORRADOR'
            AND NEW.estado IN ('ENVIADO', 'CANCELADO'))
           OR
           (OLD.estado = 'ENVIADO'
            AND NEW.estado IN (
                'RECIBIDO_PARCIAL', 'COMPLETADO',
                'CERRADO_CON_PENDIENTES', 'CANCELADO'
            ))
           OR
           (OLD.estado = 'RECIBIDO_PARCIAL'
            AND NEW.estado IN ('COMPLETADO', 'CERRADO_CON_PENDIENTES'))
       )
    THEN
        RAISE EXCEPTION 'Transicion de estado no permitida para el pedido de compra.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_pedido_compra_proteger_historial
BEFORE UPDATE ON compras.pedido_compra
FOR EACH ROW EXECUTE FUNCTION compras.proteger_pedido_compra();

CREATE TRIGGER tg_detalle_pedido_validar_proveedor
BEFORE INSERT OR UPDATE OF pedido_compra_id, producto_id
ON compras.detalle_pedido_compra
FOR EACH ROW EXECUTE FUNCTION compras.validar_producto_pedido();

CREATE FUNCTION compras.proteger_pedido_enviado()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_pedido_compra_id uuid;
    v_estado varchar(30);
BEGIN
    v_pedido_compra_id := CASE
        WHEN TG_OP = 'DELETE' THEN OLD.pedido_compra_id
        ELSE NEW.pedido_compra_id
    END;

    SELECT estado
      INTO v_estado
      FROM compras.pedido_compra
     WHERE id = v_pedido_compra_id;

    IF v_estado <> 'BORRADOR' THEN
        IF TG_OP = 'DELETE' THEN
            RAISE EXCEPTION 'Las lineas de un pedido enviado son inmutables.';
        END IF;

        IF ROW(
            NEW.pedido_compra_id,
            NEW.producto_id,
            NEW.codigo_producto,
            NEW.nombre_producto,
            NEW.stock_disponible_origen,
            NEW.stock_minimo_origen,
            NEW.pendiente_otros_pedidos,
            NEW.cantidad_sugerida,
            NEW.cantidad_solicitada,
            NEW.origen_necesidad,
            NEW.costo_estimado,
            NEW.observacion
        ) IS DISTINCT FROM ROW(
            OLD.pedido_compra_id,
            OLD.producto_id,
            OLD.codigo_producto,
            OLD.nombre_producto,
            OLD.stock_disponible_origen,
            OLD.stock_minimo_origen,
            OLD.pendiente_otros_pedidos,
            OLD.cantidad_sugerida,
            OLD.cantidad_solicitada,
            OLD.origen_necesidad,
            OLD.costo_estimado,
            OLD.observacion
        ) THEN
            RAISE EXCEPTION
                'Un pedido enviado solo admite actualizar las cantidades recibidas.';
        END IF;
    END IF;

    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_detalle_pedido_proteger_enviado
BEFORE UPDATE OR DELETE ON compras.detalle_pedido_compra
FOR EACH ROW EXECUTE FUNCTION compras.proteger_pedido_enviado();

CREATE FUNCTION compras.validar_recepcion_pedido()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_proveedor_id uuid;
    v_estado varchar(30);
BEGIN
    IF NEW.pedido_compra_id IS NULL THEN
        RETURN NEW;
    END IF;

    SELECT proveedor_id, estado
      INTO v_proveedor_id, v_estado
      FROM compras.pedido_compra
     WHERE id = NEW.pedido_compra_id;

    IF v_proveedor_id IS DISTINCT FROM NEW.proveedor_id THEN
        RAISE EXCEPTION
            'La recepcion debe conservar el proveedor historico del pedido.';
    END IF;

    IF v_estado NOT IN ('ENVIADO', 'RECIBIDO_PARCIAL') THEN
        RAISE EXCEPTION
            'Solo un pedido enviado o recibido parcialmente puede generar una compra.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_compra_validar_pedido
BEFORE INSERT OR UPDATE OF pedido_compra_id, proveedor_id
ON compras.compra
FOR EACH ROW EXECUTE FUNCTION compras.validar_recepcion_pedido();

CREATE FUNCTION compras.proteger_compra_historica()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
BEGIN
    IF OLD.estado = 'ANULADA' AND to_jsonb(NEW) IS DISTINCT FROM to_jsonb(OLD) THEN
        RAISE EXCEPTION 'Una compra anulada es completamente inmutable.';
    END IF;

    IF NEW.estado IS DISTINCT FROM OLD.estado
       AND NOT (
           (OLD.estado = 'BORRADOR' AND NEW.estado = 'CONFIRMADA')
           OR
           (OLD.estado = 'CONFIRMADA' AND NEW.estado = 'ANULADA')
       )
    THEN
        RAISE EXCEPTION 'Transicion de estado no permitida para la compra.';
    END IF;

    IF OLD.estado = 'CONFIRMADA'
       AND (to_jsonb(NEW) - ARRAY[
               'estado',
               'usuario_anulacion_id',
               'autorizacion_anulacion_id',
               'motivo_anulacion_id',
               'fecha_anulacion',
               'observacion_anulacion',
               'version'
           ])
           IS DISTINCT FROM
           (to_jsonb(OLD) - ARRAY[
               'estado',
               'usuario_anulacion_id',
               'autorizacion_anulacion_id',
               'motivo_anulacion_id',
               'fecha_anulacion',
               'observacion_anulacion',
               'version'
           ])
    THEN
        RAISE EXCEPTION
            'Los datos comerciales de una compra confirmada son inmutables.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_compra_proteger_historial
BEFORE UPDATE ON compras.compra
FOR EACH ROW EXECUTE FUNCTION compras.proteger_compra_historica();

CREATE FUNCTION compras.proteger_detalle_compra()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_compra_id uuid;
    v_estado varchar(20);
BEGIN
    IF TG_OP = 'DELETE' THEN
        v_compra_id := OLD.compra_id;
    ELSE
        v_compra_id := NEW.compra_id;
    END IF;

    SELECT estado
      INTO v_estado
      FROM compras.compra
     WHERE id = v_compra_id;

    IF v_estado <> 'BORRADOR' THEN
        RAISE EXCEPTION
            'Las lineas de una compra confirmada o anulada son inmutables.';
    END IF;

    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_detalle_compra_proteger_historial
BEFORE INSERT OR UPDATE OR DELETE ON compras.detalle_compra
FOR EACH ROW EXECUTE FUNCTION compras.proteger_detalle_compra();

CREATE FUNCTION compras.validar_detalle_recepcion()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_pedido_compra_id uuid;
    v_modo_iva varchar(30);
    v_producto_pedido_id uuid;
BEGIN
    SELECT pedido_compra_id, modo_iva
      INTO v_pedido_compra_id, v_modo_iva
      FROM compras.compra
     WHERE id = NEW.compra_id;

    IF NEW.modo_iva <> v_modo_iva THEN
        RAISE EXCEPTION
            'El tratamiento de IVA de la linea debe coincidir con el de la compra.';
    END IF;

    IF v_pedido_compra_id IS NULL AND NEW.detalle_pedido_compra_id IS NOT NULL THEN
        RAISE EXCEPTION
            'Una compra directa no puede referenciar una linea de pedido.';
    END IF;

    IF NEW.detalle_pedido_compra_id IS NOT NULL THEN
        SELECT producto_id
          INTO v_producto_pedido_id
          FROM compras.detalle_pedido_compra
         WHERE id = NEW.detalle_pedido_compra_id
           AND pedido_compra_id = v_pedido_compra_id;

        IF v_producto_pedido_id IS NULL THEN
            RAISE EXCEPTION
                'La linea recibida no pertenece al pedido de la compra.';
        END IF;

        IF NEW.producto_id <> v_producto_pedido_id
           AND (
               NEW.es_sustituto = false
               OR NEW.autorizacion_excepcion_id IS NULL
           )
        THEN
            RAISE EXCEPTION
                'Un producto sustituto requiere autorizacion explicita.';
        END IF;

        IF NEW.producto_id = v_producto_pedido_id
           AND NEW.es_sustituto = true
        THEN
            RAISE EXCEPTION
                'La linea no puede marcarse como sustituto si conserva el producto pedido.';
        END IF;
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_detalle_compra_validar_recepcion
BEFORE INSERT OR UPDATE OF compra_id, producto_id, detalle_pedido_compra_id,
    modo_iva, es_sustituto, autorizacion_excepcion_id
ON compras.detalle_compra
FOR EACH ROW EXECUTE FUNCTION compras.validar_detalle_recepcion();

CREATE FUNCTION seguridad.limite_descuento_usuario(p_usuario_id uuid)
RETURNS numeric
LANGUAGE sql
STABLE
AS $funcion$
    SELECT COALESCE(max(l.valor_maximo), 0)
    FROM seguridad.usuario_rol ur
    JOIN seguridad.rol r
      ON r.id = ur.rol_id
     AND r.activo = true
    JOIN seguridad.limite_operacion_rol l
      ON l.rol_id = r.id
     AND l.activo = true
     AND l.codigo_operacion = 'DESCUENTO_PORCENTAJE'
     AND l.tipo_limite = 'PORCENTAJE'
    WHERE ur.usuario_id = p_usuario_id;
$funcion$;

CREATE FUNCTION ventas.validar_totales_venta()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_venta_id uuid;
    v_cabecera ventas.venta%ROWTYPE;
    v_lineas integer;
    v_subtotal numeric;
    v_descuento numeric;
    v_total numeric;
    v_base numeric;
    v_iva numeric;
    v_iva_completo boolean;
    v_lineas_producto integer;
    v_lineas_venta integer;
    v_lineas_ninguna integer;
    v_debajo_costo boolean;
    v_limite numeric;
    v_porcentaje_efectivo numeric;
    v_pagos numeric;
BEGIN
    IF TG_TABLE_NAME = 'venta' THEN
        v_venta_id := NEW.id;
    ELSIF TG_OP = 'DELETE' THEN
        v_venta_id := OLD.venta_id;
    ELSE
        v_venta_id := NEW.venta_id;
    END IF;

    SELECT *
      INTO v_cabecera
      FROM ventas.venta
     WHERE id = v_venta_id;

    IF NOT FOUND THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;

        RETURN NEW;
    END IF;

    SELECT count(*),
           COALESCE(sum(subtotal_bruto), 0),
           COALESCE(sum(valor_descuento), 0),
           COALESCE(sum(subtotal_neto), 0),
           COALESCE(sum(base_gravable), 0),
           COALESCE(sum(valor_iva), 0),
           COALESCE(bool_and(porcentaje_iva IS NOT NULL), false),
           count(*) FILTER (WHERE origen_descuento = 'PRODUCTO'),
           count(*) FILTER (WHERE origen_descuento = 'VENTA'),
           count(*) FILTER (WHERE origen_descuento = 'NINGUNO'),
           COALESCE(bool_or(
               costo_unitario IS NOT NULL
               AND subtotal_neto < costo_unitario * cantidad
           ), false)
      INTO v_lineas,
           v_subtotal,
           v_descuento,
           v_total,
           v_base,
           v_iva,
           v_iva_completo,
           v_lineas_producto,
           v_lineas_venta,
           v_lineas_ninguna,
           v_debajo_costo
      FROM ventas.detalle_venta
     WHERE venta_id = v_venta_id;

    IF v_lineas = 0 THEN
        RAISE EXCEPTION 'Una venta confirmada debe contener al menos un producto.';
    END IF;

    IF v_cabecera.subtotal_bruto <> v_subtotal
       OR v_cabecera.descuento_total <> v_descuento
       OR v_cabecera.total <> v_total
    THEN
        RAISE EXCEPTION
            'Los totales de la venta no coinciden con la suma de sus productos.';
    END IF;

    IF (v_cabecera.ambito_descuento = 'NINGUNO'
        AND (v_lineas_producto <> 0 OR v_lineas_venta <> 0))
       OR (v_cabecera.ambito_descuento = 'PRODUCTO'
           AND (v_lineas_producto = 0 OR v_lineas_venta <> 0))
       OR (v_cabecera.ambito_descuento = 'VENTA'
           AND (v_lineas_venta <> v_lineas OR v_lineas_ninguna <> 0))
    THEN
        RAISE EXCEPTION
            'Una venta no puede mezclar descuento por producto y descuento global.';
    END IF;

    IF v_cabecera.ambito_descuento = 'VENTA'
       AND (
           (v_cabecera.tipo_descuento = 'PORCENTAJE'
            AND v_cabecera.descuento_total <>
                round(
                    v_cabecera.subtotal_bruto
                    * v_cabecera.valor_descuento_solicitado / 100,
                    0
                ))
           OR
           (v_cabecera.tipo_descuento = 'VALOR_FIJO'
            AND v_cabecera.descuento_total <>
                round(v_cabecera.valor_descuento_solicitado, 0))
       )
    THEN
        RAISE EXCEPTION
            'El descuento global debe redondearse al peso colombiano mas cercano.';
    END IF;

    IF EXISTS (
        SELECT 1
        FROM ventas.detalle_venta d
        WHERE d.venta_id = v_venta_id
          AND d.origen_descuento = 'PRODUCTO'
          AND d.tipo_descuento = 'PORCENTAJE'
          AND d.valor_descuento <>
              round(d.subtotal_bruto * d.porcentaje_descuento / 100, 0)
    )
    THEN
        RAISE EXCEPTION
            'El descuento porcentual de producto debe redondearse al peso mas cercano.';
    END IF;

    IF v_cabecera.iva_discriminado_completo <> v_iva_completo
       OR (
           v_iva_completo
           AND (
               v_cabecera.base_gravable_total <> v_base
               OR v_cabecera.impuesto_incluido_total <> v_iva
           )
       )
    THEN
        RAISE EXCEPTION
            'La discriminacion de IVA incluido no coincide con las lineas de venta.';
    END IF;

    v_limite := seguridad.limite_descuento_usuario(v_cabecera.usuario_id);
    v_porcentaje_efectivo := CASE
        WHEN v_cabecera.subtotal_bruto = 0 THEN 0
        ELSE v_cabecera.descuento_total * 100.0 / v_cabecera.subtotal_bruto
    END;

    IF v_cabecera.total = 0 AND v_cabecera.descuento_total > 0 AND v_limite < 100 THEN
        RAISE EXCEPTION
            'Una venta con descuento del 100 por ciento requiere un rol con limite de 100.';
    END IF;

    IF (v_porcentaje_efectivo > v_limite OR v_debajo_costo)
       AND v_cabecera.autorizacion_descuento_id IS NULL
    THEN
        RAISE EXCEPTION
            'El descuento supera el limite o vende bajo costo y requiere autorizacion.';
    END IF;

    IF v_cabecera.autorizacion_descuento_id IS NOT NULL
       AND NOT EXISTS (
           SELECT 1
           FROM seguridad.autorizacion_operacion a
           WHERE a.id = v_cabecera.autorizacion_descuento_id
             AND a.usuario_solicitante_id = v_cabecera.usuario_id
             AND a.estado IN ('AUTORIZADA', 'UTILIZADA')
       )
    THEN
        RAISE EXCEPTION 'La autorizacion de descuento no es valida para el operador.';
    END IF;

    SELECT COALESCE(sum(valor_aplicado), 0)
      INTO v_pagos
      FROM ventas.pago_venta
     WHERE venta_id = v_venta_id
       AND estado = 'APLICADO';

    IF v_cabecera.estado = 'CONFIRMADA'
       AND v_cabecera.tipo_venta = 'CONTADO'
       AND v_pagos <> v_cabecera.total
    THEN
        RAISE EXCEPTION
            'Una venta de contado debe quedar pagada exactamente por su total.';
    END IF;

    IF v_pagos > v_cabecera.total THEN
        RAISE EXCEPTION 'Los pagos aplicados superan el total de la venta.';
    END IF;

    IF v_cabecera.total = 0 AND v_pagos <> 0 THEN
        RAISE EXCEPTION 'Una venta con total cero no debe registrar pagos.';
    END IF;

    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE CONSTRAINT TRIGGER tg_venta_validar_totales_cabecera
AFTER INSERT OR UPDATE ON ventas.venta
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_totales_venta();

CREATE CONSTRAINT TRIGGER tg_venta_validar_totales_detalle
AFTER INSERT OR UPDATE OR DELETE ON ventas.detalle_venta
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_totales_venta();

CREATE CONSTRAINT TRIGGER tg_venta_validar_totales_pago
AFTER INSERT OR UPDATE OR DELETE ON ventas.pago_venta
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_totales_venta();

CREATE FUNCTION ventas.validar_totales_apartado()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_apartado_id uuid;
    v_cabecera ventas.apartado%ROWTYPE;
    v_lineas integer;
    v_subtotal numeric;
    v_descuento numeric;
    v_total numeric;
    v_base numeric;
    v_iva numeric;
    v_iva_completo boolean;
    v_lineas_producto integer;
    v_lineas_venta integer;
    v_lineas_ninguna integer;
    v_debajo_costo boolean;
    v_limite numeric;
    v_porcentaje_efectivo numeric;
    v_pagos numeric;
BEGIN
    IF TG_TABLE_NAME = 'apartado' THEN
        v_apartado_id := NEW.id;
    ELSIF TG_OP = 'DELETE' THEN
        v_apartado_id := OLD.apartado_id;
    ELSE
        v_apartado_id := NEW.apartado_id;
    END IF;

    SELECT *
      INTO v_cabecera
      FROM ventas.apartado
     WHERE id = v_apartado_id;

    IF NOT FOUND THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;

    SELECT count(*),
           COALESCE(sum(subtotal_bruto), 0),
           COALESCE(sum(valor_descuento), 0),
           COALESCE(sum(subtotal_neto), 0),
           COALESCE(sum(base_gravable), 0),
           COALESCE(sum(valor_iva), 0),
           COALESCE(bool_and(porcentaje_iva IS NOT NULL), false),
           count(*) FILTER (WHERE origen_descuento = 'PRODUCTO'),
           count(*) FILTER (WHERE origen_descuento = 'VENTA'),
           count(*) FILTER (WHERE origen_descuento = 'NINGUNO'),
           COALESCE(bool_or(
               costo_unitario IS NOT NULL
               AND subtotal_neto < costo_unitario * cantidad
           ), false)
      INTO v_lineas,
           v_subtotal,
           v_descuento,
           v_total,
           v_base,
           v_iva,
           v_iva_completo,
           v_lineas_producto,
           v_lineas_venta,
           v_lineas_ninguna,
           v_debajo_costo
      FROM ventas.detalle_apartado
     WHERE apartado_id = v_apartado_id;

    IF v_lineas = 0 THEN
        RAISE EXCEPTION 'Un apartado debe contener al menos un producto.';
    END IF;

    IF v_cabecera.subtotal_bruto <> v_subtotal
       OR v_cabecera.descuento_total <> v_descuento
       OR v_cabecera.total <> v_total
    THEN
        RAISE EXCEPTION
            'Los totales del apartado no coinciden con la suma de sus productos.';
    END IF;

    IF (v_cabecera.ambito_descuento = 'NINGUNO'
        AND (v_lineas_producto <> 0 OR v_lineas_venta <> 0))
       OR (v_cabecera.ambito_descuento = 'PRODUCTO'
           AND (v_lineas_producto = 0 OR v_lineas_venta <> 0))
       OR (v_cabecera.ambito_descuento = 'VENTA'
           AND (v_lineas_venta <> v_lineas OR v_lineas_ninguna <> 0))
    THEN
        RAISE EXCEPTION
            'Un apartado no puede mezclar descuento por producto y descuento global.';
    END IF;

    IF v_cabecera.ambito_descuento = 'VENTA'
       AND (
           (v_cabecera.tipo_descuento = 'PORCENTAJE'
            AND v_cabecera.descuento_total <>
                round(
                    v_cabecera.subtotal_bruto
                    * v_cabecera.valor_descuento_solicitado / 100,
                    0
                ))
           OR
           (v_cabecera.tipo_descuento = 'VALOR_FIJO'
            AND v_cabecera.descuento_total <>
                round(v_cabecera.valor_descuento_solicitado, 0))
       )
    THEN
        RAISE EXCEPTION
            'El descuento global del apartado debe redondearse al peso mas cercano.';
    END IF;

    IF EXISTS (
        SELECT 1
        FROM ventas.detalle_apartado d
        WHERE d.apartado_id = v_apartado_id
          AND d.origen_descuento = 'PRODUCTO'
          AND d.tipo_descuento = 'PORCENTAJE'
          AND d.valor_descuento <>
              round(d.subtotal_bruto * d.porcentaje_descuento / 100, 0)
    )
    THEN
        RAISE EXCEPTION
            'El descuento porcentual del producto debe redondearse al peso mas cercano.';
    END IF;

    IF v_cabecera.iva_discriminado_completo <> v_iva_completo
       OR (
           v_iva_completo
           AND (
               v_cabecera.base_gravable_total <> v_base
               OR v_cabecera.impuesto_incluido_total <> v_iva
           )
       )
    THEN
        RAISE EXCEPTION
            'La discriminacion de IVA incluido no coincide con el apartado.';
    END IF;

    v_limite := seguridad.limite_descuento_usuario(v_cabecera.usuario_id);
    v_porcentaje_efectivo :=
        v_cabecera.descuento_total * 100.0 / v_cabecera.subtotal_bruto;

    IF (v_porcentaje_efectivo > v_limite OR v_debajo_costo)
       AND v_cabecera.autorizacion_descuento_id IS NULL
    THEN
        RAISE EXCEPTION
            'El descuento del apartado supera el limite o vende bajo costo.';
    END IF;

    IF v_cabecera.autorizacion_descuento_id IS NOT NULL
       AND NOT EXISTS (
           SELECT 1
           FROM seguridad.autorizacion_operacion a
           WHERE a.id = v_cabecera.autorizacion_descuento_id
             AND a.usuario_solicitante_id = v_cabecera.usuario_id
             AND a.estado IN ('AUTORIZADA', 'UTILIZADA')
       )
    THEN
        RAISE EXCEPTION
            'La autorizacion de descuento del apartado no es valida.';
    END IF;

    SELECT COALESCE(sum(valor_aplicado), 0)
      INTO v_pagos
      FROM ventas.pago_apartado
     WHERE apartado_id = v_apartado_id
       AND estado = 'APLICADO';

    IF v_cabecera.estado <> 'ANULADO'
       AND v_pagos <> v_cabecera.total - v_cabecera.saldo_pendiente
    THEN
        RAISE EXCEPTION
            'El saldo del apartado no coincide con sus pagos aplicados.';
    END IF;

    IF v_cabecera.estado <> 'ANULADO'
       AND v_pagos < v_cabecera.abono_inicial
    THEN
        RAISE EXCEPTION
            'Los pagos del apartado no cubren el abono inicial registrado.';
    END IF;

    IF v_cabecera.estado = 'ANULADO'
       AND v_cabecera.total_abonado_cancelacion <> v_pagos
    THEN
        RAISE EXCEPTION
            'El total abonado al cancelar no coincide con los pagos historicos del apartado.';
    END IF;

    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE CONSTRAINT TRIGGER tg_apartado_validar_totales_cabecera
AFTER INSERT OR UPDATE ON ventas.apartado
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_totales_apartado();

CREATE CONSTRAINT TRIGGER tg_apartado_validar_totales_detalle
AFTER INSERT OR UPDATE OR DELETE ON ventas.detalle_apartado
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_totales_apartado();

CREATE CONSTRAINT TRIGGER tg_apartado_validar_totales_pago
AFTER INSERT OR UPDATE OR DELETE ON ventas.pago_apartado
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_totales_apartado();

CREATE FUNCTION ventas.validar_reembolsos_apartado()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_apartado_id uuid;
    v_estado varchar(20);
    v_valor_declarado numeric;
    v_valor_registrado numeric;
BEGIN
    IF TG_TABLE_NAME = 'apartado' THEN
        v_apartado_id := NEW.id;
    ELSIF TG_OP = 'DELETE' THEN
        v_apartado_id := OLD.apartado_id;
    ELSE
        v_apartado_id := NEW.apartado_id;
    END IF;

    SELECT estado, valor_devuelto_cancelacion
      INTO v_estado, v_valor_declarado
      FROM ventas.apartado
     WHERE id = v_apartado_id;

    IF NOT FOUND THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;

    SELECT COALESCE(sum(valor), 0)
      INTO v_valor_registrado
      FROM ventas.reembolso_apartado
     WHERE apartado_id = v_apartado_id;

    IF v_estado <> 'ANULADO' AND v_valor_registrado <> 0 THEN
        RAISE EXCEPTION
            'Solo un apartado anulado puede registrar reembolsos.';
    END IF;

    IF v_estado = 'ANULADO'
       AND v_valor_registrado <> COALESCE(v_valor_declarado, 0)
    THEN
        RAISE EXCEPTION
            'Los reembolsos no coinciden con el valor decidido al cancelar el apartado.';
    END IF;

    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE CONSTRAINT TRIGGER tg_apartado_validar_reembolso_cabecera
AFTER INSERT OR UPDATE ON ventas.apartado
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_reembolsos_apartado();

CREATE CONSTRAINT TRIGGER tg_apartado_validar_reembolso_detalle
AFTER INSERT OR UPDATE OR DELETE ON ventas.reembolso_apartado
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_reembolsos_apartado();

CREATE FUNCTION ventas.validar_datos_cobro()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_afecta_efectivo boolean;
    v_requiere_referencia boolean;
BEGIN
    SELECT afecta_efectivo, requiere_referencia
      INTO v_afecta_efectivo, v_requiere_referencia
      FROM catalogo.metodo_pago
     WHERE id = NEW.metodo_pago_id;

    IF v_afecta_efectivo THEN
        IF NEW.valor_recibido IS NULL THEN
            RAISE EXCEPTION
                'El pago en efectivo requiere registrar el valor recibido.';
        END IF;
    ELSIF NEW.valor_recibido IS NOT NULL OR NEW.cambio <> 0 THEN
        RAISE EXCEPTION
            'Los medios distintos de efectivo no usan valor recibido ni cambio.';
    END IF;

    IF v_requiere_referencia
       AND (NEW.referencia IS NULL OR btrim(NEW.referencia) = '')
    THEN
        RAISE EXCEPTION 'El medio de pago requiere una referencia.';
    END IF;

    IF NOT v_requiere_referencia AND NEW.referencia IS NOT NULL
       AND btrim(NEW.referencia) = ''
    THEN
        RAISE EXCEPTION 'La referencia opcional no puede estar vacia.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_pago_venta_validar_datos
BEFORE INSERT OR UPDATE OF metodo_pago_id, valor_recibido, cambio, referencia
ON ventas.pago_venta
FOR EACH ROW EXECUTE FUNCTION ventas.validar_datos_cobro();

CREATE TRIGGER tg_pago_credito_validar_datos
BEFORE INSERT OR UPDATE OF metodo_pago_id, valor_recibido, cambio, referencia
ON ventas.pago_credito
FOR EACH ROW EXECUTE FUNCTION ventas.validar_datos_cobro();

CREATE TRIGGER tg_pago_apartado_validar_datos
BEFORE INSERT OR UPDATE OF metodo_pago_id, valor_recibido, cambio, referencia
ON ventas.pago_apartado
FOR EACH ROW EXECUTE FUNCTION ventas.validar_datos_cobro();

CREATE FUNCTION ventas.validar_datos_pago_cambio()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_afecta_efectivo boolean;
    v_requiere_referencia boolean;
BEGIN
    SELECT afecta_efectivo, requiere_referencia
      INTO v_afecta_efectivo, v_requiere_referencia
      FROM catalogo.metodo_pago
     WHERE id = NEW.metodo_pago_id;

    IF NEW.tipo_movimiento = 'DEVOLUCION' THEN
        IF NEW.valor_recibido IS NOT NULL OR NEW.cambio <> 0 THEN
            RAISE EXCEPTION
                'Una devolucion no registra valor recibido ni cambio.';
        END IF;
    ELSIF v_afecta_efectivo AND NEW.valor_recibido IS NULL THEN
        RAISE EXCEPTION
            'El cobro en efectivo requiere registrar el valor recibido.';
    ELSIF NOT v_afecta_efectivo
          AND (NEW.valor_recibido IS NOT NULL OR NEW.cambio <> 0)
    THEN
        RAISE EXCEPTION
            'Los cobros distintos de efectivo no usan valor recibido ni cambio.';
    END IF;

    IF v_requiere_referencia
       AND (NEW.referencia IS NULL OR btrim(NEW.referencia) = '')
    THEN
        RAISE EXCEPTION 'El medio de pago requiere una referencia.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_pago_cambio_validar_datos
BEFORE INSERT OR UPDATE OF metodo_pago_id, tipo_movimiento,
    valor_recibido, cambio, referencia
ON ventas.pago_cambio_venta
FOR EACH ROW EXECUTE FUNCTION ventas.validar_datos_pago_cambio();

CREATE FUNCTION ventas.validar_liquidacion_cambio()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_cambio_id uuid;
    v_cambio ventas.cambio_venta%ROWTYPE;
    v_cobros numeric;
    v_devoluciones numeric;
    v_cantidad_ajustes integer;
    v_tipo_ajuste varchar(20);
    v_valor_ajuste numeric;
    v_credito_ajuste uuid;
    v_total_devuelto numeric;
    v_total_entregado numeric;
    v_lineas_devueltas integer;
    v_lineas_entregadas integer;
BEGIN
    IF TG_TABLE_NAME = 'cambio_venta' THEN
        v_cambio_id := NEW.id;
    ELSIF TG_OP = 'DELETE' THEN
        v_cambio_id := OLD.cambio_venta_id;
    ELSE
        v_cambio_id := NEW.cambio_venta_id;
    END IF;

    SELECT *
      INTO v_cambio
      FROM ventas.cambio_venta
     WHERE id = v_cambio_id;

    IF NOT FOUND THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;

    IF v_cambio.estado = 'CONFIRMADO' THEN
        SELECT COALESCE(sum(subtotal_neto) FILTER (
                   WHERE tipo_detalle = 'DEVUELTO'
               ), 0),
               COALESCE(sum(subtotal_neto) FILTER (
                   WHERE tipo_detalle = 'ENTREGADO'
               ), 0),
               count(*) FILTER (WHERE tipo_detalle = 'DEVUELTO'),
               count(*) FILTER (WHERE tipo_detalle = 'ENTREGADO')
          INTO v_total_devuelto,
               v_total_entregado,
               v_lineas_devueltas,
               v_lineas_entregadas
          FROM ventas.detalle_cambio_venta
         WHERE cambio_venta_id = v_cambio_id;

        IF v_lineas_devueltas = 0
           OR v_lineas_entregadas = 0
           OR v_total_devuelto <> v_cambio.total_devuelto
           OR v_total_entregado <> v_cambio.total_entregado
        THEN
            RAISE EXCEPTION
                'Los totales del cambio no coinciden con los productos devueltos y entregados.';
        END IF;

        SELECT COALESCE(sum(valor) FILTER (
                   WHERE estado = 'APLICADO' AND tipo_movimiento = 'COBRO'
               ), 0),
               COALESCE(sum(valor) FILTER (
                   WHERE estado = 'APLICADO' AND tipo_movimiento = 'DEVOLUCION'
               ), 0)
          INTO v_cobros, v_devoluciones
          FROM ventas.pago_cambio_venta
         WHERE cambio_venta_id = v_cambio_id;

        IF (v_cambio.diferencia > 0
            AND (v_cobros <> v_cambio.valor_pago_o_devolucion
                 OR v_devoluciones <> 0))
           OR (v_cambio.diferencia < 0
               AND (v_devoluciones <> v_cambio.valor_pago_o_devolucion
                    OR v_cobros <> 0))
           OR (v_cambio.diferencia = 0
               AND (v_cobros <> 0 OR v_devoluciones <> 0))
        THEN
            RAISE EXCEPTION
                'Los cobros o devoluciones no coinciden con la diferencia del cambio.';
        END IF;

        SELECT count(*)
          INTO v_cantidad_ajustes
          FROM ventas.ajuste_credito_cambio
         WHERE cambio_venta_id = v_cambio_id;

        IF v_cantidad_ajustes = 1 THEN
            SELECT tipo_ajuste, valor, credito_id
              INTO v_tipo_ajuste, v_valor_ajuste, v_credito_ajuste
              FROM ventas.ajuste_credito_cambio
             WHERE cambio_venta_id = v_cambio_id;
        END IF;

        IF v_cambio.valor_ajuste_credito = 0 AND v_cantidad_ajustes <> 0 THEN
            RAISE EXCEPTION
                'El cambio no declara ajuste de credito, pero existe un ajuste asociado.';
        END IF;

        IF v_cambio.valor_ajuste_credito > 0
           AND (
               v_cantidad_ajustes <> 1
               OR v_valor_ajuste <> v_cambio.valor_ajuste_credito
               OR v_credito_ajuste IS DISTINCT FROM v_cambio.credito_id
               OR (
                   v_cambio.diferencia > 0 AND v_tipo_ajuste <> 'AUMENTO'
               )
               OR (
                   v_cambio.diferencia < 0 AND v_tipo_ajuste <> 'REDUCCION'
               )
           )
        THEN
            RAISE EXCEPTION
                'El ajuste del credito no coincide con el tratamiento del cambio.';
        END IF;
    END IF;

    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE CONSTRAINT TRIGGER tg_cambio_validar_liquidacion_cabecera
AFTER INSERT OR UPDATE ON ventas.cambio_venta
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_liquidacion_cambio();

CREATE CONSTRAINT TRIGGER tg_cambio_validar_liquidacion_pago
AFTER INSERT OR UPDATE OR DELETE ON ventas.pago_cambio_venta
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_liquidacion_cambio();

CREATE CONSTRAINT TRIGGER tg_cambio_validar_liquidacion_detalle
AFTER INSERT OR UPDATE OR DELETE ON ventas.detalle_cambio_venta
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_liquidacion_cambio();

CREATE CONSTRAINT TRIGGER tg_cambio_validar_liquidacion_credito
AFTER INSERT OR UPDATE OR DELETE ON ventas.ajuste_credito_cambio
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ventas.validar_liquidacion_cambio();

CREATE FUNCTION compras.validar_totales_compra()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_compra_id uuid;
    v_compra compras.compra%ROWTYPE;
    v_lineas integer;
    v_subtotal numeric;
    v_impuesto numeric;
    v_total numeric;
BEGIN
    IF TG_TABLE_NAME = 'compra' THEN
        v_compra_id := NEW.id;
    ELSIF TG_OP = 'DELETE' THEN
        v_compra_id := OLD.compra_id;
    ELSE
        v_compra_id := NEW.compra_id;
    END IF;

    SELECT *
      INTO v_compra
      FROM compras.compra
     WHERE id = v_compra_id;

    IF NOT FOUND THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;

    SELECT count(*),
           round(COALESCE(sum(subtotal_bruto), 0), 2),
           round(COALESCE(sum(valor_iva), 0), 2),
           round(COALESCE(sum(total_linea), 0), 2)
      INTO v_lineas, v_subtotal, v_impuesto, v_total
      FROM compras.detalle_compra
     WHERE compra_id = v_compra_id;

    IF v_compra.estado IN ('CONFIRMADA', 'ANULADA') AND v_lineas = 0 THEN
        RAISE EXCEPTION
            'Una compra confirmada o anulada debe conservar al menos una linea.';
    END IF;

    IF v_compra.subtotal_bruto <> v_subtotal OR v_compra.total <> v_total THEN
        RAISE EXCEPTION
            'Los totales de la compra no coinciden con sus lineas.';
    END IF;

    IF (v_compra.modo_iva = 'NO_DISCRIMINADO'
        AND v_compra.impuesto_total IS NOT NULL)
       OR (v_compra.modo_iva <> 'NO_DISCRIMINADO'
           AND v_compra.impuesto_total <> v_impuesto)
    THEN
        RAISE EXCEPTION
            'El IVA de la compra no coincide con sus lineas.';
    END IF;

    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE CONSTRAINT TRIGGER tg_compra_validar_totales_cabecera
AFTER INSERT OR UPDATE ON compras.compra
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION compras.validar_totales_compra();

CREATE CONSTRAINT TRIGGER tg_compra_validar_totales_detalle
AFTER INSERT OR UPDATE OR DELETE ON compras.detalle_compra
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION compras.validar_totales_compra();

CREATE FUNCTION compras.validar_avance_pedido()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_pedido_id uuid;
    v_estado varchar(30);
    v_lineas integer;
    v_lineas_con_recepcion integer;
    v_lineas_pendientes integer;
    v_desajustes integer;
BEGIN
    IF TG_TABLE_NAME = 'pedido_compra' THEN
        v_pedido_id := NEW.id;
    ELSIF TG_TABLE_NAME = 'detalle_pedido_compra' THEN
        IF TG_OP = 'DELETE' THEN
            v_pedido_id := OLD.pedido_compra_id;
        ELSE
            v_pedido_id := NEW.pedido_compra_id;
        END IF;
    ELSIF TG_TABLE_NAME = 'compra' THEN
        IF TG_OP = 'DELETE' THEN
            v_pedido_id := OLD.pedido_compra_id;
        ELSE
            v_pedido_id := NEW.pedido_compra_id;
        END IF;
    ELSE
        SELECT pedido_compra_id
          INTO v_pedido_id
          FROM compras.compra
         WHERE id = CASE
             WHEN TG_OP = 'DELETE' THEN OLD.compra_id
             ELSE NEW.compra_id
         END;
    END IF;

    IF v_pedido_id IS NULL THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;

    SELECT estado
      INTO v_estado
      FROM compras.pedido_compra
     WHERE id = v_pedido_id;

    IF NOT FOUND THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;

    SELECT count(*),
           count(*) FILTER (WHERE d.cantidad_recibida > 0),
           count(*) FILTER (WHERE d.cantidad_recibida < d.cantidad_solicitada),
           count(*) FILTER (
               WHERE d.cantidad_recibida <> COALESCE(r.cantidad_confirmada, 0)
           )
      INTO v_lineas,
           v_lineas_con_recepcion,
           v_lineas_pendientes,
           v_desajustes
      FROM compras.detalle_pedido_compra d
      LEFT JOIN (
          SELECT dc.detalle_pedido_compra_id,
                 sum(dc.cantidad)::integer AS cantidad_confirmada
          FROM compras.detalle_compra dc
          JOIN compras.compra c ON c.id = dc.compra_id
          WHERE c.estado IN ('CONFIRMADA', 'ANULADA')
            AND dc.detalle_pedido_compra_id IS NOT NULL
          GROUP BY dc.detalle_pedido_compra_id
      ) r ON r.detalle_pedido_compra_id = d.id
     WHERE d.pedido_compra_id = v_pedido_id;

    IF v_desajustes <> 0 THEN
        RAISE EXCEPTION
            'Las cantidades recibidas del pedido no coinciden con las compras confirmadas.';
    END IF;

    IF v_estado <> 'BORRADOR' AND v_estado <> 'CANCELADO' AND v_lineas = 0 THEN
        RAISE EXCEPTION 'Un pedido enviado debe contener al menos una linea.';
    END IF;

    IF (v_estado = 'BORRADOR' AND v_lineas_con_recepcion <> 0)
       OR (v_estado = 'ENVIADO' AND v_lineas_con_recepcion <> 0)
       OR (v_estado = 'RECIBIDO_PARCIAL'
           AND (v_lineas_con_recepcion = 0 OR v_lineas_pendientes = 0))
       OR (v_estado = 'COMPLETADO' AND v_lineas_pendientes <> 0)
       OR (v_estado = 'CERRADO_CON_PENDIENTES' AND v_lineas_pendientes = 0)
       OR (v_estado = 'CANCELADO' AND v_lineas_con_recepcion <> 0)
    THEN
        RAISE EXCEPTION
            'El estado del pedido no coincide con su avance de recepcion.';
    END IF;

    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE CONSTRAINT TRIGGER tg_pedido_validar_avance_cabecera
AFTER INSERT OR UPDATE ON compras.pedido_compra
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION compras.validar_avance_pedido();

CREATE CONSTRAINT TRIGGER tg_pedido_validar_avance_detalle
AFTER INSERT OR UPDATE OR DELETE ON compras.detalle_pedido_compra
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION compras.validar_avance_pedido();

CREATE CONSTRAINT TRIGGER tg_pedido_validar_avance_compra
AFTER INSERT OR UPDATE OR DELETE ON compras.compra
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION compras.validar_avance_pedido();

CREATE CONSTRAINT TRIGGER tg_pedido_validar_avance_recepcion
AFTER INSERT OR UPDATE OR DELETE ON compras.detalle_compra
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION compras.validar_avance_pedido();

CREATE FUNCTION ventas.validar_referencia_reembolso()
RETURNS trigger
LANGUAGE plpgsql
AS $funcion$
DECLARE
    v_requiere_referencia boolean;
BEGIN
    SELECT requiere_referencia
      INTO v_requiere_referencia
      FROM catalogo.metodo_pago
     WHERE id = NEW.metodo_pago_id;

    IF v_requiere_referencia
       AND (NEW.referencia IS NULL OR btrim(NEW.referencia) = '')
    THEN
        RAISE EXCEPTION 'El medio de reembolso requiere una referencia.';
    END IF;

    RETURN NEW;
END;
$funcion$;

CREATE TRIGGER tg_reembolso_apartado_validar_referencia
BEFORE INSERT OR UPDATE OF metodo_pago_id, referencia
ON ventas.reembolso_apartado
FOR EACH ROW EXECUTE FUNCTION ventas.validar_referencia_reembolso();

CREATE VIEW compras.vw_necesidad_reposicion AS
WITH pendientes AS (
    SELECT d.producto_id,
           sum(greatest(0, d.cantidad_solicitada - d.cantidad_recibida))::integer
               AS cantidad_pendiente
    FROM compras.detalle_pedido_compra d
    JOIN compras.pedido_compra p ON p.id = d.pedido_compra_id
    WHERE p.estado IN ('BORRADOR', 'ENVIADO', 'RECIBIDO_PARCIAL')
    GROUP BY d.producto_id
)
SELECT p.id AS producto_id,
       p.codigo_interno,
       p.nombre AS producto,
       p.proveedor_id,
       pr.nombre_razon_social AS proveedor,
       (p.stock_actual - p.stock_reservado) AS stock_disponible,
       p.stock_minimo,
       COALESCE(pe.cantidad_pendiente, 0) AS pendiente_en_pedidos,
       greatest(
           0,
           p.stock_minimo
           - (
               (p.stock_actual - p.stock_reservado)
               + COALESCE(pe.cantidad_pendiente, 0)
           )
       )::integer AS cantidad_sugerida,
       CASE
           WHEN p.proveedor_id IS NULL THEN 'SIN_PROVEEDOR'
           WHEN pr.activo = false THEN 'PROVEEDOR_INACTIVO'
           ELSE 'LISTO_PARA_PEDIDO'
       END AS estado_proveedor,
       (p.proveedor_id IS NOT NULL AND pr.activo = true) AS puede_generar_pedido
FROM catalogo.producto p
LEFT JOIN catalogo.proveedor pr ON pr.id = p.proveedor_id
LEFT JOIN pendientes pe ON pe.producto_id = p.id
WHERE p.activo = true
  AND (
      p.stock_actual - p.stock_reservado = 0
      OR p.stock_actual - p.stock_reservado < p.stock_minimo
  );

-- =============================================================================
-- 12. INDICES DE RELACIONES Y CONSULTAS OPERATIVAS
-- =============================================================================

-- Configuracion
CREATE INDEX ix_instalacion_establecimiento
    ON configuracion.instalacion (establecimiento_id);

CREATE INDEX ix_motivo_operacion_tipo_activo
    ON configuracion.motivo_operacion
       (establecimiento_id, tipo_operacion, activo, orden_visual);

CREATE INDEX ix_destino_respaldo_instalacion_tipo
    ON configuracion.destino_respaldo (instalacion_id, tipo_destino, activo);

CREATE INDEX ix_respaldo_instalacion_fecha
    ON configuracion.ejecucion_respaldo (instalacion_id, fecha_inicio DESC);

CREATE INDEX ix_respaldo_resultado_fecha
    ON configuracion.ejecucion_respaldo (resultado, fecha_inicio DESC);

CREATE INDEX ix_copia_respaldo_ejecucion
    ON configuracion.copia_respaldo (ejecucion_respaldo_id);

CREATE INDEX ix_copia_respaldo_pendiente
    ON configuracion.copia_respaldo (estado, fecha_ultimo_intento)
    WHERE estado IN ('PENDIENTE', 'FALLIDA');

CREATE INDEX ix_prueba_restauracion_copia_fecha
    ON configuracion.prueba_restauracion (copia_respaldo_id, fecha_inicio DESC);

CREATE INDEX ix_prueba_restauracion_autorizacion
    ON configuracion.prueba_restauracion (autorizacion_operacion_id);

CREATE INDEX ix_perfil_impresora_terminal_activo
    ON configuracion.perfil_impresora (terminal_id, activo, tipo_impresora);

CREATE INDEX ix_plantilla_impresion_tipo_activa
    ON configuracion.plantilla_impresion
       (establecimiento_id, tipo_salida, activa);

-- Seguridad
CREATE INDEX ix_usuario_rol_rol
    ON seguridad.usuario_rol (rol_id);

CREATE INDEX ix_usuario_rol_asignado_por
    ON seguridad.usuario_rol (asignado_por_id);

CREATE INDEX ix_rol_permiso_permiso
    ON seguridad.rol_permiso (permiso_id);

CREATE INDEX ix_limite_operacion_rol_activo
    ON seguridad.limite_operacion_rol (rol_id, activo);

CREATE INDEX ix_credencial_usuario_fecha
    ON seguridad.credencial_usuario (usuario_id, fecha_emision DESC);

CREATE UNIQUE INDEX uq_credencial_usuario_activa
    ON seguridad.credencial_usuario (usuario_id)
    WHERE estado = 'ACTIVA';

CREATE INDEX ix_permiso_modulo_activo
    ON seguridad.permiso (modulo, activo);

CREATE INDEX ix_autorizacion_solicitante_fecha
    ON seguridad.autorizacion_operacion (usuario_solicitante_id, fecha_solicitud DESC);

CREATE INDEX ix_autorizacion_autorizador_fecha
    ON seguridad.autorizacion_operacion (usuario_autorizador_id, fecha_solicitud DESC);

CREATE INDEX ix_autorizacion_permiso
    ON seguridad.autorizacion_operacion (permiso_id);

CREATE INDEX ix_autorizacion_credencial
    ON seguridad.autorizacion_operacion (credencial_autorizador_id);

CREATE INDEX ix_autorizacion_estado_expiracion
    ON seguridad.autorizacion_operacion (estado, fecha_expiracion);

CREATE INDEX ix_autorizacion_correlacion
    ON seguridad.autorizacion_operacion (correlacion_id);

CREATE INDEX ix_usuario_claim_usuario
    ON seguridad.usuario_claim (usuario_id);

CREATE INDEX ix_rol_claim_rol
    ON seguridad.rol_claim (rol_id);

CREATE INDEX ix_usuario_login_usuario
    ON seguridad.usuario_login (usuario_id);

-- Catalogos
CREATE INDEX ix_categoria_usuario_creacion
    ON catalogo.categoria (usuario_creacion_id);

CREATE INDEX ix_categoria_usuario_modificacion
    ON catalogo.categoria (usuario_modificacion_id);

CREATE INDEX ix_producto_categoria_activo
    ON catalogo.producto (categoria_id, activo);

CREATE INDEX ix_producto_unidad
    ON catalogo.producto (unidad_medida_id);

CREATE INDEX ix_producto_proveedor_activo
    ON catalogo.producto (proveedor_id, activo);

CREATE INDEX ix_producto_usuario_creacion
    ON catalogo.producto (usuario_creacion_id);

CREATE INDEX ix_producto_usuario_modificacion
    ON catalogo.producto (usuario_modificacion_id);

CREATE INDEX ix_producto_nombre_busqueda
    ON catalogo.producto (lower(nombre));

CREATE INDEX ix_producto_stock_bajo
    ON catalogo.producto (id)
    WHERE activo = true AND stock_actual <= stock_minimo;

CREATE INDEX ix_cliente_usuario_creacion
    ON catalogo.cliente (usuario_creacion_id);

CREATE INDEX ix_cliente_usuario_modificacion
    ON catalogo.cliente (usuario_modificacion_id);

CREATE INDEX ix_cliente_nombre_busqueda
    ON catalogo.cliente (lower(nombre_completo));

CREATE INDEX ix_proveedor_usuario_creacion
    ON catalogo.proveedor (usuario_creacion_id);

CREATE INDEX ix_proveedor_usuario_modificacion
    ON catalogo.proveedor (usuario_modificacion_id);

CREATE INDEX ix_proveedor_nombre_busqueda
    ON catalogo.proveedor (lower(nombre_razon_social));

-- Caja
CREATE INDEX ix_turno_caja_caja_fecha
    ON caja.turno_caja (caja_id, fecha_hora_apertura DESC);

CREATE INDEX ix_turno_caja_terminal
    ON caja.turno_caja (terminal_id);

CREATE INDEX ix_turno_caja_usuario_apertura
    ON caja.turno_caja (usuario_apertura_id);

CREATE INDEX ix_turno_caja_usuario_responsable
    ON caja.turno_caja (usuario_responsable_id);

CREATE INDEX ix_turno_caja_usuario_cierre
    ON caja.turno_caja (usuario_cierre_id);

CREATE INDEX ix_turno_caja_fecha_operativa
    ON caja.turno_caja (fecha_operativa DESC);

CREATE UNIQUE INDEX uq_turno_caja_abierto_por_caja
    ON caja.turno_caja (caja_id)
    WHERE estado = 'ABIERTA';

CREATE INDEX ix_sesion_operador_turno_fecha
    ON caja.sesion_operador (turno_caja_id, fecha_inicio DESC);

CREATE INDEX ix_sesion_operador_usuario_fecha
    ON caja.sesion_operador (usuario_id, fecha_inicio DESC);

CREATE INDEX ix_sesion_operador_credencial
    ON caja.sesion_operador (credencial_usuario_id);

CREATE UNIQUE INDEX uq_sesion_operador_activa_terminal
    ON caja.sesion_operador (terminal_id)
    WHERE estado = 'ACTIVA';

CREATE INDEX ix_movimiento_caja_turno_fecha
    ON caja.movimiento_caja (turno_caja_id, fecha_hora);

CREATE INDEX ix_movimiento_caja_usuario
    ON caja.movimiento_caja (usuario_id);

CREATE INDEX ix_movimiento_caja_sesion
    ON caja.movimiento_caja (sesion_operador_id);

CREATE INDEX ix_movimiento_caja_revertido
    ON caja.movimiento_caja (movimiento_revertido_id);

CREATE UNIQUE INDEX uq_movimiento_caja_una_reversion
    ON caja.movimiento_caja (movimiento_revertido_id)
    WHERE movimiento_revertido_id IS NOT NULL;

CREATE INDEX ix_movimiento_caja_correlacion
    ON caja.movimiento_caja (correlacion_id);

-- Ventas
CREATE INDEX ix_borrador_venta_turno_fecha
    ON ventas.borrador_venta (turno_caja_id, fecha_modificacion DESC);

CREATE INDEX ix_borrador_venta_usuario
    ON ventas.borrador_venta (usuario_id);

CREATE INDEX ix_borrador_venta_sesion
    ON ventas.borrador_venta (sesion_operador_id);

CREATE UNIQUE INDEX uq_borrador_venta_activo_terminal
    ON ventas.borrador_venta (terminal_id)
    WHERE estado IN ('ACTIVO', 'RECUPERADO');

CREATE INDEX ix_detalle_borrador_borrador
    ON ventas.detalle_borrador_venta (borrador_venta_id);

CREATE INDEX ix_detalle_borrador_producto
    ON ventas.detalle_borrador_venta (producto_id);

CREATE INDEX ix_venta_turno_fecha
    ON ventas.venta (turno_caja_id, fecha_hora DESC);

CREATE INDEX ix_venta_usuario_fecha
    ON ventas.venta (usuario_id, fecha_hora DESC);

CREATE INDEX ix_venta_sesion
    ON ventas.venta (sesion_operador_id);

CREATE UNIQUE INDEX uq_venta_sesion_operador
    ON ventas.venta (sesion_operador_id)
    WHERE sesion_operador_id IS NOT NULL;

CREATE INDEX ix_venta_autorizacion_descuento
    ON ventas.venta (autorizacion_descuento_id);

CREATE INDEX ix_venta_cliente_fecha
    ON ventas.venta (cliente_id, fecha_hora DESC);

CREATE INDEX ix_venta_fecha_operativa_estado
    ON ventas.venta (fecha_operativa DESC, estado);

CREATE INDEX ix_detalle_venta_venta
    ON ventas.detalle_venta (venta_id);

CREATE INDEX ix_detalle_venta_producto
    ON ventas.detalle_venta (producto_id);

CREATE INDEX ix_pago_venta_venta
    ON ventas.pago_venta (venta_id);

CREATE INDEX ix_pago_venta_metodo
    ON ventas.pago_venta (metodo_pago_id);

CREATE INDEX ix_pago_venta_usuario
    ON ventas.pago_venta (usuario_id);

CREATE INDEX ix_pago_venta_sesion
    ON ventas.pago_venta (sesion_operador_id);

CREATE INDEX ix_pago_venta_usuario_anulacion
    ON ventas.pago_venta (usuario_anulacion_id);

CREATE INDEX ix_pago_venta_motivo_anulacion
    ON ventas.pago_venta (motivo_anulacion_id);

CREATE INDEX ix_anulacion_venta_solicitante
    ON ventas.anulacion_venta (usuario_solicitante_id);

CREATE INDEX ix_anulacion_venta_autorizador
    ON ventas.anulacion_venta (usuario_autorizador_id);

CREATE INDEX ix_pago_credito_credito_fecha
    ON ventas.pago_credito (credito_id, fecha_hora DESC);

CREATE INDEX ix_pago_credito_turno
    ON ventas.pago_credito (turno_caja_id);

CREATE INDEX ix_pago_credito_metodo
    ON ventas.pago_credito (metodo_pago_id);

CREATE INDEX ix_pago_credito_usuario
    ON ventas.pago_credito (usuario_id);

CREATE INDEX ix_pago_credito_sesion
    ON ventas.pago_credito (sesion_operador_id);

CREATE INDEX ix_pago_credito_usuario_anulacion
    ON ventas.pago_credito (usuario_anulacion_id);

CREATE INDEX ix_pago_credito_motivo_anulacion
    ON ventas.pago_credito (motivo_anulacion_id);

CREATE INDEX ix_credito_estado_vencimiento
    ON ventas.credito (estado, fecha_vencimiento);

CREATE INDEX ix_apartado_cliente_fecha
    ON ventas.apartado (cliente_id, fecha_hora DESC);

CREATE INDEX ix_apartado_usuario
    ON ventas.apartado (usuario_id);

CREATE INDEX ix_apartado_turno
    ON ventas.apartado (turno_caja_id);

CREATE INDEX ix_apartado_sesion
    ON ventas.apartado (sesion_operador_id);

CREATE INDEX ix_apartado_autorizacion_descuento
    ON ventas.apartado (autorizacion_descuento_id);

CREATE INDEX ix_apartado_usuario_entrega
    ON ventas.apartado (usuario_entrega_id);

CREATE INDEX ix_apartado_usuario_anulacion
    ON ventas.apartado (usuario_anulacion_id);

CREATE INDEX ix_apartado_estado_limite
    ON ventas.apartado (estado, fecha_limite);

CREATE INDEX ix_detalle_apartado_apartado
    ON ventas.detalle_apartado (apartado_id);

CREATE INDEX ix_detalle_apartado_producto
    ON ventas.detalle_apartado (producto_id);

CREATE INDEX ix_pago_apartado_apartado_fecha
    ON ventas.pago_apartado (apartado_id, fecha_hora DESC);

CREATE INDEX ix_pago_apartado_turno
    ON ventas.pago_apartado (turno_caja_id);

CREATE INDEX ix_pago_apartado_metodo
    ON ventas.pago_apartado (metodo_pago_id);

CREATE INDEX ix_pago_apartado_usuario
    ON ventas.pago_apartado (usuario_id);

CREATE INDEX ix_pago_apartado_sesion
    ON ventas.pago_apartado (sesion_operador_id);

CREATE INDEX ix_pago_apartado_usuario_anulacion
    ON ventas.pago_apartado (usuario_anulacion_id);

CREATE INDEX ix_pago_apartado_motivo_anulacion
    ON ventas.pago_apartado (motivo_anulacion_id);

CREATE INDEX ix_reembolso_apartado_apartado_fecha
    ON ventas.reembolso_apartado (apartado_id, fecha_hora DESC);

CREATE INDEX ix_reembolso_apartado_turno
    ON ventas.reembolso_apartado (turno_caja_id);

CREATE INDEX ix_reembolso_apartado_sesion
    ON ventas.reembolso_apartado (sesion_operador_id);

CREATE INDEX ix_cambio_venta_venta_fecha
    ON ventas.cambio_venta (venta_id, fecha_hora DESC);

CREATE INDEX ix_cambio_venta_credito
    ON ventas.cambio_venta (credito_id);

CREATE INDEX ix_cambio_venta_turno
    ON ventas.cambio_venta (turno_caja_id);

CREATE INDEX ix_cambio_venta_usuario
    ON ventas.cambio_venta (usuario_id);

CREATE INDEX ix_cambio_venta_sesion
    ON ventas.cambio_venta (sesion_operador_id);

CREATE INDEX ix_cambio_venta_motivo_anulacion
    ON ventas.cambio_venta (motivo_anulacion_id);

CREATE INDEX ix_detalle_cambio_cambio
    ON ventas.detalle_cambio_venta (cambio_venta_id);

CREATE INDEX ix_detalle_cambio_origen
    ON ventas.detalle_cambio_venta (detalle_venta_origen_id);

CREATE INDEX ix_detalle_cambio_producto
    ON ventas.detalle_cambio_venta (producto_id);

CREATE INDEX ix_pago_cambio_cambio
    ON ventas.pago_cambio_venta (cambio_venta_id);

CREATE INDEX ix_pago_cambio_turno
    ON ventas.pago_cambio_venta (turno_caja_id);

CREATE INDEX ix_pago_cambio_metodo
    ON ventas.pago_cambio_venta (metodo_pago_id);

CREATE INDEX ix_pago_cambio_usuario
    ON ventas.pago_cambio_venta (usuario_id);

CREATE INDEX ix_pago_cambio_sesion
    ON ventas.pago_cambio_venta (sesion_operador_id);

CREATE INDEX ix_ajuste_credito_credito_fecha
    ON ventas.ajuste_credito_cambio (credito_id, fecha_hora DESC);

-- Compras e inventario
CREATE INDEX ix_pedido_compra_proveedor_estado
    ON compras.pedido_compra (proveedor_id, estado, fecha_creacion DESC);

CREATE UNIQUE INDEX uq_pedido_compra_borrador_proveedor
    ON compras.pedido_compra (instalacion_id, proveedor_id)
    WHERE estado = 'BORRADOR';

CREATE INDEX ix_pedido_compra_instalacion_fecha
    ON compras.pedido_compra (instalacion_id, fecha_creacion DESC);

CREATE INDEX ix_detalle_pedido_pedido
    ON compras.detalle_pedido_compra (pedido_compra_id);

CREATE INDEX ix_detalle_pedido_producto
    ON compras.detalle_pedido_compra (producto_id);

CREATE INDEX ix_compra_usuario
    ON compras.compra (usuario_id);

CREATE INDEX ix_compra_pedido
    ON compras.compra (pedido_compra_id);

CREATE INDEX ix_compra_sesion
    ON compras.compra (sesion_operador_id);

CREATE INDEX ix_compra_usuario_anulacion
    ON compras.compra (usuario_anulacion_id);

CREATE INDEX ix_compra_fecha_documento_estado
    ON compras.compra (fecha_documento DESC, estado);

CREATE INDEX ix_detalle_compra_compra
    ON compras.detalle_compra (compra_id);

CREATE INDEX ix_detalle_compra_producto
    ON compras.detalle_compra (producto_id);

CREATE INDEX ix_detalle_compra_detalle_pedido
    ON compras.detalle_compra (detalle_pedido_compra_id);

CREATE INDEX ix_mov_inventario_producto_fecha
    ON compras.movimiento_inventario (producto_id, fecha_hora DESC);

CREATE INDEX ix_mov_inventario_usuario
    ON compras.movimiento_inventario (usuario_id);

CREATE INDEX ix_mov_inventario_sesion
    ON compras.movimiento_inventario (sesion_operador_id);

CREATE INDEX ix_mov_inventario_autorizacion
    ON compras.movimiento_inventario (autorizacion_operacion_id);

CREATE INDEX ix_mov_inventario_venta
    ON compras.movimiento_inventario (venta_id);

CREATE INDEX ix_mov_inventario_compra
    ON compras.movimiento_inventario (compra_id);

CREATE INDEX ix_mov_inventario_apartado
    ON compras.movimiento_inventario (apartado_id);

CREATE INDEX ix_mov_inventario_cambio
    ON compras.movimiento_inventario (cambio_venta_id);

CREATE INDEX ix_mov_inventario_anulacion
    ON compras.movimiento_inventario (anulacion_venta_id);

CREATE INDEX ix_mov_inventario_revertido
    ON compras.movimiento_inventario (movimiento_revertido_id);

CREATE UNIQUE INDEX uq_mov_inventario_una_reversion
    ON compras.movimiento_inventario (movimiento_revertido_id)
    WHERE movimiento_revertido_id IS NOT NULL;

CREATE INDEX ix_mov_inventario_correlacion
    ON compras.movimiento_inventario (correlacion_id);

-- Documentos e impresion
CREATE INDEX ix_documento_emitido_entidad
    ON configuracion.documento_emitido
       (entidad_tipo, entidad_id, fecha_emision DESC);

CREATE INDEX ix_documento_emitido_fecha
    ON configuracion.documento_emitido (instalacion_id, fecha_emision DESC);

CREATE INDEX ix_trabajo_impresion_documento
    ON configuracion.trabajo_impresion
       (documento_emitido_id, fecha_solicitud DESC);

CREATE INDEX ix_trabajo_impresion_pendiente
    ON configuracion.trabajo_impresion (terminal_id, estado, fecha_solicitud)
    WHERE estado IN ('PENDIENTE', 'IMPRIMIENDO', 'FALLIDO');

-- Auditoria e idempotencia
CREATE INDEX ix_evento_auditoria_usuario_fecha
    ON auditoria.evento_auditoria (usuario_id, fecha_hora DESC);

CREATE INDEX ix_evento_auditoria_autorizador
    ON auditoria.evento_auditoria (usuario_autorizador_id);

CREATE INDEX ix_evento_auditoria_sesion
    ON auditoria.evento_auditoria (sesion_operador_id);

CREATE INDEX ix_evento_auditoria_instalacion_fecha
    ON auditoria.evento_auditoria (instalacion_id, fecha_hora DESC);

CREATE INDEX ix_evento_auditoria_terminal
    ON auditoria.evento_auditoria (terminal_id);

CREATE INDEX ix_evento_auditoria_entidad
    ON auditoria.evento_auditoria (entidad, entidad_id, fecha_hora DESC);

CREATE INDEX ix_evento_auditoria_correlacion
    ON auditoria.evento_auditoria (correlacion_id);

CREATE INDEX ix_idempotente_terminal
    ON auditoria.operacion_idempotente (terminal_id);

CREATE INDEX ix_idempotente_usuario
    ON auditoria.operacion_idempotente (usuario_id);

CREATE INDEX ix_idempotente_sesion
    ON auditoria.operacion_idempotente (sesion_operador_id);

CREATE INDEX ix_idempotente_fecha
    ON auditoria.operacion_idempotente (fecha_registro DESC);

-- =============================================================================
-- DOCUMENTACION DE DECISIONES DEL MODELO
-- =============================================================================

COMMENT ON COLUMN configuracion.establecimiento.iva_predeterminado IS
    'Opcional. NULL significa que no existe un IVA sugerido al crear productos.';

COMMENT ON COLUMN configuracion.establecimiento.dias_limite_apartado IS
    'Opcional. Si es NULL, el usuario debe escoger la fecha limite de cada apartado.';

COMMENT ON COLUMN configuracion.establecimiento.porcentaje_minimo_apartado IS
    'Porcentaje minimo configurable; el valor inicial aprobado es 20 por ciento.';

COMMENT ON COLUMN configuracion.establecimiento.modo_turno_predeterminado IS
    'Modo aplicado al siguiente turno. No puede cambiarse mientras exista operacion activa.';

COMMENT ON COLUMN configuracion.establecimiento.dias_prueba_restauracion IS
    'Frecuencia maxima inicial de 90 dias, ademas de pruebas posteriores a cambios mayores.';

COMMENT ON TABLE seguridad.rol IS
    'La aplicacion crea Administrador, Supervisor y Cajero como plantillas iniciales; sus permisos son editables.';

COMMENT ON TABLE seguridad.limite_operacion_rol IS
    'Limites configurables por rol. Para DESCUENTO_PORCENTAJE los valores iniciales son 100, 20 y 5 para Administrador, Supervisor y Cajero.';

COMMENT ON TABLE seguridad.credencial_usuario IS
    'Credencial rapida Code 128. Solo conserva el hash y un fragmento no secreto; el token se imprime directamente y nunca entra en snapshots ni colas persistentes.';

COMMENT ON COLUMN catalogo.producto.proveedor_id IS
    'Unico proveedor asignado al producto en V1. NULL se muestra como Sin proveedor.';

COMMENT ON COLUMN catalogo.producto.porcentaje_iva IS
    'NULL significa IVA no especificado; 0 significa IVA conocido de cero por ciento.';

COMMENT ON COLUMN catalogo.producto.precio_minorista IS
    'Precio final de venta en COP enteros con IVA incluido cuando este se conoce.';

COMMENT ON COLUMN catalogo.producto.precio_mayorista IS
    'Precio final mayorista opcional en COP enteros; nunca se le suma IVA en caja.';

COMMENT ON COLUMN catalogo.producto.costo_promedio IS
    'NULL significa costo aun desconocido; cero representa un costo conocido de cero.';

COMMENT ON COLUMN ventas.venta.total IS
    'Precio final en COP enteros. El IVA ya esta incluido y nunca se suma nuevamente.';

COMMENT ON TABLE ventas.borrador_venta IS
    'Carrito recuperable despues de una interrupcion. No constituye una venta ni afecta caja o inventario.';

COMMENT ON TABLE compras.pedido_compra IS
    'Pedido generado por el proveedor actualmente asignado a los productos; cada recepcion confirmada crea una compra.';

COMMENT ON COLUMN compras.detalle_pedido_compra.cantidad_recibida IS
    'Cantidad recibida historicamente. Una anulacion posterior de la compra revierte inventario, pero no reescribe el pedido enviado.';

COMMENT ON VIEW compras.vw_necesidad_reposicion IS
    'Aplica max(0, minimo - (disponible + pendiente)); incluye agotados aun con minimo cero.';

COMMENT ON COLUMN compras.compra.numero_documento_proveedor IS
    'Factura o referencia del proveedor opcional; si se informa, es unica para ese proveedor.';

COMMENT ON TABLE configuracion.documento_emitido IS
    'Snapshot inmutable de datos y plantilla para que una reimpresion no cambie el documento historico.';

COMMENT ON TABLE configuracion.trabajo_impresion IS
    'Cola reintentable separada de la transaccion comercial; un fallo de impresion no revierte la venta.';

COMMENT ON TABLE configuracion.destino_respaldo IS
    'Configura copia local fisicamente separada y copia externa cifrada con retencion diaria, semanal y mensual.';

-- =============================================================================
-- 13. VALIDACION ESTRUCTURAL ANTES DE CONFIRMAR
-- =============================================================================

DO $validacion$
DECLARE
    cantidad_tablas integer;
    cantidad_pk     integer;
    cantidad_fk     integer;
    cantidad_fk_no_restrict integer;
    cantidad_cantidades_no_enteras integer;
    existe_producto_proveedor integer;
BEGIN
    SELECT count(*)
      INTO cantidad_tablas
      FROM information_schema.tables
     WHERE table_type = 'BASE TABLE'
       AND table_schema IN (
           'seguridad', 'configuracion', 'catalogo', 'caja',
           'ventas', 'compras', 'auditoria'
       );

    SELECT count(*)
      INTO cantidad_pk
      FROM information_schema.table_constraints
     WHERE constraint_type = 'PRIMARY KEY'
       AND table_schema IN (
           'seguridad', 'configuracion', 'catalogo', 'caja',
           'ventas', 'compras', 'auditoria'
       );

    SELECT count(*)
      INTO cantidad_fk
      FROM information_schema.table_constraints
     WHERE constraint_type = 'FOREIGN KEY'
       AND table_schema IN (
           'seguridad', 'configuracion', 'catalogo', 'caja',
           'ventas', 'compras', 'auditoria'
       );

    SELECT count(*)
      INTO cantidad_fk_no_restrict
      FROM pg_constraint c
      JOIN pg_namespace n ON n.oid = c.connamespace
     WHERE c.contype = 'f'
       AND n.nspname IN (
           'seguridad', 'configuracion', 'catalogo', 'caja',
           'ventas', 'compras', 'auditoria'
       )
       AND c.confdeltype <> 'r';

    SELECT count(*)
      INTO cantidad_cantidades_no_enteras
      FROM information_schema.columns
     WHERE table_schema IN ('catalogo', 'ventas', 'compras')
       AND (
           column_name LIKE 'cantidad%'
           OR column_name IN (
               'stock_actual', 'stock_reservado', 'stock_minimo',
               'stock_anterior', 'stock_posterior',
               'reservado_anterior', 'reservado_posterior',
               'pendiente_otros_pedidos'
           )
       )
       AND data_type <> 'integer';

    SELECT count(*)
      INTO existe_producto_proveedor
      FROM information_schema.tables
     WHERE table_schema = 'catalogo'
       AND table_name = 'producto_proveedor';

    IF cantidad_tablas <> 58 THEN
        RAISE EXCEPTION
            'Validacion ControlPlus: se esperaban 58 tablas y se encontraron %.',
            cantidad_tablas;
    END IF;

    IF cantidad_pk <> 58 THEN
        RAISE EXCEPTION
            'Validacion ControlPlus: cada tabla debe tener PK; se encontraron % PK.',
            cantidad_pk;
    END IF;

    IF cantidad_fk = 0 THEN
        RAISE EXCEPTION
            'Validacion ControlPlus: no se encontraron claves foraneas.';
    END IF;

    IF cantidad_fk_no_restrict <> 0 THEN
        RAISE EXCEPTION
            'Validacion ControlPlus: se encontraron % FK sin ON DELETE RESTRICT.',
            cantidad_fk_no_restrict;
    END IF;

    IF cantidad_cantidades_no_enteras <> 0 THEN
        RAISE EXCEPTION
            'Validacion ControlPlus: se encontraron % cantidades o existencias no enteras.',
            cantidad_cantidades_no_enteras;
    END IF;

    IF existe_producto_proveedor <> 0 THEN
        RAISE EXCEPTION
            'Validacion ControlPlus: V1 admite un solo proveedor por producto; producto_proveedor no debe existir.';
    END IF;

    RAISE NOTICE
        'ControlPlus validado: % tablas, % PK y % FK.',
        cantidad_tablas, cantidad_pk, cantidad_fk;
END;
$validacion$;

COMMIT;

-- =============================================================================
-- 14. RESUMEN DE COMPROBACION (solo consulta; no modifica datos)
-- =============================================================================

SELECT
    table_schema AS esquema,
    count(*) AS tablas
FROM information_schema.tables
WHERE table_type = 'BASE TABLE'
  AND table_schema IN (
      'seguridad', 'configuracion', 'catalogo', 'caja',
      'ventas', 'compras', 'auditoria'
  )
GROUP BY table_schema
ORDER BY table_schema;

SELECT
    constraint_type AS tipo_restriccion,
    count(*) AS cantidad
FROM information_schema.table_constraints
WHERE table_schema IN (
    'seguridad', 'configuracion', 'catalogo', 'caja',
    'ventas', 'compras', 'auditoria'
)
GROUP BY constraint_type
ORDER BY constraint_type;
